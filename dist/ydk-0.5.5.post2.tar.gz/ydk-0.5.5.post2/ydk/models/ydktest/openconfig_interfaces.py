""" openconfig_interfaces 

Model for managing network interfaces and subinterfaces.  This
module also defines convenience types / groupings for other
models to create references to interfaces\:

 base\-interface\-ref (type) \-  reference to a base interface
 interface\-ref (grouping) \-  container for reference to a
   interface + subinterface
 interface\-ref\-state (grouping) \- container for read\-only
   (opstate) reference to interface + subinterface

This model reuses data items defined in the IETF YANG model for
interfaces described by RFC 7223 with an alternate structure
(particularly for operational state data) and and with
additional configuration items.

"""


import re
import collections

from enum import Enum

from ydk.types import Empty, YList, YLeafList, DELETE, Decimal64, FixedBitsDict

from ydk.errors import YPYError, YPYModelError




class Interfaces(object):
    """
    Top level container for interfaces, including configuration
    and state data.
    
    .. attribute:: interface
    
    	The list of named interfaces on the device
    	**type**\: list of    :py:class:`Interface <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface>`
    
    

    """

    _prefix = 'oc-if'
    _revision = '2016-05-26'

    def __init__(self):
        self.ylist_key_names = []

        self.interface = YList()
        self.interface.parent = self
        self.interface.name = 'interface'


    class Interface(object):
        """
        The list of named interfaces on the device.
        
        .. attribute:: name  <key>
        
        	References the configured name of the interface
        	**type**\:  str
        
        	**refers to**\:  :py:class:`name <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.Config>`
        
        .. attribute:: config
        
        	Configurable items at the global, physical interface level
        	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.Config>`
        
        .. attribute:: hold_time
        
        	Top\-level container for hold\-time settings to enable dampening advertisements of interface transitions
        	**type**\:   :py:class:`HoldTime <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.HoldTime>`
        
        .. attribute:: state
        
        	Operational state data at the global interface level
        	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.State>`
        
        	**config**\: False
        
        .. attribute:: subinterfaces
        
        	Enclosing container for the list of subinterfaces associated with a physical interface
        	**type**\:   :py:class:`Subinterfaces <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.Subinterfaces>`
        
        

        """

        _prefix = 'oc-if'
        _revision = '2016-05-26'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = ['name']

            self.name = None
            self.config = Interfaces.Interface.Config()
            self.config.parent = self
            self.hold_time = Interfaces.Interface.HoldTime()
            self.hold_time.parent = self
            self.state = Interfaces.Interface.State()
            self.state.parent = self
            self.subinterfaces = Interfaces.Interface.Subinterfaces()
            self.subinterfaces.parent = self


        class Config(object):
            """
            Configurable items at the global, physical interface
            level
            
            .. attribute:: description
            
            	[adapted from IETF interfaces model (RFC 7223)]  A textual description of the interface.  A server implementation MAY map this leaf to the ifAlias MIB object.  Such an implementation needs to use some mechanism to handle the differences in size and characters allowed between this leaf and ifAlias.  The definition of such a mechanism is outside the scope of this document.  Since ifAlias is defined to be stored in non\-volatile storage, the MIB implementation MUST map ifAlias to the value of 'description' in the persistently stored datastore.  Specifically, if the device supports '\:startup', when ifAlias is read the device MUST return the value of 'description' in the 'startup' datastore, and when it is written, it MUST be written to the 'running' and 'startup' datastores.  Note that it is up to the implementation to  decide whether to modify this single leaf in 'startup' or perform an implicit copy\-config from 'running' to 'startup'.  If the device does not support '\:startup', ifAlias MUST be mapped to the 'description' leaf in the 'running' datastore
            	**type**\:  str
            
            .. attribute:: enabled
            
            	[adapted from IETF interfaces model (RFC 7223)]  This leaf contains the configured, desired state of the interface.  Systems that implement the IF\-MIB use the value of this leaf in the 'running' datastore to set IF\-MIB.ifAdminStatus to 'up' or 'down' after an ifEntry has been initialized, as described in RFC 2863.  Changes in this leaf in the 'running' datastore are reflected in ifAdminStatus, but if ifAdminStatus is changed over SNMP, this leaf is not affected
            	**type**\:  bool
            
            	**default value**\: true
            
            .. attribute:: mtu
            
            	Set the max transmission unit size in octets for the physical interface.  If this is not set, the mtu is set to the operational default \-\- e.g., 1514 bytes on an Ethernet interface
            	**type**\:  int
            
            	**range:** 0..65535
            
            .. attribute:: name
            
            	[adapted from IETF interfaces model (RFC 7223)]  The name of the interface.  A device MAY restrict the allowed values for this leaf, possibly depending on the type of the interface. For system\-controlled interfaces, this leaf is the device\-specific name of the interface.  The 'config false' list interfaces/interface[name]/state contains the currently existing interfaces on the device.  If a client tries to create configuration for a system\-controlled interface that is not present in the corresponding state list, the server MAY reject the request if the implementation does not support pre\-provisioning of interfaces or if the name refers to an interface that can never exist in the system.  A NETCONF server MUST reply with an rpc\-error with the error\-tag 'invalid\-value' in this case.  The IETF model in RFC 7223 provides YANG features for the following (i.e., pre\-provisioning and arbitrary\-names), however they are omitted here\:   If the device supports pre\-provisioning of interface  configuration, the 'pre\-provisioning' feature is  advertised.   If the device allows arbitrarily named user\-controlled  interfaces, the 'arbitrary\-names' feature is advertised.  When a configured user\-controlled interface is created by the system, it is instantiated with the same name in the /interfaces/interface[name]/state list
            	**type**\:  str
            
            .. attribute:: type
            
            	[adapted from IETF interfaces model (RFC 7223)]  The type of the interface.  When an interface entry is created, a server MAY initialize the type leaf with a valid value, e.g., if it is possible to derive the type from the name of the interface.  If a client tries to set the type of an interface to a value that can never be used by the system, e.g., if the type is not supported or if the type does not match the name of the interface, the server MUST reject the request. A NETCONF server MUST reply with an rpc\-error with the error\-tag 'invalid\-value' in this case
            	**type**\:   :py:class:`InterfaceTypeIdentity <ydk.models.ydktest.ietf_interfaces.InterfaceTypeIdentity>`
            
            

            """

            _prefix = 'oc-if'
            _revision = '2016-05-26'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.description = None
                self.enabled = None
                self.mtu = None
                self.name = None
                self.type = None

            @property
            def _common_path(self):
                if self.parent is None:
                    raise YPYModelError('parent is not set . Cannot derive path.')

                return self.parent._common_path +'/openconfig-interfaces:config'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.description is not None:
                    return True

                if self.enabled is not None:
                    return True

                if self.mtu is not None:
                    return True

                if self.name is not None:
                    return True

                if self.type is not None:
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                return meta._meta_table['Interfaces.Interface.Config']['meta_info']


        class State(object):
            """
            Operational state data at the global interface level
            
            .. attribute:: admin_status
            
            	[adapted from IETF interfaces model (RFC 7223)]  The desired state of the interface.  In RFC 7223 this leaf has the same read semantics as ifAdminStatus.  Here, it reflects the administrative state as set by enabling or disabling the interface
            	**type**\:   :py:class:`AdminStatusEnum <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.State.AdminStatusEnum>`
            
            	**config**\: False
            
            .. attribute:: counters
            
            	A collection of interface\-related statistics objects
            	**type**\:   :py:class:`Counters <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.State.Counters>`
            
            	**config**\: False
            
            .. attribute:: description
            
            	[adapted from IETF interfaces model (RFC 7223)]  A textual description of the interface.  A server implementation MAY map this leaf to the ifAlias MIB object.  Such an implementation needs to use some mechanism to handle the differences in size and characters allowed between this leaf and ifAlias.  The definition of such a mechanism is outside the scope of this document.  Since ifAlias is defined to be stored in non\-volatile storage, the MIB implementation MUST map ifAlias to the value of 'description' in the persistently stored datastore.  Specifically, if the device supports '\:startup', when ifAlias is read the device MUST return the value of 'description' in the 'startup' datastore, and when it is written, it MUST be written to the 'running' and 'startup' datastores.  Note that it is up to the implementation to  decide whether to modify this single leaf in 'startup' or perform an implicit copy\-config from 'running' to 'startup'.  If the device does not support '\:startup', ifAlias MUST be mapped to the 'description' leaf in the 'running' datastore
            	**type**\:  str
            
            	**config**\: False
            
            .. attribute:: enabled
            
            	[adapted from IETF interfaces model (RFC 7223)]  This leaf contains the configured, desired state of the interface.  Systems that implement the IF\-MIB use the value of this leaf in the 'running' datastore to set IF\-MIB.ifAdminStatus to 'up' or 'down' after an ifEntry has been initialized, as described in RFC 2863.  Changes in this leaf in the 'running' datastore are reflected in ifAdminStatus, but if ifAdminStatus is changed over SNMP, this leaf is not affected
            	**type**\:  bool
            
            	**config**\: False
            
            	**default value**\: true
            
            .. attribute:: ifindex
            
            	System assigned number for each interface.  Corresponds to ifIndex object in SNMP Interface MIB
            	**type**\:  int
            
            	**range:** 0..4294967295
            
            	**config**\: False
            
            .. attribute:: last_change
            
            	Date and time of the last state change of the interface (e.g., up\-to\-down transition).   This corresponds to the ifLastChange object in the standard interface MIB
            	**type**\:  int
            
            	**range:** 0..4294967295
            
            	**config**\: False
            
            .. attribute:: mtu
            
            	Set the max transmission unit size in octets for the physical interface.  If this is not set, the mtu is set to the operational default \-\- e.g., 1514 bytes on an Ethernet interface
            	**type**\:  int
            
            	**range:** 0..65535
            
            	**config**\: False
            
            .. attribute:: name
            
            	[adapted from IETF interfaces model (RFC 7223)]  The name of the interface.  A device MAY restrict the allowed values for this leaf, possibly depending on the type of the interface. For system\-controlled interfaces, this leaf is the device\-specific name of the interface.  The 'config false' list interfaces/interface[name]/state contains the currently existing interfaces on the device.  If a client tries to create configuration for a system\-controlled interface that is not present in the corresponding state list, the server MAY reject the request if the implementation does not support pre\-provisioning of interfaces or if the name refers to an interface that can never exist in the system.  A NETCONF server MUST reply with an rpc\-error with the error\-tag 'invalid\-value' in this case.  The IETF model in RFC 7223 provides YANG features for the following (i.e., pre\-provisioning and arbitrary\-names), however they are omitted here\:   If the device supports pre\-provisioning of interface  configuration, the 'pre\-provisioning' feature is  advertised.   If the device allows arbitrarily named user\-controlled  interfaces, the 'arbitrary\-names' feature is advertised.  When a configured user\-controlled interface is created by the system, it is instantiated with the same name in the /interfaces/interface[name]/state list
            	**type**\:  str
            
            	**config**\: False
            
            .. attribute:: oper_status
            
            	[adapted from IETF interfaces model (RFC 7223)]  The current operational state of the interface.  This leaf has the same semantics as ifOperStatus
            	**type**\:   :py:class:`OperStatusEnum <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.State.OperStatusEnum>`
            
            	**config**\: False
            
            .. attribute:: type
            
            	[adapted from IETF interfaces model (RFC 7223)]  The type of the interface.  When an interface entry is created, a server MAY initialize the type leaf with a valid value, e.g., if it is possible to derive the type from the name of the interface.  If a client tries to set the type of an interface to a value that can never be used by the system, e.g., if the type is not supported or if the type does not match the name of the interface, the server MUST reject the request. A NETCONF server MUST reply with an rpc\-error with the error\-tag 'invalid\-value' in this case
            	**type**\:   :py:class:`InterfaceTypeIdentity <ydk.models.ydktest.ietf_interfaces.InterfaceTypeIdentity>`
            
            	**config**\: False
            
            

            """

            _prefix = 'oc-if'
            _revision = '2016-05-26'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.admin_status = None
                self.counters = Interfaces.Interface.State.Counters()
                self.counters.parent = self
                self.description = None
                self.enabled = None
                self.ifindex = None
                self.last_change = None
                self.mtu = None
                self.name = None
                self.oper_status = None
                self.type = None

            class AdminStatusEnum(Enum):
                """
                AdminStatusEnum

                [adapted from IETF interfaces model (RFC 7223)]

                The desired state of the interface.  In RFC 7223 this leaf

                has the same read semantics as ifAdminStatus.  Here, it

                reflects the administrative state as set by enabling or

                disabling the interface.

                .. data:: UP = 0

                	Ready to pass packets.

                .. data:: DOWN = 1

                	Not ready to pass packets and not in some test mode.

                .. data:: TESTING = 2

                	In some test mode.

                """

                UP = 0

                DOWN = 1

                TESTING = 2


                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                    return meta._meta_table['Interfaces.Interface.State.AdminStatusEnum']


            class OperStatusEnum(Enum):
                """
                OperStatusEnum

                [adapted from IETF interfaces model (RFC 7223)]

                The current operational state of the interface.

                This leaf has the same semantics as ifOperStatus.

                .. data:: UP = 1

                	Ready to pass packets.

                .. data:: DOWN = 2

                	The interface does not pass any packets.

                .. data:: TESTING = 3

                	In some test mode.  No operational packets can

                	be passed.

                .. data:: UNKNOWN = 4

                	Status cannot be determined for some reason.

                .. data:: DORMANT = 5

                	Waiting for some external event.

                .. data:: NOT_PRESENT = 6

                	Some component (typically hardware) is missing.

                .. data:: LOWER_LAYER_DOWN = 7

                	Down due to state of lower-layer interface(s).

                """

                UP = 1

                DOWN = 2

                TESTING = 3

                UNKNOWN = 4

                DORMANT = 5

                NOT_PRESENT = 6

                LOWER_LAYER_DOWN = 7


                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                    return meta._meta_table['Interfaces.Interface.State.OperStatusEnum']



            class Counters(object):
                """
                A collection of interface\-related statistics objects.
                
                .. attribute:: in_broadcast_pkts
                
                	[adapted from IETF interfaces model (RFC 7223)]  The number of packets, delivered by this sub\-layer to a higher (sub\-)layer, that were addressed to a broadcast address at this sub\-layer.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                	**type**\:  int
                
                	**range:** 0..18446744073709551615
                
                	**config**\: False
                
                .. attribute:: in_discards
                
                	[adapted from IETF interfaces model (RFC 7223)] Changed the counter type to counter64.  The number of inbound packets that were chosen to be discarded even though no errors had been detected to prevent their being deliverable to a higher\-layer protocol.  One possible reason for discarding such a packet could be to free up buffer space.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                	**type**\:  int
                
                	**range:** 0..18446744073709551615
                
                	**config**\: False
                
                .. attribute:: in_errors
                
                	[adapted from IETF interfaces model (RFC 7223)] Changed the counter type to counter64.  For packet\-oriented interfaces, the number of inbound packets that contained errors preventing them from being deliverable to a higher\-layer protocol.  For character\- oriented or fixed\-length interfaces, the number of inbound transmission units that contained errors preventing them from being deliverable to a higher\-layer protocol.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                	**type**\:  int
                
                	**range:** 0..18446744073709551615
                
                	**config**\: False
                
                .. attribute:: in_multicast_pkts
                
                	[adapted from IETF interfaces model (RFC 7223)]   The number of packets, delivered by this sub\-layer to a higher (sub\-)layer, that were addressed to a multicast address at this sub\-layer.  For a MAC\-layer protocol, this includes both Group and Functional addresses.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                	**type**\:  int
                
                	**range:** 0..18446744073709551615
                
                	**config**\: False
                
                .. attribute:: in_octets
                
                	[adapted from IETF interfaces model (RFC 7223)]  The total number of octets received on the interface, including framing characters.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                	**type**\:  int
                
                	**range:** 0..18446744073709551615
                
                	**config**\: False
                
                .. attribute:: in_unicast_pkts
                
                	[adapted from IETF interfaces model (RFC 7223)]  The number of packets, delivered by this sub\-layer to a higher (sub\-)layer, that were not addressed to a multicast or broadcast address at this sub\-layer.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                	**type**\:  int
                
                	**range:** 0..18446744073709551615
                
                	**config**\: False
                
                .. attribute:: in_unknown_protos
                
                	[adapted from IETF interfaces model (RFC 7223)] Changed the counter type to counter64.  For packet\-oriented interfaces, the number of packets received via the interface that were discarded because of an unknown or unsupported protocol.  For character\-oriented or fixed\-length interfaces that support protocol multiplexing, the number of transmission units received via the interface that were discarded because of an unknown or unsupported protocol. For any interface that does not support protocol multiplexing, this counter is not present.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                	**type**\:  int
                
                	**range:** 0..4294967295
                
                	**config**\: False
                
                .. attribute:: last_clear
                
                	Indicates the last time the interface counters were cleared
                	**type**\:  str
                
                	**pattern:** \\d{4}\-\\d{2}\-\\d{2}T\\d{2}\:\\d{2}\:\\d{2}(\\.\\d+)?(Z\|[\\+\\\-]\\d{2}\:\\d{2})
                
                	**config**\: False
                
                .. attribute:: out_broadcast_pkts
                
                	[adapted from IETF interfaces model (RFC 7223)]  The total number of packets that higher\-level protocols requested be transmitted, and that were addressed to a broadcast address at this sub\-layer, including those that were discarded or not sent.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                	**type**\:  int
                
                	**range:** 0..18446744073709551615
                
                	**config**\: False
                
                .. attribute:: out_discards
                
                	[adapted from IETF interfaces model (RFC 7223)] Changed the counter type to counter64.  The number of outbound packets that were chosen to be discarded even though no errors had been detected to prevent their being transmitted.  One possible reason for discarding such a packet could be to free up buffer space.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                	**type**\:  int
                
                	**range:** 0..18446744073709551615
                
                	**config**\: False
                
                .. attribute:: out_errors
                
                	[adapted from IETF interfaces model (RFC 7223)] Changed the counter type to counter64.  For packet\-oriented interfaces, the number of outbound packets that could not be transmitted because of errors. For character\-oriented or fixed\-length interfaces, the number of outbound transmission units that could not be transmitted because of errors.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                	**type**\:  int
                
                	**range:** 0..18446744073709551615
                
                	**config**\: False
                
                .. attribute:: out_multicast_pkts
                
                	[adapted from IETF interfaces model (RFC 7223)] Changed the counter type to counter64.  The total number of packets that higher\-level protocols requested be transmitted, and that were addressed to a multicast address at this sub\-layer, including those that were discarded or not sent.  For a MAC\-layer protocol, this includes both Group and Functional addresses.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                	**type**\:  int
                
                	**range:** 0..18446744073709551615
                
                	**config**\: False
                
                .. attribute:: out_octets
                
                	[adapted from IETF interfaces model (RFC 7223)] Changed the counter type to counter64.  The total number of octets transmitted out of the interface, including framing characters.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                	**type**\:  int
                
                	**range:** 0..18446744073709551615
                
                	**config**\: False
                
                .. attribute:: out_unicast_pkts
                
                	[adapted from IETF interfaces model (RFC 7223)]  The total number of packets that higher\-level protocols requested be transmitted, and that were not addressed to a multicast or broadcast address at this sub\-layer, including those that were discarded or not sent.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                	**type**\:  int
                
                	**range:** 0..18446744073709551615
                
                	**config**\: False
                
                

                """

                _prefix = 'oc-if'
                _revision = '2016-05-26'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = []

                    self.in_broadcast_pkts = None
                    self.in_discards = None
                    self.in_errors = None
                    self.in_multicast_pkts = None
                    self.in_octets = None
                    self.in_unicast_pkts = None
                    self.in_unknown_protos = None
                    self.last_clear = None
                    self.out_broadcast_pkts = None
                    self.out_discards = None
                    self.out_errors = None
                    self.out_multicast_pkts = None
                    self.out_octets = None
                    self.out_unicast_pkts = None

                @property
                def _common_path(self):
                    if self.parent is None:
                        raise YPYModelError('parent is not set . Cannot derive path.')

                    return self.parent._common_path +'/openconfig-interfaces:counters'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return False

                def _has_data(self):
                    if self.in_broadcast_pkts is not None:
                        return True

                    if self.in_discards is not None:
                        return True

                    if self.in_errors is not None:
                        return True

                    if self.in_multicast_pkts is not None:
                        return True

                    if self.in_octets is not None:
                        return True

                    if self.in_unicast_pkts is not None:
                        return True

                    if self.in_unknown_protos is not None:
                        return True

                    if self.last_clear is not None:
                        return True

                    if self.out_broadcast_pkts is not None:
                        return True

                    if self.out_discards is not None:
                        return True

                    if self.out_errors is not None:
                        return True

                    if self.out_multicast_pkts is not None:
                        return True

                    if self.out_octets is not None:
                        return True

                    if self.out_unicast_pkts is not None:
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                    return meta._meta_table['Interfaces.Interface.State.Counters']['meta_info']

            @property
            def _common_path(self):
                if self.parent is None:
                    raise YPYModelError('parent is not set . Cannot derive path.')

                return self.parent._common_path +'/openconfig-interfaces:state'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return False

            def _has_data(self):
                if self.admin_status is not None:
                    return True

                if self.counters is not None and self.counters._has_data():
                    return True

                if self.description is not None:
                    return True

                if self.enabled is not None:
                    return True

                if self.ifindex is not None:
                    return True

                if self.last_change is not None:
                    return True

                if self.mtu is not None:
                    return True

                if self.name is not None:
                    return True

                if self.oper_status is not None:
                    return True

                if self.type is not None:
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                return meta._meta_table['Interfaces.Interface.State']['meta_info']


        class HoldTime(object):
            """
            Top\-level container for hold\-time settings to enable
            dampening advertisements of interface transitions.
            
            .. attribute:: config
            
            	Configuration data for interface hold\-time settings
            	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.HoldTime.Config>`
            
            .. attribute:: state
            
            	Operational state data for interface hold\-time
            	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.HoldTime.State>`
            
            	**config**\: False
            
            

            """

            _prefix = 'oc-if'
            _revision = '2016-05-26'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.config = Interfaces.Interface.HoldTime.Config()
                self.config.parent = self
                self.state = Interfaces.Interface.HoldTime.State()
                self.state.parent = self


            class Config(object):
                """
                Configuration data for interface hold\-time settings.
                
                .. attribute:: down
                
                	Dampens advertisement when the interface transitions from up to down.  A zero value means dampening is turned off, i.e., immediate notification
                	**type**\:  int
                
                	**range:** 0..4294967295
                
                	**units**\: milliseconds
                
                	**default value**\: 0
                
                .. attribute:: up
                
                	Dampens advertisement when the interface transitions from down to up.  A zero value means dampening is turned off, i.e., immediate notification
                	**type**\:  int
                
                	**range:** 0..4294967295
                
                	**units**\: milliseconds
                
                	**default value**\: 0
                
                

                """

                _prefix = 'oc-if'
                _revision = '2016-05-26'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = []

                    self.down = None
                    self.up = None

                @property
                def _common_path(self):
                    if self.parent is None:
                        raise YPYModelError('parent is not set . Cannot derive path.')

                    return self.parent._common_path +'/openconfig-interfaces:config'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.down is not None:
                        return True

                    if self.up is not None:
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                    return meta._meta_table['Interfaces.Interface.HoldTime.Config']['meta_info']


            class State(object):
                """
                Operational state data for interface hold\-time.
                
                .. attribute:: down
                
                	Dampens advertisement when the interface transitions from up to down.  A zero value means dampening is turned off, i.e., immediate notification
                	**type**\:  int
                
                	**range:** 0..4294967295
                
                	**config**\: False
                
                	**units**\: milliseconds
                
                	**default value**\: 0
                
                .. attribute:: up
                
                	Dampens advertisement when the interface transitions from down to up.  A zero value means dampening is turned off, i.e., immediate notification
                	**type**\:  int
                
                	**range:** 0..4294967295
                
                	**config**\: False
                
                	**units**\: milliseconds
                
                	**default value**\: 0
                
                

                """

                _prefix = 'oc-if'
                _revision = '2016-05-26'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = []

                    self.down = None
                    self.up = None

                @property
                def _common_path(self):
                    if self.parent is None:
                        raise YPYModelError('parent is not set . Cannot derive path.')

                    return self.parent._common_path +'/openconfig-interfaces:state'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return False

                def _has_data(self):
                    if self.down is not None:
                        return True

                    if self.up is not None:
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                    return meta._meta_table['Interfaces.Interface.HoldTime.State']['meta_info']

            @property
            def _common_path(self):
                if self.parent is None:
                    raise YPYModelError('parent is not set . Cannot derive path.')

                return self.parent._common_path +'/openconfig-interfaces:hold-time'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.config is not None and self.config._has_data():
                    return True

                if self.state is not None and self.state._has_data():
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                return meta._meta_table['Interfaces.Interface.HoldTime']['meta_info']


        class Subinterfaces(object):
            """
            Enclosing container for the list of subinterfaces associated
            with a physical interface
            
            .. attribute:: subinterface
            
            	The list of subinterfaces (logical interfaces) associated with a physical interface
            	**type**\: list of    :py:class:`Subinterface <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.Subinterfaces.Subinterface>`
            
            

            """

            _prefix = 'oc-if'
            _revision = '2016-05-26'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.subinterface = YList()
                self.subinterface.parent = self
                self.subinterface.name = 'subinterface'


            class Subinterface(object):
                """
                The list of subinterfaces (logical interfaces) associated
                with a physical interface
                
                .. attribute:: index  <key>
                
                	The index number of the subinterface \-\- used to address the logical interface
                	**type**\:  int
                
                	**range:** 0..4294967295
                
                	**refers to**\:  :py:class:`index <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.Subinterfaces.Subinterface.Config>`
                
                .. attribute:: config
                
                	Configurable items at the subinterface level
                	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.Subinterfaces.Subinterface.Config>`
                
                .. attribute:: state
                
                	Operational state data for logical interfaces
                	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.Subinterfaces.Subinterface.State>`
                
                	**config**\: False
                
                

                """

                _prefix = 'oc-if'
                _revision = '2016-05-26'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = ['index']

                    self.index = None
                    self.config = Interfaces.Interface.Subinterfaces.Subinterface.Config()
                    self.config.parent = self
                    self.state = Interfaces.Interface.Subinterfaces.Subinterface.State()
                    self.state.parent = self


                class Config(object):
                    """
                    Configurable items at the subinterface level
                    
                    .. attribute:: description
                    
                    	[adapted from IETF interfaces model (RFC 7223)]  A textual description of the interface.  A server implementation MAY map this leaf to the ifAlias MIB object.  Such an implementation needs to use some mechanism to handle the differences in size and characters allowed between this leaf and ifAlias.  The definition of such a mechanism is outside the scope of this document.  Since ifAlias is defined to be stored in non\-volatile storage, the MIB implementation MUST map ifAlias to the value of 'description' in the persistently stored datastore.  Specifically, if the device supports '\:startup', when ifAlias is read the device MUST return the value of 'description' in the 'startup' datastore, and when it is written, it MUST be written to the 'running' and 'startup' datastores.  Note that it is up to the implementation to  decide whether to modify this single leaf in 'startup' or perform an implicit copy\-config from 'running' to 'startup'.  If the device does not support '\:startup', ifAlias MUST be mapped to the 'description' leaf in the 'running' datastore
                    	**type**\:  str
                    
                    .. attribute:: enabled
                    
                    	[adapted from IETF interfaces model (RFC 7223)]  This leaf contains the configured, desired state of the interface.  Systems that implement the IF\-MIB use the value of this leaf in the 'running' datastore to set IF\-MIB.ifAdminStatus to 'up' or 'down' after an ifEntry has been initialized, as described in RFC 2863.  Changes in this leaf in the 'running' datastore are reflected in ifAdminStatus, but if ifAdminStatus is changed over SNMP, this leaf is not affected
                    	**type**\:  bool
                    
                    	**default value**\: true
                    
                    .. attribute:: index
                    
                    	The index of the subinterface, or logical interface number. On systems with no support for subinterfaces, or not using subinterfaces, this value should default to 0, i.e., the default subinterface
                    	**type**\:  int
                    
                    	**range:** 0..4294967295
                    
                    	**default value**\: 0
                    
                    .. attribute:: name
                    
                    	[adapted from IETF interfaces model (RFC 7223)]  The name of the interface.  A device MAY restrict the allowed values for this leaf, possibly depending on the type of the interface. For system\-controlled interfaces, this leaf is the device\-specific name of the interface.  The 'config false' list interfaces/interface[name]/state contains the currently existing interfaces on the device.  If a client tries to create configuration for a system\-controlled interface that is not present in the corresponding state list, the server MAY reject the request if the implementation does not support pre\-provisioning of interfaces or if the name refers to an interface that can never exist in the system.  A NETCONF server MUST reply with an rpc\-error with the error\-tag 'invalid\-value' in this case.  The IETF model in RFC 7223 provides YANG features for the following (i.e., pre\-provisioning and arbitrary\-names), however they are omitted here\:   If the device supports pre\-provisioning of interface  configuration, the 'pre\-provisioning' feature is  advertised.   If the device allows arbitrarily named user\-controlled  interfaces, the 'arbitrary\-names' feature is advertised.  When a configured user\-controlled interface is created by the system, it is instantiated with the same name in the /interfaces/interface[name]/state list
                    	**type**\:  str
                    
                    

                    """

                    _prefix = 'oc-if'
                    _revision = '2016-05-26'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = []

                        self.description = None
                        self.enabled = None
                        self.index = None
                        self.name = None

                    @property
                    def _common_path(self):
                        if self.parent is None:
                            raise YPYModelError('parent is not set . Cannot derive path.')

                        return self.parent._common_path +'/openconfig-interfaces:config'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return True

                    def _has_data(self):
                        if self.description is not None:
                            return True

                        if self.enabled is not None:
                            return True

                        if self.index is not None:
                            return True

                        if self.name is not None:
                            return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                        return meta._meta_table['Interfaces.Interface.Subinterfaces.Subinterface.Config']['meta_info']


                class State(object):
                    """
                    Operational state data for logical interfaces
                    
                    .. attribute:: admin_status
                    
                    	[adapted from IETF interfaces model (RFC 7223)]  The desired state of the interface.  In RFC 7223 this leaf has the same read semantics as ifAdminStatus.  Here, it reflects the administrative state as set by enabling or disabling the interface
                    	**type**\:   :py:class:`AdminStatusEnum <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.Subinterfaces.Subinterface.State.AdminStatusEnum>`
                    
                    	**config**\: False
                    
                    .. attribute:: counters
                    
                    	A collection of interface\-related statistics objects
                    	**type**\:   :py:class:`Counters <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.Subinterfaces.Subinterface.State.Counters>`
                    
                    	**config**\: False
                    
                    .. attribute:: description
                    
                    	[adapted from IETF interfaces model (RFC 7223)]  A textual description of the interface.  A server implementation MAY map this leaf to the ifAlias MIB object.  Such an implementation needs to use some mechanism to handle the differences in size and characters allowed between this leaf and ifAlias.  The definition of such a mechanism is outside the scope of this document.  Since ifAlias is defined to be stored in non\-volatile storage, the MIB implementation MUST map ifAlias to the value of 'description' in the persistently stored datastore.  Specifically, if the device supports '\:startup', when ifAlias is read the device MUST return the value of 'description' in the 'startup' datastore, and when it is written, it MUST be written to the 'running' and 'startup' datastores.  Note that it is up to the implementation to  decide whether to modify this single leaf in 'startup' or perform an implicit copy\-config from 'running' to 'startup'.  If the device does not support '\:startup', ifAlias MUST be mapped to the 'description' leaf in the 'running' datastore
                    	**type**\:  str
                    
                    	**config**\: False
                    
                    .. attribute:: enabled
                    
                    	[adapted from IETF interfaces model (RFC 7223)]  This leaf contains the configured, desired state of the interface.  Systems that implement the IF\-MIB use the value of this leaf in the 'running' datastore to set IF\-MIB.ifAdminStatus to 'up' or 'down' after an ifEntry has been initialized, as described in RFC 2863.  Changes in this leaf in the 'running' datastore are reflected in ifAdminStatus, but if ifAdminStatus is changed over SNMP, this leaf is not affected
                    	**type**\:  bool
                    
                    	**config**\: False
                    
                    	**default value**\: true
                    
                    .. attribute:: ifindex
                    
                    	System assigned number for each interface.  Corresponds to ifIndex object in SNMP Interface MIB
                    	**type**\:  int
                    
                    	**range:** 0..4294967295
                    
                    	**config**\: False
                    
                    .. attribute:: index
                    
                    	The index of the subinterface, or logical interface number. On systems with no support for subinterfaces, or not using subinterfaces, this value should default to 0, i.e., the default subinterface
                    	**type**\:  int
                    
                    	**range:** 0..4294967295
                    
                    	**config**\: False
                    
                    	**default value**\: 0
                    
                    .. attribute:: last_change
                    
                    	Date and time of the last state change of the interface (e.g., up\-to\-down transition).   This corresponds to the ifLastChange object in the standard interface MIB
                    	**type**\:  int
                    
                    	**range:** 0..4294967295
                    
                    	**config**\: False
                    
                    .. attribute:: name
                    
                    	[adapted from IETF interfaces model (RFC 7223)]  The name of the interface.  A device MAY restrict the allowed values for this leaf, possibly depending on the type of the interface. For system\-controlled interfaces, this leaf is the device\-specific name of the interface.  The 'config false' list interfaces/interface[name]/state contains the currently existing interfaces on the device.  If a client tries to create configuration for a system\-controlled interface that is not present in the corresponding state list, the server MAY reject the request if the implementation does not support pre\-provisioning of interfaces or if the name refers to an interface that can never exist in the system.  A NETCONF server MUST reply with an rpc\-error with the error\-tag 'invalid\-value' in this case.  The IETF model in RFC 7223 provides YANG features for the following (i.e., pre\-provisioning and arbitrary\-names), however they are omitted here\:   If the device supports pre\-provisioning of interface  configuration, the 'pre\-provisioning' feature is  advertised.   If the device allows arbitrarily named user\-controlled  interfaces, the 'arbitrary\-names' feature is advertised.  When a configured user\-controlled interface is created by the system, it is instantiated with the same name in the /interfaces/interface[name]/state list
                    	**type**\:  str
                    
                    	**config**\: False
                    
                    .. attribute:: oper_status
                    
                    	[adapted from IETF interfaces model (RFC 7223)]  The current operational state of the interface.  This leaf has the same semantics as ifOperStatus
                    	**type**\:   :py:class:`OperStatusEnum <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.Subinterfaces.Subinterface.State.OperStatusEnum>`
                    
                    	**config**\: False
                    
                    

                    """

                    _prefix = 'oc-if'
                    _revision = '2016-05-26'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = []

                        self.admin_status = None
                        self.counters = Interfaces.Interface.Subinterfaces.Subinterface.State.Counters()
                        self.counters.parent = self
                        self.description = None
                        self.enabled = None
                        self.ifindex = None
                        self.index = None
                        self.last_change = None
                        self.name = None
                        self.oper_status = None

                    class AdminStatusEnum(Enum):
                        """
                        AdminStatusEnum

                        [adapted from IETF interfaces model (RFC 7223)]

                        The desired state of the interface.  In RFC 7223 this leaf

                        has the same read semantics as ifAdminStatus.  Here, it

                        reflects the administrative state as set by enabling or

                        disabling the interface.

                        .. data:: UP = 0

                        	Ready to pass packets.

                        .. data:: DOWN = 1

                        	Not ready to pass packets and not in some test mode.

                        .. data:: TESTING = 2

                        	In some test mode.

                        """

                        UP = 0

                        DOWN = 1

                        TESTING = 2


                        @staticmethod
                        def _meta_info():
                            from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                            return meta._meta_table['Interfaces.Interface.Subinterfaces.Subinterface.State.AdminStatusEnum']


                    class OperStatusEnum(Enum):
                        """
                        OperStatusEnum

                        [adapted from IETF interfaces model (RFC 7223)]

                        The current operational state of the interface.

                        This leaf has the same semantics as ifOperStatus.

                        .. data:: UP = 1

                        	Ready to pass packets.

                        .. data:: DOWN = 2

                        	The interface does not pass any packets.

                        .. data:: TESTING = 3

                        	In some test mode.  No operational packets can

                        	be passed.

                        .. data:: UNKNOWN = 4

                        	Status cannot be determined for some reason.

                        .. data:: DORMANT = 5

                        	Waiting for some external event.

                        .. data:: NOT_PRESENT = 6

                        	Some component (typically hardware) is missing.

                        .. data:: LOWER_LAYER_DOWN = 7

                        	Down due to state of lower-layer interface(s).

                        """

                        UP = 1

                        DOWN = 2

                        TESTING = 3

                        UNKNOWN = 4

                        DORMANT = 5

                        NOT_PRESENT = 6

                        LOWER_LAYER_DOWN = 7


                        @staticmethod
                        def _meta_info():
                            from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                            return meta._meta_table['Interfaces.Interface.Subinterfaces.Subinterface.State.OperStatusEnum']



                    class Counters(object):
                        """
                        A collection of interface\-related statistics objects.
                        
                        .. attribute:: in_broadcast_pkts
                        
                        	[adapted from IETF interfaces model (RFC 7223)]  The number of packets, delivered by this sub\-layer to a higher (sub\-)layer, that were addressed to a broadcast address at this sub\-layer.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                        	**type**\:  int
                        
                        	**range:** 0..18446744073709551615
                        
                        	**config**\: False
                        
                        .. attribute:: in_discards
                        
                        	[adapted from IETF interfaces model (RFC 7223)] Changed the counter type to counter64.  The number of inbound packets that were chosen to be discarded even though no errors had been detected to prevent their being deliverable to a higher\-layer protocol.  One possible reason for discarding such a packet could be to free up buffer space.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                        	**type**\:  int
                        
                        	**range:** 0..18446744073709551615
                        
                        	**config**\: False
                        
                        .. attribute:: in_errors
                        
                        	[adapted from IETF interfaces model (RFC 7223)] Changed the counter type to counter64.  For packet\-oriented interfaces, the number of inbound packets that contained errors preventing them from being deliverable to a higher\-layer protocol.  For character\- oriented or fixed\-length interfaces, the number of inbound transmission units that contained errors preventing them from being deliverable to a higher\-layer protocol.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                        	**type**\:  int
                        
                        	**range:** 0..18446744073709551615
                        
                        	**config**\: False
                        
                        .. attribute:: in_multicast_pkts
                        
                        	[adapted from IETF interfaces model (RFC 7223)]   The number of packets, delivered by this sub\-layer to a higher (sub\-)layer, that were addressed to a multicast address at this sub\-layer.  For a MAC\-layer protocol, this includes both Group and Functional addresses.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                        	**type**\:  int
                        
                        	**range:** 0..18446744073709551615
                        
                        	**config**\: False
                        
                        .. attribute:: in_octets
                        
                        	[adapted from IETF interfaces model (RFC 7223)]  The total number of octets received on the interface, including framing characters.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                        	**type**\:  int
                        
                        	**range:** 0..18446744073709551615
                        
                        	**config**\: False
                        
                        .. attribute:: in_unicast_pkts
                        
                        	[adapted from IETF interfaces model (RFC 7223)]  The number of packets, delivered by this sub\-layer to a higher (sub\-)layer, that were not addressed to a multicast or broadcast address at this sub\-layer.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                        	**type**\:  int
                        
                        	**range:** 0..18446744073709551615
                        
                        	**config**\: False
                        
                        .. attribute:: in_unknown_protos
                        
                        	[adapted from IETF interfaces model (RFC 7223)] Changed the counter type to counter64.  For packet\-oriented interfaces, the number of packets received via the interface that were discarded because of an unknown or unsupported protocol.  For character\-oriented or fixed\-length interfaces that support protocol multiplexing, the number of transmission units received via the interface that were discarded because of an unknown or unsupported protocol. For any interface that does not support protocol multiplexing, this counter is not present.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                        	**type**\:  int
                        
                        	**range:** 0..4294967295
                        
                        	**config**\: False
                        
                        .. attribute:: last_clear
                        
                        	Indicates the last time the interface counters were cleared
                        	**type**\:  str
                        
                        	**pattern:** \\d{4}\-\\d{2}\-\\d{2}T\\d{2}\:\\d{2}\:\\d{2}(\\.\\d+)?(Z\|[\\+\\\-]\\d{2}\:\\d{2})
                        
                        	**config**\: False
                        
                        .. attribute:: out_broadcast_pkts
                        
                        	[adapted from IETF interfaces model (RFC 7223)]  The total number of packets that higher\-level protocols requested be transmitted, and that were addressed to a broadcast address at this sub\-layer, including those that were discarded or not sent.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                        	**type**\:  int
                        
                        	**range:** 0..18446744073709551615
                        
                        	**config**\: False
                        
                        .. attribute:: out_discards
                        
                        	[adapted from IETF interfaces model (RFC 7223)] Changed the counter type to counter64.  The number of outbound packets that were chosen to be discarded even though no errors had been detected to prevent their being transmitted.  One possible reason for discarding such a packet could be to free up buffer space.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                        	**type**\:  int
                        
                        	**range:** 0..18446744073709551615
                        
                        	**config**\: False
                        
                        .. attribute:: out_errors
                        
                        	[adapted from IETF interfaces model (RFC 7223)] Changed the counter type to counter64.  For packet\-oriented interfaces, the number of outbound packets that could not be transmitted because of errors. For character\-oriented or fixed\-length interfaces, the number of outbound transmission units that could not be transmitted because of errors.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                        	**type**\:  int
                        
                        	**range:** 0..18446744073709551615
                        
                        	**config**\: False
                        
                        .. attribute:: out_multicast_pkts
                        
                        	[adapted from IETF interfaces model (RFC 7223)] Changed the counter type to counter64.  The total number of packets that higher\-level protocols requested be transmitted, and that were addressed to a multicast address at this sub\-layer, including those that were discarded or not sent.  For a MAC\-layer protocol, this includes both Group and Functional addresses.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                        	**type**\:  int
                        
                        	**range:** 0..18446744073709551615
                        
                        	**config**\: False
                        
                        .. attribute:: out_octets
                        
                        	[adapted from IETF interfaces model (RFC 7223)] Changed the counter type to counter64.  The total number of octets transmitted out of the interface, including framing characters.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                        	**type**\:  int
                        
                        	**range:** 0..18446744073709551615
                        
                        	**config**\: False
                        
                        .. attribute:: out_unicast_pkts
                        
                        	[adapted from IETF interfaces model (RFC 7223)]  The total number of packets that higher\-level protocols requested be transmitted, and that were not addressed to a multicast or broadcast address at this sub\-layer, including those that were discarded or not sent.  Discontinuities in the value of this counter can occur at re\-initialization of the management system, and at other times as indicated by the value of 'discontinuity\-time'
                        	**type**\:  int
                        
                        	**range:** 0..18446744073709551615
                        
                        	**config**\: False
                        
                        

                        """

                        _prefix = 'oc-if'
                        _revision = '2016-05-26'

                        def __init__(self):
                            self.parent = None
                            self.ylist_key_names = []

                            self.in_broadcast_pkts = None
                            self.in_discards = None
                            self.in_errors = None
                            self.in_multicast_pkts = None
                            self.in_octets = None
                            self.in_unicast_pkts = None
                            self.in_unknown_protos = None
                            self.last_clear = None
                            self.out_broadcast_pkts = None
                            self.out_discards = None
                            self.out_errors = None
                            self.out_multicast_pkts = None
                            self.out_octets = None
                            self.out_unicast_pkts = None

                        @property
                        def _common_path(self):
                            if self.parent is None:
                                raise YPYModelError('parent is not set . Cannot derive path.')

                            return self.parent._common_path +'/openconfig-interfaces:counters'

                        def is_config(self):
                            ''' Returns True if this instance represents config data else returns False '''
                            return False

                        def _has_data(self):
                            if self.in_broadcast_pkts is not None:
                                return True

                            if self.in_discards is not None:
                                return True

                            if self.in_errors is not None:
                                return True

                            if self.in_multicast_pkts is not None:
                                return True

                            if self.in_octets is not None:
                                return True

                            if self.in_unicast_pkts is not None:
                                return True

                            if self.in_unknown_protos is not None:
                                return True

                            if self.last_clear is not None:
                                return True

                            if self.out_broadcast_pkts is not None:
                                return True

                            if self.out_discards is not None:
                                return True

                            if self.out_errors is not None:
                                return True

                            if self.out_multicast_pkts is not None:
                                return True

                            if self.out_octets is not None:
                                return True

                            if self.out_unicast_pkts is not None:
                                return True

                            return False

                        @staticmethod
                        def _meta_info():
                            from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                            return meta._meta_table['Interfaces.Interface.Subinterfaces.Subinterface.State.Counters']['meta_info']

                    @property
                    def _common_path(self):
                        if self.parent is None:
                            raise YPYModelError('parent is not set . Cannot derive path.')

                        return self.parent._common_path +'/openconfig-interfaces:state'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return False

                    def _has_data(self):
                        if self.admin_status is not None:
                            return True

                        if self.counters is not None and self.counters._has_data():
                            return True

                        if self.description is not None:
                            return True

                        if self.enabled is not None:
                            return True

                        if self.ifindex is not None:
                            return True

                        if self.index is not None:
                            return True

                        if self.last_change is not None:
                            return True

                        if self.name is not None:
                            return True

                        if self.oper_status is not None:
                            return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                        return meta._meta_table['Interfaces.Interface.Subinterfaces.Subinterface.State']['meta_info']

                @property
                def _common_path(self):
                    if self.parent is None:
                        raise YPYModelError('parent is not set . Cannot derive path.')
                    if self.index is None:
                        raise YPYModelError('Key property index is None')

                    return self.parent._common_path +'/openconfig-interfaces:subinterface[openconfig-interfaces:index = ' + str(self.index) + ']'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.index is not None:
                        return True

                    if self.config is not None and self.config._has_data():
                        return True

                    if self.state is not None and self.state._has_data():
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                    return meta._meta_table['Interfaces.Interface.Subinterfaces.Subinterface']['meta_info']

            @property
            def _common_path(self):
                if self.parent is None:
                    raise YPYModelError('parent is not set . Cannot derive path.')

                return self.parent._common_path +'/openconfig-interfaces:subinterfaces'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.subinterface is not None:
                    for child_ref in self.subinterface:
                        if child_ref._has_data():
                            return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _openconfig_interfaces as meta
                return meta._meta_table['Interfaces.Interface.Subinterfaces']['meta_info']

        @property
        def _common_path(self):
            if self.name is None:
                raise YPYModelError('Key property name is None')

            return '/openconfig-interfaces:interfaces/openconfig-interfaces:interface[openconfig-interfaces:name = ' + str(self.name) + ']'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.name is not None:
                return True

            if self.config is not None and self.config._has_data():
                return True

            if self.hold_time is not None and self.hold_time._has_data():
                return True

            if self.state is not None and self.state._has_data():
                return True

            if self.subinterfaces is not None and self.subinterfaces._has_data():
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _openconfig_interfaces as meta
            return meta._meta_table['Interfaces.Interface']['meta_info']

    @property
    def _common_path(self):

        return '/openconfig-interfaces:interfaces'

    def is_config(self):
        ''' Returns True if this instance represents config data else returns False '''
        return True

    def _has_data(self):
        if self.interface is not None:
            for child_ref in self.interface:
                if child_ref._has_data():
                    return True

        return False

    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_interfaces as meta
        return meta._meta_table['Interfaces']['meta_info']


