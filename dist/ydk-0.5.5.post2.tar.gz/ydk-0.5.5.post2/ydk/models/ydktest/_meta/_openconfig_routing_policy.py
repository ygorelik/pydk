
import re
import collections

from enum import Enum

from ydk._core._dm_meta_info import _MetaInfoClassMember, _MetaInfoClass, _MetaInfoEnum
from ydk._core._dm_meta_info import ATTRIBUTE, REFERENCE_CLASS, REFERENCE_LIST, REFERENCE_LEAFLIST, ANYXML_CLASS
from ydk._core._dm_meta_info import REFERENCE_IDENTITY_CLASS, REFERENCE_ENUM_CLASS, REFERENCE_BITS, REFERENCE_UNION

from ydk.types import Empty, YList, YLeafList, DELETE, Decimal64, FixedBitsDict
from ydk.errors import YPYError, YPYModelError
from ydk.providers._importer import _yang_ns

_meta_table = {
    'DefaultPolicyTypeEnum' : _MetaInfoEnum('DefaultPolicyTypeEnum',
        'ydk.models.ydktest.openconfig_routing_policy', 'DefaultPolicyTypeEnum',
        '''type used to specify default route disposition in
a policy chain''',
        {
            'ACCEPT_ROUTE':'ACCEPT_ROUTE',
            'REJECT_ROUTE':'REJECT_ROUTE',
        }, 'openconfig-routing-policy', _yang_ns._namespaces['openconfig-routing-policy']),
    'RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Config', REFERENCE_CLASS,
            '''Configuration data for prefix sets''',
            False, 
            [
            _MetaInfoClassMember('prefix-set-name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                name / label of the prefix set -- this is used to
                reference the set in match conditions
                ''',
                'prefix_set_name',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'config',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.State', REFERENCE_CLASS,
            '''Operational state data ''',
            False, 
            [
            _MetaInfoClassMember('prefix-set-name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                name / label of the prefix set -- this is used to
                reference the set in match conditions
                ''',
                'prefix_set_name',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'state',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.Config', REFERENCE_CLASS,
            '''Configuration data for prefix definition''',
            False, 
            [
            _MetaInfoClassMember('ip-prefix', REFERENCE_UNION, 'str', 'inet:ip-prefix',
                None, None,
                [], [],
                '''                The prefix member in CIDR notation -- while the
                prefix may be either IPv4 or IPv6, most
                implementations require all members of the prefix set
                to be the same address family.  Mixing address types in
                the same prefix set is likely to cause an error.
                ''',
                'ip_prefix',
                'openconfig-routing-policy', False, [
                    _MetaInfoClassMember('ip-prefix', ATTRIBUTE, 'str', 'inet:ipv4-prefix',
                        None, None,
                        [], [b'(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])/(([0-9])|([1-2][0-9])|(3[0-2]))'],
                        '''                        The prefix member in CIDR notation -- while the
                        prefix may be either IPv4 or IPv6, most
                        implementations require all members of the prefix set
                        to be the same address family.  Mixing address types in
                        the same prefix set is likely to cause an error.
                        ''',
                        'ip_prefix',
                        'openconfig-routing-policy', False, is_mandatory=True),
                    _MetaInfoClassMember('ip-prefix', ATTRIBUTE, 'str', 'inet:ipv6-prefix',
                        None, None,
                        [], [b'((:|[0-9a-fA-F]{0,4}):)([0-9a-fA-F]{0,4}:){0,5}((([0-9a-fA-F]{0,4}:)?(:|[0-9a-fA-F]{0,4}))|(((25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])))(/(([0-9])|([0-9]{2})|(1[0-1][0-9])|(12[0-8])))'],
                        '''                        The prefix member in CIDR notation -- while the
                        prefix may be either IPv4 or IPv6, most
                        implementations require all members of the prefix set
                        to be the same address family.  Mixing address types in
                        the same prefix set is likely to cause an error.
                        ''',
                        'ip_prefix',
                        'openconfig-routing-policy', False, is_mandatory=True),
                ], is_mandatory=True),
            _MetaInfoClassMember('masklength-range', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [b'^([0-9]+\\.\\.[0-9]+)|exact$'],
                '''                Defines a range for the masklength, or 'exact' if
                the prefix has an exact length.
                
                Example: 10.3.192.0/21 through 10.3.192.0/24 would be
                expressed as prefix: 10.3.192.0/21,
                masklength-range: 21..24.
                
                Example: 10.3.192.0/21 would be expressed as
                prefix: 10.3.192.0/21,
                masklength-range: exact
                ''',
                'masklength_range',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'config',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.State', REFERENCE_CLASS,
            '''Operational state data for prefix definition''',
            False, 
            [
            _MetaInfoClassMember('ip-prefix', REFERENCE_UNION, 'str', 'inet:ip-prefix',
                None, None,
                [], [],
                '''                The prefix member in CIDR notation -- while the
                prefix may be either IPv4 or IPv6, most
                implementations require all members of the prefix set
                to be the same address family.  Mixing address types in
                the same prefix set is likely to cause an error.
                ''',
                'ip_prefix',
                'openconfig-routing-policy', False, [
                    _MetaInfoClassMember('ip-prefix', ATTRIBUTE, 'str', 'inet:ipv4-prefix',
                        None, None,
                        [], [b'(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])/(([0-9])|([1-2][0-9])|(3[0-2]))'],
                        '''                        The prefix member in CIDR notation -- while the
                        prefix may be either IPv4 or IPv6, most
                        implementations require all members of the prefix set
                        to be the same address family.  Mixing address types in
                        the same prefix set is likely to cause an error.
                        ''',
                        'ip_prefix',
                        'openconfig-routing-policy', False, is_config=False, is_mandatory=True),
                    _MetaInfoClassMember('ip-prefix', ATTRIBUTE, 'str', 'inet:ipv6-prefix',
                        None, None,
                        [], [b'((:|[0-9a-fA-F]{0,4}):)([0-9a-fA-F]{0,4}:){0,5}((([0-9a-fA-F]{0,4}:)?(:|[0-9a-fA-F]{0,4}))|(((25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])))(/(([0-9])|([0-9]{2})|(1[0-1][0-9])|(12[0-8])))'],
                        '''                        The prefix member in CIDR notation -- while the
                        prefix may be either IPv4 or IPv6, most
                        implementations require all members of the prefix set
                        to be the same address family.  Mixing address types in
                        the same prefix set is likely to cause an error.
                        ''',
                        'ip_prefix',
                        'openconfig-routing-policy', False, is_config=False, is_mandatory=True),
                ], is_config=False, is_mandatory=True),
            _MetaInfoClassMember('masklength-range', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [b'^([0-9]+\\.\\.[0-9]+)|exact$'],
                '''                Defines a range for the masklength, or 'exact' if
                the prefix has an exact length.
                
                Example: 10.3.192.0/21 through 10.3.192.0/24 would be
                expressed as prefix: 10.3.192.0/21,
                masklength-range: 21..24.
                
                Example: 10.3.192.0/21 would be expressed as
                prefix: 10.3.192.0/21,
                masklength-range: exact
                ''',
                'masklength_range',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'state',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix', REFERENCE_LIST,
            '''List of prefixes in the prefix set''',
            False, 
            [
            _MetaInfoClassMember('ip-prefix', REFERENCE_UNION, 'str', 'leafref',
                None, None,
                [], [],
                '''                Reference to the ip-prefix list key.
                ''',
                'ip_prefix',
                'openconfig-routing-policy', True, [
                    _MetaInfoClassMember('ip-prefix', ATTRIBUTE, 'str', 'inet:ipv4-prefix',
                        None, None,
                        [], [b'(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])/(([0-9])|([1-2][0-9])|(3[0-2]))'],
                        '''                        Reference to the ip-prefix list key.
                        ''',
                        'ip_prefix',
                        'openconfig-routing-policy', True),
                    _MetaInfoClassMember('ip-prefix', ATTRIBUTE, 'str', 'inet:ipv6-prefix',
                        None, None,
                        [], [b'((:|[0-9a-fA-F]{0,4}):)([0-9a-fA-F]{0,4}:){0,5}((([0-9a-fA-F]{0,4}:)?(:|[0-9a-fA-F]{0,4}))|(((25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])))(/(([0-9])|([0-9]{2})|(1[0-1][0-9])|(12[0-8])))'],
                        '''                        Reference to the ip-prefix list key.
                        ''',
                        'ip_prefix',
                        'openconfig-routing-policy', True),
                ]),
            _MetaInfoClassMember('masklength-range', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [b'^([0-9]+\\.\\.[0-9]+)|exact$'],
                '''                Reference to the masklength-range list key
                ''',
                'masklength_range',
                'openconfig-routing-policy', True),
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.Config',
                [], [],
                '''                Configuration data for prefix definition
                ''',
                'config',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.State',
                [], [],
                '''                Operational state data for prefix definition
                ''',
                'state',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'prefix',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes', REFERENCE_CLASS,
            '''Enclosing container for the list of prefixes in a policy
prefix list''',
            False, 
            [
            _MetaInfoClassMember('prefix', REFERENCE_LIST, 'Prefix', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix',
                [], [],
                '''                List of prefixes in the prefix set
                ''',
                'prefix',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'prefixes',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.PrefixSets.PrefixSet' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.PrefixSets.PrefixSet', REFERENCE_LIST,
            '''List of the defined prefix sets''',
            False, 
            [
            _MetaInfoClassMember('prefix-set-name', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                Reference to prefix name list key
                ''',
                'prefix_set_name',
                'openconfig-routing-policy', True),
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Config',
                [], [],
                '''                Configuration data for prefix sets
                ''',
                'config',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('prefixes', REFERENCE_CLASS, 'Prefixes', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes',
                [], [],
                '''                Enclosing container for the list of prefixes in a policy
                prefix list
                ''',
                'prefixes',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.State',
                [], [],
                '''                Operational state data 
                ''',
                'state',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'prefix-set',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.PrefixSets' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.PrefixSets', REFERENCE_CLASS,
            '''Enclosing container ''',
            False, 
            [
            _MetaInfoClassMember('prefix-set', REFERENCE_LIST, 'PrefixSet', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.PrefixSets.PrefixSet',
                [], [],
                '''                List of the defined prefix sets
                ''',
                'prefix_set',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'prefix-sets',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.Config', REFERENCE_CLASS,
            '''Configuration data for neighbor sets.''',
            False, 
            [
            _MetaInfoClassMember('address', REFERENCE_UNION, 'str', 'inet:ip-address-no-zone',
                None, None,
                [], [],
                '''                List of IP addresses in the neighbor set
                ''',
                'address',
                'openconfig-routing-policy', False, [
                    _MetaInfoClassMember('address', REFERENCE_LEAFLIST, 'str', 'inet:ipv4-address-no-zone',
                        None, None,
                        [], [b'(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(%[\\p{N}\\p{L}]+)?'],
                        '''                        List of IP addresses in the neighbor set
                        ''',
                        'address',
                        'openconfig-routing-policy', False),
                    _MetaInfoClassMember('address', REFERENCE_LEAFLIST, 'str', 'inet:ipv6-address-no-zone',
                        None, None,
                        [], [b'((:|[0-9a-fA-F]{0,4}):)([0-9a-fA-F]{0,4}:){0,5}((([0-9a-fA-F]{0,4}:)?(:|[0-9a-fA-F]{0,4}))|(((25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])))(%[\\p{N}\\p{L}]+)?'],
                        '''                        List of IP addresses in the neighbor set
                        ''',
                        'address',
                        'openconfig-routing-policy', False),
                ]),
            _MetaInfoClassMember('neighbor-set-name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                name / label of the neighbor set -- this is used to
                reference the set in match conditions
                ''',
                'neighbor_set_name',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'config',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.State', REFERENCE_CLASS,
            '''Operational state data for neighbor sets.''',
            False, 
            [
            _MetaInfoClassMember('address', REFERENCE_UNION, 'str', 'inet:ip-address-no-zone',
                None, None,
                [], [],
                '''                List of IP addresses in the neighbor set
                ''',
                'address',
                'openconfig-routing-policy', False, [
                    _MetaInfoClassMember('address', REFERENCE_LEAFLIST, 'str', 'inet:ipv4-address-no-zone',
                        None, None,
                        [], [b'(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(%[\\p{N}\\p{L}]+)?'],
                        '''                        List of IP addresses in the neighbor set
                        ''',
                        'address',
                        'openconfig-routing-policy', False, is_config=False),
                    _MetaInfoClassMember('address', REFERENCE_LEAFLIST, 'str', 'inet:ipv6-address-no-zone',
                        None, None,
                        [], [b'((:|[0-9a-fA-F]{0,4}):)([0-9a-fA-F]{0,4}:){0,5}((([0-9a-fA-F]{0,4}:)?(:|[0-9a-fA-F]{0,4}))|(((25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])))(%[\\p{N}\\p{L}]+)?'],
                        '''                        List of IP addresses in the neighbor set
                        ''',
                        'address',
                        'openconfig-routing-policy', False, is_config=False),
                ], is_config=False),
            _MetaInfoClassMember('neighbor-set-name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                name / label of the neighbor set -- this is used to
                reference the set in match conditions
                ''',
                'neighbor_set_name',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'state',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.NeighborSets.NeighborSet' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.NeighborSets.NeighborSet', REFERENCE_LIST,
            '''List of defined neighbor sets for use in policies.''',
            False, 
            [
            _MetaInfoClassMember('neighbor-set-name', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                Reference to the neighbor set name list key.
                ''',
                'neighbor_set_name',
                'openconfig-routing-policy', True),
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.Config',
                [], [],
                '''                Configuration data for neighbor sets.
                ''',
                'config',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.State',
                [], [],
                '''                Operational state data for neighbor sets.
                ''',
                'state',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'neighbor-set',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.NeighborSets' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.NeighborSets', REFERENCE_CLASS,
            '''Enclosing container for the list of neighbor set
definitions''',
            False, 
            [
            _MetaInfoClassMember('neighbor-set', REFERENCE_LIST, 'NeighborSet', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.NeighborSets.NeighborSet',
                [], [],
                '''                List of defined neighbor sets for use in policies.
                ''',
                'neighbor_set',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'neighbor-sets',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.TagSets.TagSet.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.TagSets.TagSet.Config', REFERENCE_CLASS,
            '''Configuration data for tag sets''',
            False, 
            [
            _MetaInfoClassMember('tag-set-name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                name / label of the tag set -- this is used to reference
                the set in match conditions
                ''',
                'tag_set_name',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('tag-value', REFERENCE_UNION, 'str', 'oc-pol-types:tag-type',
                None, None,
                [], [],
                '''                Value of the tag set member
                ''',
                'tag_value',
                'openconfig-routing-policy', False, [
                    _MetaInfoClassMember('tag-value', REFERENCE_LEAFLIST, 'int', 'uint32',
                        None, None,
                        [('0', '4294967295')], [],
                        '''                        Value of the tag set member
                        ''',
                        'tag_value',
                        'openconfig-routing-policy', False),
                    _MetaInfoClassMember('tag-value', REFERENCE_LEAFLIST, 'str', 'yang:hex-string',
                        None, None,
                        [], [b'([0-9a-fA-F]{2}(:[0-9a-fA-F]{2})*)?'],
                        '''                        Value of the tag set member
                        ''',
                        'tag_value',
                        'openconfig-routing-policy', False),
                ]),
            ],
            'openconfig-routing-policy',
            'config',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.TagSets.TagSet.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.TagSets.TagSet.State', REFERENCE_CLASS,
            '''Operational state data for tag sets''',
            False, 
            [
            _MetaInfoClassMember('tag-set-name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                name / label of the tag set -- this is used to reference
                the set in match conditions
                ''',
                'tag_set_name',
                'openconfig-routing-policy', False, is_config=False),
            _MetaInfoClassMember('tag-value', REFERENCE_UNION, 'str', 'oc-pol-types:tag-type',
                None, None,
                [], [],
                '''                Value of the tag set member
                ''',
                'tag_value',
                'openconfig-routing-policy', False, [
                    _MetaInfoClassMember('tag-value', REFERENCE_LEAFLIST, 'int', 'uint32',
                        None, None,
                        [('0', '4294967295')], [],
                        '''                        Value of the tag set member
                        ''',
                        'tag_value',
                        'openconfig-routing-policy', False, is_config=False),
                    _MetaInfoClassMember('tag-value', REFERENCE_LEAFLIST, 'str', 'yang:hex-string',
                        None, None,
                        [], [b'([0-9a-fA-F]{2}(:[0-9a-fA-F]{2})*)?'],
                        '''                        Value of the tag set member
                        ''',
                        'tag_value',
                        'openconfig-routing-policy', False, is_config=False),
                ], is_config=False),
            ],
            'openconfig-routing-policy',
            'state',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.TagSets.TagSet' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.TagSets.TagSet', REFERENCE_LIST,
            '''List of tag set definitions.''',
            False, 
            [
            _MetaInfoClassMember('tag-set-name', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                Reference to the tag set name list key
                ''',
                'tag_set_name',
                'openconfig-routing-policy', True),
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.TagSets.TagSet.Config',
                [], [],
                '''                Configuration data for tag sets
                ''',
                'config',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.TagSets.TagSet.State',
                [], [],
                '''                Operational state data for tag sets
                ''',
                'state',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'tag-set',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.TagSets' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.TagSets', REFERENCE_CLASS,
            '''Enclosing container for the list of tag sets.''',
            False, 
            [
            _MetaInfoClassMember('tag-set', REFERENCE_LIST, 'TagSet', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.TagSets.TagSet',
                [], [],
                '''                List of tag set definitions.
                ''',
                'tag_set',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'tag-sets',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.Config', REFERENCE_CLASS,
            '''Configuration data for BGP community sets''',
            False, 
            [
            _MetaInfoClassMember('community-member', REFERENCE_UNION, 'str', 'union',
                None, None,
                [], [],
                '''                members of the community set
                ''',
                'community_member',
                'openconfig-bgp-policy', False, [
                    _MetaInfoClassMember('community-member', REFERENCE_UNION, 'str', 'oc-bgp-types:bgp-std-community-type',
                        None, None,
                        [], [],
                        '''                        members of the community set
                        ''',
                        'community_member',
                        'openconfig-bgp-policy', False, [
                            _MetaInfoClassMember('community-member', REFERENCE_LEAFLIST, 'int', 'uint32',
                                None, None,
                                [('65536', '4294901759')], [],
                                '''                                members of the community set
                                ''',
                                'community_member',
                                'openconfig-bgp-policy', False),
                            _MetaInfoClassMember('community-member', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'([0-9]+:[0-9]+)'],
                                '''                                members of the community set
                                ''',
                                'community_member',
                                'openconfig-bgp-policy', False),
                        ]),
                    _MetaInfoClassMember('community-member', REFERENCE_LEAFLIST, 'str', 'oc-bgp-types:bgp-community-regexp-type',
                        None, None,
                        [], [],
                        '''                        members of the community set
                        ''',
                        'community_member',
                        'openconfig-bgp-policy', False),
                    _MetaInfoClassMember('community-member', REFERENCE_LEAFLIST, 'Bgp_Well_Known_Std_CommunityIdentity', 'oc-bgp-types:bgp-well-known-community-type',
                        'ydk.models.ydktest.openconfig_bgp_types', 'Bgp_Well_Known_Std_CommunityIdentity',
                        [], [],
                        '''                        members of the community set
                        ''',
                        'community_member',
                        'openconfig-bgp-policy', False),
                ]),
            _MetaInfoClassMember('community-set-name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                name / label of the community set -- this is used to
                reference the set in match conditions
                ''',
                'community_set_name',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.State', REFERENCE_CLASS,
            '''Operational state data for BGP community sets''',
            False, 
            [
            _MetaInfoClassMember('community-member', REFERENCE_UNION, 'str', 'union',
                None, None,
                [], [],
                '''                members of the community set
                ''',
                'community_member',
                'openconfig-bgp-policy', False, [
                    _MetaInfoClassMember('community-member', REFERENCE_UNION, 'str', 'oc-bgp-types:bgp-std-community-type',
                        None, None,
                        [], [],
                        '''                        members of the community set
                        ''',
                        'community_member',
                        'openconfig-bgp-policy', False, [
                            _MetaInfoClassMember('community-member', REFERENCE_LEAFLIST, 'int', 'uint32',
                                None, None,
                                [('65536', '4294901759')], [],
                                '''                                members of the community set
                                ''',
                                'community_member',
                                'openconfig-bgp-policy', False, is_config=False),
                            _MetaInfoClassMember('community-member', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'([0-9]+:[0-9]+)'],
                                '''                                members of the community set
                                ''',
                                'community_member',
                                'openconfig-bgp-policy', False, is_config=False),
                        ], is_config=False),
                    _MetaInfoClassMember('community-member', REFERENCE_LEAFLIST, 'str', 'oc-bgp-types:bgp-community-regexp-type',
                        None, None,
                        [], [],
                        '''                        members of the community set
                        ''',
                        'community_member',
                        'openconfig-bgp-policy', False, is_config=False),
                    _MetaInfoClassMember('community-member', REFERENCE_LEAFLIST, 'Bgp_Well_Known_Std_CommunityIdentity', 'oc-bgp-types:bgp-well-known-community-type',
                        'ydk.models.ydktest.openconfig_bgp_types', 'Bgp_Well_Known_Std_CommunityIdentity',
                        [], [],
                        '''                        members of the community set
                        ''',
                        'community_member',
                        'openconfig-bgp-policy', False, is_config=False),
                ], is_config=False),
            _MetaInfoClassMember('community-set-name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                name / label of the community set -- this is used to
                reference the set in match conditions
                ''',
                'community_set_name',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet', REFERENCE_LIST,
            '''List of defined BGP community sets''',
            False, 
            [
            _MetaInfoClassMember('community-set-name', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                Reference to list key
                ''',
                'community_set_name',
                'openconfig-bgp-policy', True),
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.Config',
                [], [],
                '''                Configuration data for BGP community sets
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.State',
                [], [],
                '''                Operational state data for BGP community sets
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'community-set',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets', REFERENCE_CLASS,
            '''Enclosing container for list of defined BGP community sets''',
            False, 
            [
            _MetaInfoClassMember('community-set', REFERENCE_LIST, 'CommunitySet', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet',
                [], [],
                '''                List of defined BGP community sets
                ''',
                'community_set',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'community-sets',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.Config', REFERENCE_CLASS,
            '''Configuration data for extended BGP community sets''',
            False, 
            [
            _MetaInfoClassMember('ext-community-member', REFERENCE_UNION, 'str', 'union',
                None, None,
                [], [],
                '''                members of the extended community set
                ''',
                'ext_community_member',
                'openconfig-bgp-policy', False, [
                    _MetaInfoClassMember('ext-community-member', REFERENCE_UNION, 'str', 'oc-bgp-types:bgp-ext-community-type',
                        None, None,
                        [], [],
                        '''                        members of the extended community set
                        ''',
                        'ext_community_member',
                        'openconfig-bgp-policy', False, [
                            _MetaInfoClassMember('ext-community-member', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9]):(4[0-2][0-9][0-4][0-9][0-6][0-7][0-2][0-9][0-6]|[1-3][0-9]{9}|[1-9]([0-9]{1,7})?[0-9]|[1-9])'],
                                '''                                members of the extended community set
                                ''',
                                'ext_community_member',
                                'openconfig-bgp-policy', False),
                            _MetaInfoClassMember('ext-community-member', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5]):(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9])'],
                                '''                                members of the extended community set
                                ''',
                                'ext_community_member',
                                'openconfig-bgp-policy', False),
                            _MetaInfoClassMember('ext-community-member', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-target:(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9]):(4[0-2][0-9][0-4][0-9][0-6][0-7][0-2][0-9][0-6]|[1-3][0-9]{9}|[1-9]([0-9]{1,7})?[0-9]|[1-9])'],
                                '''                                members of the extended community set
                                ''',
                                'ext_community_member',
                                'openconfig-bgp-policy', False),
                            _MetaInfoClassMember('ext-community-member', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-target:(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5]):(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9])'],
                                '''                                members of the extended community set
                                ''',
                                'ext_community_member',
                                'openconfig-bgp-policy', False),
                            _MetaInfoClassMember('ext-community-member', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-origin:(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9]):(4[0-2][0-9][0-4][0-9][0-6][0-7][0-2][0-9][0-6]|[1-3][0-9]{9}|[1-9]([0-9]{1,7})?[0-9]|[1-9])'],
                                '''                                members of the extended community set
                                ''',
                                'ext_community_member',
                                'openconfig-bgp-policy', False),
                            _MetaInfoClassMember('ext-community-member', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-origin:(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5]):(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9])'],
                                '''                                members of the extended community set
                                ''',
                                'ext_community_member',
                                'openconfig-bgp-policy', False),
                        ]),
                    _MetaInfoClassMember('ext-community-member', REFERENCE_LEAFLIST, 'str', 'oc-bgp-types:bgp-community-regexp-type',
                        None, None,
                        [], [],
                        '''                        members of the extended community set
                        ''',
                        'ext_community_member',
                        'openconfig-bgp-policy', False),
                ]),
            _MetaInfoClassMember('ext-community-set-name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                name / label of the extended community set -- this is
                used to reference the set in match conditions
                ''',
                'ext_community_set_name',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.State', REFERENCE_CLASS,
            '''Operational state data for extended BGP community sets''',
            False, 
            [
            _MetaInfoClassMember('ext-community-member', REFERENCE_UNION, 'str', 'union',
                None, None,
                [], [],
                '''                members of the extended community set
                ''',
                'ext_community_member',
                'openconfig-bgp-policy', False, [
                    _MetaInfoClassMember('ext-community-member', REFERENCE_UNION, 'str', 'oc-bgp-types:bgp-ext-community-type',
                        None, None,
                        [], [],
                        '''                        members of the extended community set
                        ''',
                        'ext_community_member',
                        'openconfig-bgp-policy', False, [
                            _MetaInfoClassMember('ext-community-member', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9]):(4[0-2][0-9][0-4][0-9][0-6][0-7][0-2][0-9][0-6]|[1-3][0-9]{9}|[1-9]([0-9]{1,7})?[0-9]|[1-9])'],
                                '''                                members of the extended community set
                                ''',
                                'ext_community_member',
                                'openconfig-bgp-policy', False, is_config=False),
                            _MetaInfoClassMember('ext-community-member', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5]):(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9])'],
                                '''                                members of the extended community set
                                ''',
                                'ext_community_member',
                                'openconfig-bgp-policy', False, is_config=False),
                            _MetaInfoClassMember('ext-community-member', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-target:(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9]):(4[0-2][0-9][0-4][0-9][0-6][0-7][0-2][0-9][0-6]|[1-3][0-9]{9}|[1-9]([0-9]{1,7})?[0-9]|[1-9])'],
                                '''                                members of the extended community set
                                ''',
                                'ext_community_member',
                                'openconfig-bgp-policy', False, is_config=False),
                            _MetaInfoClassMember('ext-community-member', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-target:(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5]):(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9])'],
                                '''                                members of the extended community set
                                ''',
                                'ext_community_member',
                                'openconfig-bgp-policy', False, is_config=False),
                            _MetaInfoClassMember('ext-community-member', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-origin:(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9]):(4[0-2][0-9][0-4][0-9][0-6][0-7][0-2][0-9][0-6]|[1-3][0-9]{9}|[1-9]([0-9]{1,7})?[0-9]|[1-9])'],
                                '''                                members of the extended community set
                                ''',
                                'ext_community_member',
                                'openconfig-bgp-policy', False, is_config=False),
                            _MetaInfoClassMember('ext-community-member', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-origin:(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5]):(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9])'],
                                '''                                members of the extended community set
                                ''',
                                'ext_community_member',
                                'openconfig-bgp-policy', False, is_config=False),
                        ], is_config=False),
                    _MetaInfoClassMember('ext-community-member', REFERENCE_LEAFLIST, 'str', 'oc-bgp-types:bgp-community-regexp-type',
                        None, None,
                        [], [],
                        '''                        members of the extended community set
                        ''',
                        'ext_community_member',
                        'openconfig-bgp-policy', False, is_config=False),
                ], is_config=False),
            _MetaInfoClassMember('ext-community-set-name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                name / label of the extended community set -- this is
                used to reference the set in match conditions
                ''',
                'ext_community_set_name',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet', REFERENCE_LIST,
            '''List of defined extended BGP community sets''',
            False, 
            [
            _MetaInfoClassMember('ext-community-set-name', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                Reference to list key
                ''',
                'ext_community_set_name',
                'openconfig-bgp-policy', True),
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.Config',
                [], [],
                '''                Configuration data for extended BGP community sets
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.State',
                [], [],
                '''                Operational state data for extended BGP community sets
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'ext-community-set',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets', REFERENCE_CLASS,
            '''Enclosing container for list of extended BGP community
sets''',
            False, 
            [
            _MetaInfoClassMember('ext-community-set', REFERENCE_LIST, 'ExtCommunitySet', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet',
                [], [],
                '''                List of defined extended BGP community sets
                ''',
                'ext_community_set',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'ext-community-sets',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.Config', REFERENCE_CLASS,
            '''Configuration data for AS path sets''',
            False, 
            [
            _MetaInfoClassMember('as-path-set-member', REFERENCE_LEAFLIST, 'str', 'string',
                None, None,
                [], [],
                '''                AS path expression -- list of ASes in the set
                ''',
                'as_path_set_member',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('as-path-set-name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                name of the AS path set -- this is used to reference
                the set in match conditions
                ''',
                'as_path_set_name',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.State', REFERENCE_CLASS,
            '''Operational state data for AS path sets''',
            False, 
            [
            _MetaInfoClassMember('as-path-set-member', REFERENCE_LEAFLIST, 'str', 'string',
                None, None,
                [], [],
                '''                AS path expression -- list of ASes in the set
                ''',
                'as_path_set_member',
                'openconfig-bgp-policy', False, is_config=False),
            _MetaInfoClassMember('as-path-set-name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                name of the AS path set -- this is used to reference
                the set in match conditions
                ''',
                'as_path_set_name',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet', REFERENCE_LIST,
            '''List of defined AS path sets''',
            False, 
            [
            _MetaInfoClassMember('as-path-set-name', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                Reference to list key
                ''',
                'as_path_set_name',
                'openconfig-bgp-policy', True),
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.Config',
                [], [],
                '''                Configuration data for AS path sets
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.State',
                [], [],
                '''                Operational state data for AS path sets
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'as-path-set',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets', REFERENCE_CLASS,
            '''Enclosing container for list of define AS path sets''',
            False, 
            [
            _MetaInfoClassMember('as-path-set', REFERENCE_LIST, 'AsPathSet', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet',
                [], [],
                '''                List of defined AS path sets
                ''',
                'as_path_set',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'as-path-sets',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets.BgpDefinedSets' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets.BgpDefinedSets', REFERENCE_CLASS,
            '''BGP-related set definitions for policy match conditions''',
            False, 
            [
            _MetaInfoClassMember('as-path-sets', REFERENCE_CLASS, 'AsPathSets', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets',
                [], [],
                '''                Enclosing container for list of define AS path sets
                ''',
                'as_path_sets',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('community-sets', REFERENCE_CLASS, 'CommunitySets', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets',
                [], [],
                '''                Enclosing container for list of defined BGP community sets
                ''',
                'community_sets',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('ext-community-sets', REFERENCE_CLASS, 'ExtCommunitySets', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets',
                [], [],
                '''                Enclosing container for list of extended BGP community
                sets
                ''',
                'ext_community_sets',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'bgp-defined-sets',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.DefinedSets' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.DefinedSets', REFERENCE_CLASS,
            '''Predefined sets of attributes used in policy match
statements''',
            False, 
            [
            _MetaInfoClassMember('bgp-defined-sets', REFERENCE_CLASS, 'BgpDefinedSets', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.BgpDefinedSets',
                [], [],
                '''                BGP-related set definitions for policy match conditions
                ''',
                'bgp_defined_sets',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('neighbor-sets', REFERENCE_CLASS, 'NeighborSets', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.NeighborSets',
                [], [],
                '''                Enclosing container for the list of neighbor set
                definitions
                ''',
                'neighbor_sets',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('prefix-sets', REFERENCE_CLASS, 'PrefixSets', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.PrefixSets',
                [], [],
                '''                Enclosing container 
                ''',
                'prefix_sets',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('tag-sets', REFERENCE_CLASS, 'TagSets', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets.TagSets',
                [], [],
                '''                Enclosing container for the list of tag sets.
                ''',
                'tag_sets',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'defined-sets',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Config', REFERENCE_CLASS,
            '''Configuration data for policy defintions''',
            False, 
            [
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                Name of the top-level policy definition -- this name
                is used in references to the current policy
                ''',
                'name',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'config',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.State', REFERENCE_CLASS,
            '''Operational state data for policy definitions''',
            False, 
            [
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                Name of the top-level policy definition -- this name
                is used in references to the current policy
                ''',
                'name',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'state',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Config', REFERENCE_CLASS,
            '''Configuration data for policy statements''',
            False, 
            [
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                name of the policy statement
                ''',
                'name',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'config',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.State', REFERENCE_CLASS,
            '''Operational state data for policy statements''',
            False, 
            [
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                name of the policy statement
                ''',
                'name',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'state',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.Config', REFERENCE_CLASS,
            '''Configuration data for policy conditions''',
            False, 
            [
            _MetaInfoClassMember('call-policy', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                Applies the statements from the specified policy
                definition and then returns control the current
                policy statement. Note that the called policy may
                itself call other policies (subject to
                implementation limitations). This is intended to
                provide a policy 'subroutine' capability.  The
                called policy should contain an explicit or a
                default route disposition that returns an
                effective true (accept-route) or false
                (reject-route), otherwise the behavior may be
                ambiguous and implementation dependent
                ''',
                'call_policy',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('install-protocol-eq', REFERENCE_IDENTITY_CLASS, 'Install_Protocol_TypeIdentity', 'identityref',
                'ydk.models.ydktest.openconfig_policy_types', 'Install_Protocol_TypeIdentity',
                [], [],
                '''                Condition to check the protocol / method used to install
                the route into the local routing table
                ''',
                'install_protocol_eq',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'config',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.State', REFERENCE_CLASS,
            '''Operational state data for policy conditions''',
            False, 
            [
            _MetaInfoClassMember('call-policy', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                Applies the statements from the specified policy
                definition and then returns control the current
                policy statement. Note that the called policy may
                itself call other policies (subject to
                implementation limitations). This is intended to
                provide a policy 'subroutine' capability.  The
                called policy should contain an explicit or a
                default route disposition that returns an
                effective true (accept-route) or false
                (reject-route), otherwise the behavior may be
                ambiguous and implementation dependent
                ''',
                'call_policy',
                'openconfig-routing-policy', False, is_config=False),
            _MetaInfoClassMember('install-protocol-eq', REFERENCE_IDENTITY_CLASS, 'Install_Protocol_TypeIdentity', 'identityref',
                'ydk.models.ydktest.openconfig_policy_types', 'Install_Protocol_TypeIdentity',
                [], [],
                '''                Condition to check the protocol / method used to install
                the route into the local routing table
                ''',
                'install_protocol_eq',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'state',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface.Config', REFERENCE_CLASS,
            '''Configuration data for interface match conditions''',
            False, 
            [
            _MetaInfoClassMember('interface', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                Reference to a base interface.  If a reference to a
                subinterface is required, this leaf must be specified
                to indicate the base interface.
                ''',
                'interface',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('subinterface', ATTRIBUTE, 'int', 'leafref',
                None, None,
                [('0', '4294967295')], [],
                '''                Reference to a subinterface -- this requires the base
                interface to be specified using the interface leaf in
                this container.  If only a reference to a base interface
                is requuired, this leaf should not be set.
                ''',
                'subinterface',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'config',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface.State', REFERENCE_CLASS,
            '''Operational state data for interface match conditions''',
            False, 
            [
            _MetaInfoClassMember('interface', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                Reference to a base interface.  If a reference to a
                subinterface is required, this leaf must be specified
                to indicate the base interface.
                ''',
                'interface',
                'openconfig-routing-policy', False, is_config=False),
            _MetaInfoClassMember('subinterface', ATTRIBUTE, 'int', 'leafref',
                None, None,
                [('0', '4294967295')], [],
                '''                Reference to a subinterface -- this requires the base
                interface to be specified using the interface leaf in
                this container.  If only a reference to a base interface
                is requuired, this leaf should not be set.
                ''',
                'subinterface',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'state',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface', REFERENCE_CLASS,
            '''Top-level container for interface match conditions''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface.Config',
                [], [],
                '''                Configuration data for interface match conditions
                ''',
                'config',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface.State',
                [], [],
                '''                Operational state data for interface match conditions
                ''',
                'state',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'match-interface',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet.Config', REFERENCE_CLASS,
            '''Configuration data for a prefix-set condition''',
            False, 
            [
            _MetaInfoClassMember('match-set-options', REFERENCE_ENUM_CLASS, 'MatchSetOptionsRestrictedTypeEnum', 'oc-pol-types:match-set-options-restricted-type',
                'ydk.models.ydktest.openconfig_policy_types', 'MatchSetOptionsRestrictedTypeEnum',
                [], [],
                '''                Optional parameter that governs the behaviour of the
                match operation.  This leaf only supports matching on ANY
                member of the set or inverting the match.  Matching on ALL is
                not supported)
                ''',
                'match_set_options',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('prefix-set', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined prefix set
                ''',
                'prefix_set',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'config',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet.State', REFERENCE_CLASS,
            '''Operational state data for a prefix-set condition''',
            False, 
            [
            _MetaInfoClassMember('match-set-options', REFERENCE_ENUM_CLASS, 'MatchSetOptionsRestrictedTypeEnum', 'oc-pol-types:match-set-options-restricted-type',
                'ydk.models.ydktest.openconfig_policy_types', 'MatchSetOptionsRestrictedTypeEnum',
                [], [],
                '''                Optional parameter that governs the behaviour of the
                match operation.  This leaf only supports matching on ANY
                member of the set or inverting the match.  Matching on ALL is
                not supported)
                ''',
                'match_set_options',
                'openconfig-routing-policy', False, is_config=False),
            _MetaInfoClassMember('prefix-set', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined prefix set
                ''',
                'prefix_set',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'state',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet', REFERENCE_CLASS,
            '''Match a referenced prefix-set according to the logic
defined in the match-set-options leaf''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet.Config',
                [], [],
                '''                Configuration data for a prefix-set condition
                ''',
                'config',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet.State',
                [], [],
                '''                Operational state data for a prefix-set condition
                ''',
                'state',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'match-prefix-set',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet.Config', REFERENCE_CLASS,
            '''Configuration data ''',
            False, 
            [
            _MetaInfoClassMember('match-set-options', REFERENCE_ENUM_CLASS, 'MatchSetOptionsRestrictedTypeEnum', 'oc-pol-types:match-set-options-restricted-type',
                'ydk.models.ydktest.openconfig_policy_types', 'MatchSetOptionsRestrictedTypeEnum',
                [], [],
                '''                Optional parameter that governs the behaviour of the
                match operation.  This leaf only supports matching on ANY
                member of the set or inverting the match.  Matching on ALL is
                not supported)
                ''',
                'match_set_options',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('neighbor-set', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined neighbor set
                ''',
                'neighbor_set',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'config',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet.State', REFERENCE_CLASS,
            '''Operational state data ''',
            False, 
            [
            _MetaInfoClassMember('match-set-options', REFERENCE_ENUM_CLASS, 'MatchSetOptionsRestrictedTypeEnum', 'oc-pol-types:match-set-options-restricted-type',
                'ydk.models.ydktest.openconfig_policy_types', 'MatchSetOptionsRestrictedTypeEnum',
                [], [],
                '''                Optional parameter that governs the behaviour of the
                match operation.  This leaf only supports matching on ANY
                member of the set or inverting the match.  Matching on ALL is
                not supported)
                ''',
                'match_set_options',
                'openconfig-routing-policy', False, is_config=False),
            _MetaInfoClassMember('neighbor-set', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined neighbor set
                ''',
                'neighbor_set',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'state',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet', REFERENCE_CLASS,
            '''Match a referenced neighbor set according to the logic
defined in the match-set-options-leaf''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet.Config',
                [], [],
                '''                Configuration data 
                ''',
                'config',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet.State',
                [], [],
                '''                Operational state data 
                ''',
                'state',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'match-neighbor-set',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet.Config', REFERENCE_CLASS,
            '''Configuration data for tag-set conditions''',
            False, 
            [
            _MetaInfoClassMember('match-set-options', REFERENCE_ENUM_CLASS, 'MatchSetOptionsRestrictedTypeEnum', 'oc-pol-types:match-set-options-restricted-type',
                'ydk.models.ydktest.openconfig_policy_types', 'MatchSetOptionsRestrictedTypeEnum',
                [], [],
                '''                Optional parameter that governs the behaviour of the
                match operation.  This leaf only supports matching on ANY
                member of the set or inverting the match.  Matching on ALL is
                not supported)
                ''',
                'match_set_options',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('tag-set', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined tag set
                ''',
                'tag_set',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'config',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet.State', REFERENCE_CLASS,
            '''Operational state data tag-set conditions''',
            False, 
            [
            _MetaInfoClassMember('match-set-options', REFERENCE_ENUM_CLASS, 'MatchSetOptionsRestrictedTypeEnum', 'oc-pol-types:match-set-options-restricted-type',
                'ydk.models.ydktest.openconfig_policy_types', 'MatchSetOptionsRestrictedTypeEnum',
                [], [],
                '''                Optional parameter that governs the behaviour of the
                match operation.  This leaf only supports matching on ANY
                member of the set or inverting the match.  Matching on ALL is
                not supported)
                ''',
                'match_set_options',
                'openconfig-routing-policy', False, is_config=False),
            _MetaInfoClassMember('tag-set', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined tag set
                ''',
                'tag_set',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'state',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet', REFERENCE_CLASS,
            '''Match a referenced tag set according to the logic defined
in the match-options-set leaf''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet.Config',
                [], [],
                '''                Configuration data for tag-set conditions
                ''',
                'config',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet.State',
                [], [],
                '''                Operational state data tag-set conditions
                ''',
                'state',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'match-tag-set',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.IgpConditions' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.IgpConditions', REFERENCE_CLASS,
            '''Policy conditions for IGP attributes''',
            False, 
            [
            ],
            'openconfig-routing-policy',
            'igp-conditions',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.Config.RouteTypeEnum' : _MetaInfoEnum('RouteTypeEnum',
        'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.Config.RouteTypeEnum',
        '''Condition to check the route type in the route update''',
        {
            'INTERNAL':'INTERNAL',
            'EXTERNAL':'EXTERNAL',
        }, 'openconfig-bgp-policy', _yang_ns._namespaces['openconfig-bgp-policy']),
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.Config', REFERENCE_CLASS,
            '''Configuration data for BGP-specific policy conditions''',
            False, 
            [
            _MetaInfoClassMember('afi-safi-in', REFERENCE_LEAFLIST, 'Afi_Safi_TypeIdentity', 'identityref',
                'ydk.models.ydktest.openconfig_bgp_types', 'Afi_Safi_TypeIdentity',
                [], [],
                '''                List of address families which the NLRI may be
                within
                ''',
                'afi_safi_in',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('local-pref-eq', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                Condition to check if the local pref attribute is equal to
                the specified value
                ''',
                'local_pref_eq',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('med-eq', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                Condition to check if the received MED value is equal to
                the specified value
                ''',
                'med_eq',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('next-hop-in', REFERENCE_UNION, 'str', 'inet:ip-address-no-zone',
                None, None,
                [], [],
                '''                List of next hop addresses to check for in the route
                update
                ''',
                'next_hop_in',
                'openconfig-bgp-policy', False, [
                    _MetaInfoClassMember('next-hop-in', REFERENCE_LEAFLIST, 'str', 'inet:ipv4-address-no-zone',
                        None, None,
                        [], [b'(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(%[\\p{N}\\p{L}]+)?'],
                        '''                        List of next hop addresses to check for in the route
                        update
                        ''',
                        'next_hop_in',
                        'openconfig-bgp-policy', False),
                    _MetaInfoClassMember('next-hop-in', REFERENCE_LEAFLIST, 'str', 'inet:ipv6-address-no-zone',
                        None, None,
                        [], [b'((:|[0-9a-fA-F]{0,4}):)([0-9a-fA-F]{0,4}:){0,5}((([0-9a-fA-F]{0,4}:)?(:|[0-9a-fA-F]{0,4}))|(((25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])))(%[\\p{N}\\p{L}]+)?'],
                        '''                        List of next hop addresses to check for in the route
                        update
                        ''',
                        'next_hop_in',
                        'openconfig-bgp-policy', False),
                ]),
            _MetaInfoClassMember('origin-eq', REFERENCE_ENUM_CLASS, 'BgpOriginAttrTypeEnum', 'oc-bgp-types:bgp-origin-attr-type',
                'ydk.models.ydktest.openconfig_bgp_types', 'BgpOriginAttrTypeEnum',
                [], [],
                '''                Condition to check if the route origin is equal to the
                specified value
                ''',
                'origin_eq',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('route-type', REFERENCE_ENUM_CLASS, 'RouteTypeEnum', 'enumeration',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.Config.RouteTypeEnum',
                [], [],
                '''                Condition to check the route type in the route update
                ''',
                'route_type',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.State.RouteTypeEnum' : _MetaInfoEnum('RouteTypeEnum',
        'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.State.RouteTypeEnum',
        '''Condition to check the route type in the route update''',
        {
            'INTERNAL':'INTERNAL',
            'EXTERNAL':'EXTERNAL',
        }, 'openconfig-bgp-policy', _yang_ns._namespaces['openconfig-bgp-policy']),
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.State', REFERENCE_CLASS,
            '''Operational state data for BGP-specific policy
conditions''',
            False, 
            [
            _MetaInfoClassMember('afi-safi-in', REFERENCE_LEAFLIST, 'Afi_Safi_TypeIdentity', 'identityref',
                'ydk.models.ydktest.openconfig_bgp_types', 'Afi_Safi_TypeIdentity',
                [], [],
                '''                List of address families which the NLRI may be
                within
                ''',
                'afi_safi_in',
                'openconfig-bgp-policy', False, is_config=False),
            _MetaInfoClassMember('local-pref-eq', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                Condition to check if the local pref attribute is equal to
                the specified value
                ''',
                'local_pref_eq',
                'openconfig-bgp-policy', False, is_config=False),
            _MetaInfoClassMember('med-eq', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                Condition to check if the received MED value is equal to
                the specified value
                ''',
                'med_eq',
                'openconfig-bgp-policy', False, is_config=False),
            _MetaInfoClassMember('next-hop-in', REFERENCE_UNION, 'str', 'inet:ip-address-no-zone',
                None, None,
                [], [],
                '''                List of next hop addresses to check for in the route
                update
                ''',
                'next_hop_in',
                'openconfig-bgp-policy', False, [
                    _MetaInfoClassMember('next-hop-in', REFERENCE_LEAFLIST, 'str', 'inet:ipv4-address-no-zone',
                        None, None,
                        [], [b'(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(%[\\p{N}\\p{L}]+)?'],
                        '''                        List of next hop addresses to check for in the route
                        update
                        ''',
                        'next_hop_in',
                        'openconfig-bgp-policy', False, is_config=False),
                    _MetaInfoClassMember('next-hop-in', REFERENCE_LEAFLIST, 'str', 'inet:ipv6-address-no-zone',
                        None, None,
                        [], [b'((:|[0-9a-fA-F]{0,4}):)([0-9a-fA-F]{0,4}:){0,5}((([0-9a-fA-F]{0,4}:)?(:|[0-9a-fA-F]{0,4}))|(((25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])))(%[\\p{N}\\p{L}]+)?'],
                        '''                        List of next hop addresses to check for in the route
                        update
                        ''',
                        'next_hop_in',
                        'openconfig-bgp-policy', False, is_config=False),
                ], is_config=False),
            _MetaInfoClassMember('origin-eq', REFERENCE_ENUM_CLASS, 'BgpOriginAttrTypeEnum', 'oc-bgp-types:bgp-origin-attr-type',
                'ydk.models.ydktest.openconfig_bgp_types', 'BgpOriginAttrTypeEnum',
                [], [],
                '''                Condition to check if the route origin is equal to the
                specified value
                ''',
                'origin_eq',
                'openconfig-bgp-policy', False, is_config=False),
            _MetaInfoClassMember('route-type', REFERENCE_ENUM_CLASS, 'RouteTypeEnum', 'enumeration',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.State.RouteTypeEnum',
                [], [],
                '''                Condition to check the route type in the route update
                ''',
                'route_type',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount.Config', REFERENCE_CLASS,
            '''Configuration data for community count condition''',
            False, 
            [
            _MetaInfoClassMember('operator', REFERENCE_IDENTITY_CLASS, 'Attribute_ComparisonIdentity', 'identityref',
                'ydk.models.ydktest.openconfig_policy_types', 'Attribute_ComparisonIdentity',
                [], [],
                '''                type of comparison to be performed
                ''',
                'operator',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('value', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                value to compare with the community count
                ''',
                'value',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount.State', REFERENCE_CLASS,
            '''Operational state data for community count condition''',
            False, 
            [
            _MetaInfoClassMember('operator', REFERENCE_IDENTITY_CLASS, 'Attribute_ComparisonIdentity', 'identityref',
                'ydk.models.ydktest.openconfig_policy_types', 'Attribute_ComparisonIdentity',
                [], [],
                '''                type of comparison to be performed
                ''',
                'operator',
                'openconfig-bgp-policy', False, is_config=False),
            _MetaInfoClassMember('value', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                value to compare with the community count
                ''',
                'value',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount', REFERENCE_CLASS,
            '''Value and comparison operations for conditions based on the
number of communities in the route update''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount.Config',
                [], [],
                '''                Configuration data for community count condition
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount.State',
                [], [],
                '''                Operational state data for community count condition
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'community-count',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength.Config', REFERENCE_CLASS,
            '''Configuration data for AS path length condition''',
            False, 
            [
            _MetaInfoClassMember('operator', REFERENCE_IDENTITY_CLASS, 'Attribute_ComparisonIdentity', 'identityref',
                'ydk.models.ydktest.openconfig_policy_types', 'Attribute_ComparisonIdentity',
                [], [],
                '''                type of comparison to be performed
                ''',
                'operator',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('value', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                value to compare with the community count
                ''',
                'value',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength.State', REFERENCE_CLASS,
            '''Operational state data for AS path length condition''',
            False, 
            [
            _MetaInfoClassMember('operator', REFERENCE_IDENTITY_CLASS, 'Attribute_ComparisonIdentity', 'identityref',
                'ydk.models.ydktest.openconfig_policy_types', 'Attribute_ComparisonIdentity',
                [], [],
                '''                type of comparison to be performed
                ''',
                'operator',
                'openconfig-bgp-policy', False, is_config=False),
            _MetaInfoClassMember('value', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                value to compare with the community count
                ''',
                'value',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength', REFERENCE_CLASS,
            '''Value and comparison operations for conditions based on the
length of the AS path in the route update''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength.Config',
                [], [],
                '''                Configuration data for AS path length condition
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength.State',
                [], [],
                '''                Operational state data for AS path length condition
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'as-path-length',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet.Config', REFERENCE_CLASS,
            '''Configuration data for match conditions on communities''',
            False, 
            [
            _MetaInfoClassMember('community-set', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined community set
                ''',
                'community_set',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('match-set-options', REFERENCE_ENUM_CLASS, 'MatchSetOptionsTypeEnum', 'oc-pol-types:match-set-options-type',
                'ydk.models.ydktest.openconfig_policy_types', 'MatchSetOptionsTypeEnum',
                [], [],
                '''                Optional parameter that governs the behaviour of the
                match operation
                ''',
                'match_set_options',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet.State', REFERENCE_CLASS,
            '''Operational state data ''',
            False, 
            [
            _MetaInfoClassMember('community-set', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined community set
                ''',
                'community_set',
                'openconfig-bgp-policy', False, is_config=False),
            _MetaInfoClassMember('match-set-options', REFERENCE_ENUM_CLASS, 'MatchSetOptionsTypeEnum', 'oc-pol-types:match-set-options-type',
                'ydk.models.ydktest.openconfig_policy_types', 'MatchSetOptionsTypeEnum',
                [], [],
                '''                Optional parameter that governs the behaviour of the
                match operation
                ''',
                'match_set_options',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet', REFERENCE_CLASS,
            '''Top-level container for match conditions on communities.
Match a referenced community-set according to the logic
defined in the match-set-options leaf''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet.Config',
                [], [],
                '''                Configuration data for match conditions on communities
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet.State',
                [], [],
                '''                Operational state data 
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'match-community-set',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet.Config', REFERENCE_CLASS,
            '''Configuration data for match conditions on extended
communities''',
            False, 
            [
            _MetaInfoClassMember('ext-community-set', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined extended community set
                ''',
                'ext_community_set',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('match-set-options', REFERENCE_ENUM_CLASS, 'MatchSetOptionsTypeEnum', 'oc-pol-types:match-set-options-type',
                'ydk.models.ydktest.openconfig_policy_types', 'MatchSetOptionsTypeEnum',
                [], [],
                '''                Optional parameter that governs the behaviour of the
                match operation
                ''',
                'match_set_options',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet.State', REFERENCE_CLASS,
            '''Operational state data for match conditions on extended
communities''',
            False, 
            [
            _MetaInfoClassMember('ext-community-set', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined extended community set
                ''',
                'ext_community_set',
                'openconfig-bgp-policy', False, is_config=False),
            _MetaInfoClassMember('match-set-options', REFERENCE_ENUM_CLASS, 'MatchSetOptionsTypeEnum', 'oc-pol-types:match-set-options-type',
                'ydk.models.ydktest.openconfig_policy_types', 'MatchSetOptionsTypeEnum',
                [], [],
                '''                Optional parameter that governs the behaviour of the
                match operation
                ''',
                'match_set_options',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet', REFERENCE_CLASS,
            '''Match a referenced extended community-set according to the
logic defined in the match-set-options leaf''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet.Config',
                [], [],
                '''                Configuration data for match conditions on extended
                communities
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet.State',
                [], [],
                '''                Operational state data for match conditions on extended
                communities
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'match-ext-community-set',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet.Config', REFERENCE_CLASS,
            '''Configuration data for match conditions on AS path set''',
            False, 
            [
            _MetaInfoClassMember('as-path-set', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined AS path set
                ''',
                'as_path_set',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('match-set-options', REFERENCE_ENUM_CLASS, 'MatchSetOptionsTypeEnum', 'oc-pol-types:match-set-options-type',
                'ydk.models.ydktest.openconfig_policy_types', 'MatchSetOptionsTypeEnum',
                [], [],
                '''                Optional parameter that governs the behaviour of the
                match operation
                ''',
                'match_set_options',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet.State', REFERENCE_CLASS,
            '''Operational state data for match conditions on AS
path set''',
            False, 
            [
            _MetaInfoClassMember('as-path-set', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined AS path set
                ''',
                'as_path_set',
                'openconfig-bgp-policy', False, is_config=False),
            _MetaInfoClassMember('match-set-options', REFERENCE_ENUM_CLASS, 'MatchSetOptionsTypeEnum', 'oc-pol-types:match-set-options-type',
                'ydk.models.ydktest.openconfig_policy_types', 'MatchSetOptionsTypeEnum',
                [], [],
                '''                Optional parameter that governs the behaviour of the
                match operation
                ''',
                'match_set_options',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet', REFERENCE_CLASS,
            '''Match a referenced as-path set according to the logic
defined in the match-set-options leaf''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet.Config',
                [], [],
                '''                Configuration data for match conditions on AS path set
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet.State',
                [], [],
                '''                Operational state data for match conditions on AS
                path set
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'match-as-path-set',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions', REFERENCE_CLASS,
            '''Top-level container ''',
            False, 
            [
            _MetaInfoClassMember('as-path-length', REFERENCE_CLASS, 'AsPathLength', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength',
                [], [],
                '''                Value and comparison operations for conditions based on the
                length of the AS path in the route update
                ''',
                'as_path_length',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('community-count', REFERENCE_CLASS, 'CommunityCount', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount',
                [], [],
                '''                Value and comparison operations for conditions based on the
                number of communities in the route update
                ''',
                'community_count',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.Config',
                [], [],
                '''                Configuration data for BGP-specific policy conditions
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('match-as-path-set', REFERENCE_CLASS, 'MatchAsPathSet', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet',
                [], [],
                '''                Match a referenced as-path set according to the logic
                defined in the match-set-options leaf
                ''',
                'match_as_path_set',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('match-community-set', REFERENCE_CLASS, 'MatchCommunitySet', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet',
                [], [],
                '''                Top-level container for match conditions on communities.
                Match a referenced community-set according to the logic
                defined in the match-set-options leaf
                ''',
                'match_community_set',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('match-ext-community-set', REFERENCE_CLASS, 'MatchExtCommunitySet', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet',
                [], [],
                '''                Match a referenced extended community-set according to the
                logic defined in the match-set-options leaf
                ''',
                'match_ext_community_set',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.State',
                [], [],
                '''                Operational state data for BGP-specific policy
                conditions
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'bgp-conditions',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions', REFERENCE_CLASS,
            '''Condition statements for the current policy statement''',
            False, 
            [
            _MetaInfoClassMember('bgp-conditions', REFERENCE_CLASS, 'BgpConditions', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions',
                [], [],
                '''                Top-level container 
                ''',
                'bgp_conditions',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.Config',
                [], [],
                '''                Configuration data for policy conditions
                ''',
                'config',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('igp-conditions', REFERENCE_CLASS, 'IgpConditions', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.IgpConditions',
                [], [],
                '''                Policy conditions for IGP attributes
                ''',
                'igp_conditions',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('match-interface', REFERENCE_CLASS, 'MatchInterface', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface',
                [], [],
                '''                Top-level container for interface match conditions
                ''',
                'match_interface',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('match-neighbor-set', REFERENCE_CLASS, 'MatchNeighborSet', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet',
                [], [],
                '''                Match a referenced neighbor set according to the logic
                defined in the match-set-options-leaf
                ''',
                'match_neighbor_set',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('match-prefix-set', REFERENCE_CLASS, 'MatchPrefixSet', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet',
                [], [],
                '''                Match a referenced prefix-set according to the logic
                defined in the match-set-options leaf
                ''',
                'match_prefix_set',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('match-tag-set', REFERENCE_CLASS, 'MatchTagSet', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet',
                [], [],
                '''                Match a referenced tag set according to the logic defined
                in the match-options-set leaf
                ''',
                'match_tag_set',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.State',
                [], [],
                '''                Operational state data for policy conditions
                ''',
                'state',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'conditions',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.Config', REFERENCE_CLASS,
            '''Configuration data for policy actions''',
            False, 
            [
            _MetaInfoClassMember('accept-route', ATTRIBUTE, 'Empty', 'empty',
                None, None,
                [], [],
                '''                accepts the route into the routing table
                ''',
                'accept_route',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('reject-route', ATTRIBUTE, 'Empty', 'empty',
                None, None,
                [], [],
                '''                rejects the route
                ''',
                'reject_route',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'config',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.State', REFERENCE_CLASS,
            '''Operational state data for policy actions''',
            False, 
            [
            _MetaInfoClassMember('accept-route', ATTRIBUTE, 'Empty', 'empty',
                None, None,
                [], [],
                '''                accepts the route into the routing table
                ''',
                'accept_route',
                'openconfig-routing-policy', False, is_config=False),
            _MetaInfoClassMember('reject-route', ATTRIBUTE, 'Empty', 'empty',
                None, None,
                [], [],
                '''                rejects the route
                ''',
                'reject_route',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'state',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions.Config', REFERENCE_CLASS,
            '''Configuration data ''',
            False, 
            [
            _MetaInfoClassMember('set-tag', REFERENCE_UNION, 'str', 'oc-pol-types:tag-type',
                None, None,
                [], [],
                '''                Set the tag value for OSPF or IS-IS routes.
                ''',
                'set_tag',
                'openconfig-routing-policy', False, [
                    _MetaInfoClassMember('set-tag', ATTRIBUTE, 'int', 'uint32',
                        None, None,
                        [('0', '4294967295')], [],
                        '''                        Set the tag value for OSPF or IS-IS routes.
                        ''',
                        'set_tag',
                        'openconfig-routing-policy', False),
                    _MetaInfoClassMember('set-tag', ATTRIBUTE, 'str', 'yang:hex-string',
                        None, None,
                        [], [b'([0-9a-fA-F]{2}(:[0-9a-fA-F]{2})*)?'],
                        '''                        Set the tag value for OSPF or IS-IS routes.
                        ''',
                        'set_tag',
                        'openconfig-routing-policy', False),
                ]),
            ],
            'openconfig-routing-policy',
            'config',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions.State', REFERENCE_CLASS,
            '''Operational state data ''',
            False, 
            [
            _MetaInfoClassMember('set-tag', REFERENCE_UNION, 'str', 'oc-pol-types:tag-type',
                None, None,
                [], [],
                '''                Set the tag value for OSPF or IS-IS routes.
                ''',
                'set_tag',
                'openconfig-routing-policy', False, [
                    _MetaInfoClassMember('set-tag', ATTRIBUTE, 'int', 'uint32',
                        None, None,
                        [('0', '4294967295')], [],
                        '''                        Set the tag value for OSPF or IS-IS routes.
                        ''',
                        'set_tag',
                        'openconfig-routing-policy', False, is_config=False),
                    _MetaInfoClassMember('set-tag', ATTRIBUTE, 'str', 'yang:hex-string',
                        None, None,
                        [], [b'([0-9a-fA-F]{2}(:[0-9a-fA-F]{2})*)?'],
                        '''                        Set the tag value for OSPF or IS-IS routes.
                        ''',
                        'set_tag',
                        'openconfig-routing-policy', False, is_config=False),
                ], is_config=False),
            ],
            'openconfig-routing-policy',
            'state',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions', REFERENCE_CLASS,
            '''Actions to set IGP route attributes; these actions
apply to multiple IGPs''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions.Config',
                [], [],
                '''                Configuration data 
                ''',
                'config',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions.State',
                [], [],
                '''                Operational state data 
                ''',
                'state',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'igp-actions',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.Config', REFERENCE_CLASS,
            '''Configuration data for BGP-specific actions''',
            False, 
            [
            _MetaInfoClassMember('set-local-pref', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                set the local pref attribute on the route
                update
                ''',
                'set_local_pref',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('set-med', REFERENCE_UNION, 'str', 'bgp-set-med-type',
                None, None,
                [], [],
                '''                set the med metric attribute in the route
                update
                ''',
                'set_med',
                'openconfig-bgp-policy', False, [
                    _MetaInfoClassMember('set-med', ATTRIBUTE, 'int', 'uint32',
                        None, None,
                        [('0', '4294967295')], [],
                        '''                        set the med metric attribute in the route
                        update
                        ''',
                        'set_med',
                        'openconfig-bgp-policy', False),
                    _MetaInfoClassMember('set-med', ATTRIBUTE, 'str', 'string',
                        None, None,
                        [], [b'^[+-][0-9]+'],
                        '''                        set the med metric attribute in the route
                        update
                        ''',
                        'set_med',
                        'openconfig-bgp-policy', False),
                    _MetaInfoClassMember('set-med', REFERENCE_ENUM_CLASS, 'BgpSetMedTypeEnum', 'enumeration',
                        'ydk.models.ydktest.openconfig_bgp_policy', 'BgpSetMedTypeEnum',
                        [], [],
                        '''                        set the med metric attribute in the route
                        update
                        ''',
                        'set_med',
                        'openconfig-bgp-policy', False),
                ]),
            _MetaInfoClassMember('set-next-hop', REFERENCE_UNION, 'str', 'bgp-next-hop-type',
                None, None,
                [], [],
                '''                set the next-hop attribute in the route update
                ''',
                'set_next_hop',
                'openconfig-bgp-policy', False, [
                    _MetaInfoClassMember('set-next-hop', REFERENCE_UNION, 'str', 'inet:ip-address-no-zone',
                        None, None,
                        [], [],
                        '''                        set the next-hop attribute in the route update
                        ''',
                        'set_next_hop',
                        'openconfig-bgp-policy', False, [
                            _MetaInfoClassMember('set-next-hop', ATTRIBUTE, 'str', 'inet:ipv4-address-no-zone',
                                None, None,
                                [], [b'(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(%[\\p{N}\\p{L}]+)?'],
                                '''                                set the next-hop attribute in the route update
                                ''',
                                'set_next_hop',
                                'openconfig-bgp-policy', False),
                            _MetaInfoClassMember('set-next-hop', ATTRIBUTE, 'str', 'inet:ipv6-address-no-zone',
                                None, None,
                                [], [b'((:|[0-9a-fA-F]{0,4}):)([0-9a-fA-F]{0,4}:){0,5}((([0-9a-fA-F]{0,4}:)?(:|[0-9a-fA-F]{0,4}))|(((25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])))(%[\\p{N}\\p{L}]+)?'],
                                '''                                set the next-hop attribute in the route update
                                ''',
                                'set_next_hop',
                                'openconfig-bgp-policy', False),
                        ]),
                    _MetaInfoClassMember('set-next-hop', REFERENCE_ENUM_CLASS, 'BgpNextHopTypeEnum', 'enumeration',
                        'ydk.models.ydktest.openconfig_bgp_policy', 'BgpNextHopTypeEnum',
                        [], [],
                        '''                        set the next-hop attribute in the route update
                        ''',
                        'set_next_hop',
                        'openconfig-bgp-policy', False),
                ]),
            _MetaInfoClassMember('set-route-origin', REFERENCE_ENUM_CLASS, 'BgpOriginAttrTypeEnum', 'oc-bgp-types:bgp-origin-attr-type',
                'ydk.models.ydktest.openconfig_bgp_types', 'BgpOriginAttrTypeEnum',
                [], [],
                '''                set the origin attribute to the specified
                value
                ''',
                'set_route_origin',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.State', REFERENCE_CLASS,
            '''Operational state data for BGP-specific actions''',
            False, 
            [
            _MetaInfoClassMember('set-local-pref', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                set the local pref attribute on the route
                update
                ''',
                'set_local_pref',
                'openconfig-bgp-policy', False, is_config=False),
            _MetaInfoClassMember('set-med', REFERENCE_UNION, 'str', 'bgp-set-med-type',
                None, None,
                [], [],
                '''                set the med metric attribute in the route
                update
                ''',
                'set_med',
                'openconfig-bgp-policy', False, [
                    _MetaInfoClassMember('set-med', ATTRIBUTE, 'int', 'uint32',
                        None, None,
                        [('0', '4294967295')], [],
                        '''                        set the med metric attribute in the route
                        update
                        ''',
                        'set_med',
                        'openconfig-bgp-policy', False, is_config=False),
                    _MetaInfoClassMember('set-med', ATTRIBUTE, 'str', 'string',
                        None, None,
                        [], [b'^[+-][0-9]+'],
                        '''                        set the med metric attribute in the route
                        update
                        ''',
                        'set_med',
                        'openconfig-bgp-policy', False, is_config=False),
                    _MetaInfoClassMember('set-med', REFERENCE_ENUM_CLASS, 'BgpSetMedTypeEnum', 'enumeration',
                        'ydk.models.ydktest.openconfig_bgp_policy', 'BgpSetMedTypeEnum',
                        [], [],
                        '''                        set the med metric attribute in the route
                        update
                        ''',
                        'set_med',
                        'openconfig-bgp-policy', False, is_config=False),
                ], is_config=False),
            _MetaInfoClassMember('set-next-hop', REFERENCE_UNION, 'str', 'bgp-next-hop-type',
                None, None,
                [], [],
                '''                set the next-hop attribute in the route update
                ''',
                'set_next_hop',
                'openconfig-bgp-policy', False, [
                    _MetaInfoClassMember('set-next-hop', REFERENCE_UNION, 'str', 'inet:ip-address-no-zone',
                        None, None,
                        [], [],
                        '''                        set the next-hop attribute in the route update
                        ''',
                        'set_next_hop',
                        'openconfig-bgp-policy', False, [
                            _MetaInfoClassMember('set-next-hop', ATTRIBUTE, 'str', 'inet:ipv4-address-no-zone',
                                None, None,
                                [], [b'(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(%[\\p{N}\\p{L}]+)?'],
                                '''                                set the next-hop attribute in the route update
                                ''',
                                'set_next_hop',
                                'openconfig-bgp-policy', False, is_config=False),
                            _MetaInfoClassMember('set-next-hop', ATTRIBUTE, 'str', 'inet:ipv6-address-no-zone',
                                None, None,
                                [], [b'((:|[0-9a-fA-F]{0,4}):)([0-9a-fA-F]{0,4}:){0,5}((([0-9a-fA-F]{0,4}:)?(:|[0-9a-fA-F]{0,4}))|(((25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])))(%[\\p{N}\\p{L}]+)?'],
                                '''                                set the next-hop attribute in the route update
                                ''',
                                'set_next_hop',
                                'openconfig-bgp-policy', False, is_config=False),
                        ], is_config=False),
                    _MetaInfoClassMember('set-next-hop', REFERENCE_ENUM_CLASS, 'BgpNextHopTypeEnum', 'enumeration',
                        'ydk.models.ydktest.openconfig_bgp_policy', 'BgpNextHopTypeEnum',
                        [], [],
                        '''                        set the next-hop attribute in the route update
                        ''',
                        'set_next_hop',
                        'openconfig-bgp-policy', False, is_config=False),
                ], is_config=False),
            _MetaInfoClassMember('set-route-origin', REFERENCE_ENUM_CLASS, 'BgpOriginAttrTypeEnum', 'oc-bgp-types:bgp-origin-attr-type',
                'ydk.models.ydktest.openconfig_bgp_types', 'BgpOriginAttrTypeEnum',
                [], [],
                '''                set the origin attribute to the specified
                value
                ''',
                'set_route_origin',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend.Config', REFERENCE_CLASS,
            '''Configuration data for the AS path prepend action''',
            False, 
            [
            _MetaInfoClassMember('repeat-n', ATTRIBUTE, 'int', 'uint8',
                None, None,
                [('1', '255')], [],
                '''                Number of times to prepend the local AS number to the AS
                path.  The value should be between 1 and the maximum
                supported by the implementation.
                ''',
                'repeat_n',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend.State', REFERENCE_CLASS,
            '''Operational state data for the AS path prepend action''',
            False, 
            [
            _MetaInfoClassMember('repeat-n', ATTRIBUTE, 'int', 'uint8',
                None, None,
                [('1', '255')], [],
                '''                Number of times to prepend the local AS number to the AS
                path.  The value should be between 1 and the maximum
                supported by the implementation.
                ''',
                'repeat_n',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend', REFERENCE_CLASS,
            '''action to prepend local AS number to the AS-path a
specified number of times''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend.Config',
                [], [],
                '''                Configuration data for the AS path prepend action
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend.State',
                [], [],
                '''                Operational state data for the AS path prepend action
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'set-as-path-prepend',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Config.MethodEnum' : _MetaInfoEnum('MethodEnum',
        'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Config.MethodEnum',
        '''Indicates the method used to specify the extended
communities for the set-ext-community action''',
        {
            'INLINE':'INLINE',
            'REFERENCE':'REFERENCE',
        }, 'openconfig-bgp-policy', _yang_ns._namespaces['openconfig-bgp-policy']),
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Config', REFERENCE_CLASS,
            '''Configuration data for the set-community action''',
            False, 
            [
            _MetaInfoClassMember('method', REFERENCE_ENUM_CLASS, 'MethodEnum', 'enumeration',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Config.MethodEnum',
                [], [],
                '''                Indicates the method used to specify the extended
                communities for the set-ext-community action
                ''',
                'method',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('options', REFERENCE_ENUM_CLASS, 'BgpSetCommunityOptionTypeEnum', 'bgp-set-community-option-type',
                'ydk.models.ydktest.openconfig_bgp_policy', 'BgpSetCommunityOptionTypeEnum',
                [], [],
                '''                Options for modifying the community attribute with
                the specified values.  These options apply to both
                methods of setting the community attribute.
                ''',
                'options',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.State.MethodEnum' : _MetaInfoEnum('MethodEnum',
        'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.State.MethodEnum',
        '''Indicates the method used to specify the extended
communities for the set-ext-community action''',
        {
            'INLINE':'INLINE',
            'REFERENCE':'REFERENCE',
        }, 'openconfig-bgp-policy', _yang_ns._namespaces['openconfig-bgp-policy']),
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.State', REFERENCE_CLASS,
            '''Operational state data for the set-community action''',
            False, 
            [
            _MetaInfoClassMember('method', REFERENCE_ENUM_CLASS, 'MethodEnum', 'enumeration',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.State.MethodEnum',
                [], [],
                '''                Indicates the method used to specify the extended
                communities for the set-ext-community action
                ''',
                'method',
                'openconfig-bgp-policy', False, is_config=False),
            _MetaInfoClassMember('options', REFERENCE_ENUM_CLASS, 'BgpSetCommunityOptionTypeEnum', 'bgp-set-community-option-type',
                'ydk.models.ydktest.openconfig_bgp_policy', 'BgpSetCommunityOptionTypeEnum',
                [], [],
                '''                Options for modifying the community attribute with
                the specified values.  These options apply to both
                methods of setting the community attribute.
                ''',
                'options',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline.Config', REFERENCE_CLASS,
            '''Configuration data or inline specification of set-community
action''',
            False, 
            [
            _MetaInfoClassMember('communities', REFERENCE_UNION, 'str', 'union',
                None, None,
                [], [],
                '''                Set the community values for the update inline with
                a list.
                ''',
                'communities',
                'openconfig-bgp-policy', False, [
                    _MetaInfoClassMember('communities', REFERENCE_UNION, 'str', 'oc-bgp-types:bgp-std-community-type',
                        None, None,
                        [], [],
                        '''                        Set the community values for the update inline with
                        a list.
                        ''',
                        'communities',
                        'openconfig-bgp-policy', False, [
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'int', 'uint32',
                                None, None,
                                [('65536', '4294901759')], [],
                                '''                                Set the community values for the update inline with
                                a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False),
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'([0-9]+:[0-9]+)'],
                                '''                                Set the community values for the update inline with
                                a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False),
                        ]),
                    _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'Bgp_Well_Known_Std_CommunityIdentity', 'oc-bgp-types:bgp-well-known-community-type',
                        'ydk.models.ydktest.openconfig_bgp_types', 'Bgp_Well_Known_Std_CommunityIdentity',
                        [], [],
                        '''                        Set the community values for the update inline with
                        a list.
                        ''',
                        'communities',
                        'openconfig-bgp-policy', False),
                ]),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline.State', REFERENCE_CLASS,
            '''Operational state data or inline specification of
set-community action''',
            False, 
            [
            _MetaInfoClassMember('communities', REFERENCE_UNION, 'str', 'union',
                None, None,
                [], [],
                '''                Set the community values for the update inline with
                a list.
                ''',
                'communities',
                'openconfig-bgp-policy', False, [
                    _MetaInfoClassMember('communities', REFERENCE_UNION, 'str', 'oc-bgp-types:bgp-std-community-type',
                        None, None,
                        [], [],
                        '''                        Set the community values for the update inline with
                        a list.
                        ''',
                        'communities',
                        'openconfig-bgp-policy', False, [
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'int', 'uint32',
                                None, None,
                                [('65536', '4294901759')], [],
                                '''                                Set the community values for the update inline with
                                a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False, is_config=False),
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'([0-9]+:[0-9]+)'],
                                '''                                Set the community values for the update inline with
                                a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False, is_config=False),
                        ], is_config=False),
                    _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'Bgp_Well_Known_Std_CommunityIdentity', 'oc-bgp-types:bgp-well-known-community-type',
                        'ydk.models.ydktest.openconfig_bgp_types', 'Bgp_Well_Known_Std_CommunityIdentity',
                        [], [],
                        '''                        Set the community values for the update inline with
                        a list.
                        ''',
                        'communities',
                        'openconfig-bgp-policy', False, is_config=False),
                ], is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline', REFERENCE_CLASS,
            '''Set the community values for the action inline with
a list.''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline.Config',
                [], [],
                '''                Configuration data or inline specification of set-community
                action
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline.State',
                [], [],
                '''                Operational state data or inline specification of
                set-community action
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'inline',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference.Config', REFERENCE_CLASS,
            '''Configuration data for referening a community-set in the
set-community action''',
            False, 
            [
            _MetaInfoClassMember('community-set-ref', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined community set by name
                ''',
                'community_set_ref',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference.State', REFERENCE_CLASS,
            '''Operational state data for referening a community-set
in the set-community action''',
            False, 
            [
            _MetaInfoClassMember('community-set-ref', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined community set by name
                ''',
                'community_set_ref',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference', REFERENCE_CLASS,
            '''Provide a reference to a defined community set for the
set-community action''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference.Config',
                [], [],
                '''                Configuration data for referening a community-set in the
                set-community action
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference.State',
                [], [],
                '''                Operational state data for referening a community-set
                in the set-community action
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'reference',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity', REFERENCE_CLASS,
            '''Action to set the community attributes of the route, along
with options to modify how the community is modified.
Communities may be set using an inline list OR
reference to an existing defined set (not both).''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Config',
                [], [],
                '''                Configuration data for the set-community action
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('inline', REFERENCE_CLASS, 'Inline', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline',
                [], [],
                '''                Set the community values for the action inline with
                a list.
                ''',
                'inline',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('reference', REFERENCE_CLASS, 'Reference', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference',
                [], [],
                '''                Provide a reference to a defined community set for the
                set-community action
                ''',
                'reference',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.State',
                [], [],
                '''                Operational state data for the set-community action
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'set-community',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Config.MethodEnum' : _MetaInfoEnum('MethodEnum',
        'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Config.MethodEnum',
        '''Indicates the method used to specify the extended
communities for the set-ext-community action''',
        {
            'INLINE':'INLINE',
            'REFERENCE':'REFERENCE',
        }, 'openconfig-bgp-policy', _yang_ns._namespaces['openconfig-bgp-policy']),
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Config', REFERENCE_CLASS,
            '''Configuration data for the set-ext-community action''',
            False, 
            [
            _MetaInfoClassMember('method', REFERENCE_ENUM_CLASS, 'MethodEnum', 'enumeration',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Config.MethodEnum',
                [], [],
                '''                Indicates the method used to specify the extended
                communities for the set-ext-community action
                ''',
                'method',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('options', REFERENCE_ENUM_CLASS, 'BgpSetCommunityOptionTypeEnum', 'bgp-set-community-option-type',
                'ydk.models.ydktest.openconfig_bgp_policy', 'BgpSetCommunityOptionTypeEnum',
                [], [],
                '''                Options for modifying the community attribute with
                the specified values.  These options apply to both
                methods of setting the community attribute.
                ''',
                'options',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.State.MethodEnum' : _MetaInfoEnum('MethodEnum',
        'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.State.MethodEnum',
        '''Indicates the method used to specify the extended
communities for the set-ext-community action''',
        {
            'INLINE':'INLINE',
            'REFERENCE':'REFERENCE',
        }, 'openconfig-bgp-policy', _yang_ns._namespaces['openconfig-bgp-policy']),
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.State', REFERENCE_CLASS,
            '''Operational state data for the set-ext-community action''',
            False, 
            [
            _MetaInfoClassMember('method', REFERENCE_ENUM_CLASS, 'MethodEnum', 'enumeration',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.State.MethodEnum',
                [], [],
                '''                Indicates the method used to specify the extended
                communities for the set-ext-community action
                ''',
                'method',
                'openconfig-bgp-policy', False, is_config=False),
            _MetaInfoClassMember('options', REFERENCE_ENUM_CLASS, 'BgpSetCommunityOptionTypeEnum', 'bgp-set-community-option-type',
                'ydk.models.ydktest.openconfig_bgp_policy', 'BgpSetCommunityOptionTypeEnum',
                [], [],
                '''                Options for modifying the community attribute with
                the specified values.  These options apply to both
                methods of setting the community attribute.
                ''',
                'options',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline.Config', REFERENCE_CLASS,
            '''Configuration data or inline specification of
set-ext-community action''',
            False, 
            [
            _MetaInfoClassMember('communities', REFERENCE_UNION, 'str', 'union',
                None, None,
                [], [],
                '''                Set the extended community values for the update inline
                with a list.
                ''',
                'communities',
                'openconfig-bgp-policy', False, [
                    _MetaInfoClassMember('communities', REFERENCE_UNION, 'str', 'oc-bgp-types:bgp-ext-community-type',
                        None, None,
                        [], [],
                        '''                        Set the extended community values for the update inline
                        with a list.
                        ''',
                        'communities',
                        'openconfig-bgp-policy', False, [
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9]):(4[0-2][0-9][0-4][0-9][0-6][0-7][0-2][0-9][0-6]|[1-3][0-9]{9}|[1-9]([0-9]{1,7})?[0-9]|[1-9])'],
                                '''                                Set the extended community values for the update inline
                                with a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False),
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5]):(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9])'],
                                '''                                Set the extended community values for the update inline
                                with a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False),
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-target:(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9]):(4[0-2][0-9][0-4][0-9][0-6][0-7][0-2][0-9][0-6]|[1-3][0-9]{9}|[1-9]([0-9]{1,7})?[0-9]|[1-9])'],
                                '''                                Set the extended community values for the update inline
                                with a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False),
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-target:(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5]):(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9])'],
                                '''                                Set the extended community values for the update inline
                                with a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False),
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-origin:(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9]):(4[0-2][0-9][0-4][0-9][0-6][0-7][0-2][0-9][0-6]|[1-3][0-9]{9}|[1-9]([0-9]{1,7})?[0-9]|[1-9])'],
                                '''                                Set the extended community values for the update inline
                                with a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False),
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-origin:(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5]):(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9])'],
                                '''                                Set the extended community values for the update inline
                                with a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False),
                        ]),
                    _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'Bgp_Well_Known_Std_CommunityIdentity', 'oc-bgp-types:bgp-well-known-community-type',
                        'ydk.models.ydktest.openconfig_bgp_types', 'Bgp_Well_Known_Std_CommunityIdentity',
                        [], [],
                        '''                        Set the extended community values for the update inline
                        with a list.
                        ''',
                        'communities',
                        'openconfig-bgp-policy', False),
                ]),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline.State', REFERENCE_CLASS,
            '''Operational state data or inline specification of
set-ext-community action''',
            False, 
            [
            _MetaInfoClassMember('communities', REFERENCE_UNION, 'str', 'union',
                None, None,
                [], [],
                '''                Set the extended community values for the update inline
                with a list.
                ''',
                'communities',
                'openconfig-bgp-policy', False, [
                    _MetaInfoClassMember('communities', REFERENCE_UNION, 'str', 'oc-bgp-types:bgp-ext-community-type',
                        None, None,
                        [], [],
                        '''                        Set the extended community values for the update inline
                        with a list.
                        ''',
                        'communities',
                        'openconfig-bgp-policy', False, [
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9]):(4[0-2][0-9][0-4][0-9][0-6][0-7][0-2][0-9][0-6]|[1-3][0-9]{9}|[1-9]([0-9]{1,7})?[0-9]|[1-9])'],
                                '''                                Set the extended community values for the update inline
                                with a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False, is_config=False),
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5]):(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9])'],
                                '''                                Set the extended community values for the update inline
                                with a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False, is_config=False),
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-target:(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9]):(4[0-2][0-9][0-4][0-9][0-6][0-7][0-2][0-9][0-6]|[1-3][0-9]{9}|[1-9]([0-9]{1,7})?[0-9]|[1-9])'],
                                '''                                Set the extended community values for the update inline
                                with a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False, is_config=False),
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-target:(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5]):(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9])'],
                                '''                                Set the extended community values for the update inline
                                with a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False, is_config=False),
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-origin:(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9]):(4[0-2][0-9][0-4][0-9][0-6][0-7][0-2][0-9][0-6]|[1-3][0-9]{9}|[1-9]([0-9]{1,7})?[0-9]|[1-9])'],
                                '''                                Set the extended community values for the update inline
                                with a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False, is_config=False),
                            _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'str', 'string',
                                None, None,
                                [], [b'route\\-origin:(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5]):(6[0-5][0-5][0-3][0-5]|[1-5][0-9]{4}|[1-9][0-9]{1,4}|[0-9])'],
                                '''                                Set the extended community values for the update inline
                                with a list.
                                ''',
                                'communities',
                                'openconfig-bgp-policy', False, is_config=False),
                        ], is_config=False),
                    _MetaInfoClassMember('communities', REFERENCE_LEAFLIST, 'Bgp_Well_Known_Std_CommunityIdentity', 'oc-bgp-types:bgp-well-known-community-type',
                        'ydk.models.ydktest.openconfig_bgp_types', 'Bgp_Well_Known_Std_CommunityIdentity',
                        [], [],
                        '''                        Set the extended community values for the update inline
                        with a list.
                        ''',
                        'communities',
                        'openconfig-bgp-policy', False, is_config=False),
                ], is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline', REFERENCE_CLASS,
            '''Set the extended community values for the action inline with
a list.''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline.Config',
                [], [],
                '''                Configuration data or inline specification of
                set-ext-community action
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline.State',
                [], [],
                '''                Operational state data or inline specification of
                set-ext-community action
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'inline',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference.Config' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference.Config', REFERENCE_CLASS,
            '''Configuration data for referening an extended
community-set in the set-ext-community action''',
            False, 
            [
            _MetaInfoClassMember('ext-community-set-ref', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined extended community set by
                name
                ''',
                'ext_community_set_ref',
                'openconfig-bgp-policy', False),
            ],
            'openconfig-bgp-policy',
            'config',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference.State' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference.State', REFERENCE_CLASS,
            '''Operational state data for referening an extended
community-set in the set-ext-community action''',
            False, 
            [
            _MetaInfoClassMember('ext-community-set-ref', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References a defined extended community set by
                name
                ''',
                'ext_community_set_ref',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'state',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference', REFERENCE_CLASS,
            '''Provide a reference to an extended community set for the
set-ext-community action''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference.Config',
                [], [],
                '''                Configuration data for referening an extended
                community-set in the set-ext-community action
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference.State',
                [], [],
                '''                Operational state data for referening an extended
                community-set in the set-ext-community action
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'reference',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity', REFERENCE_CLASS,
            '''Action to set the extended community attributes of the
route, along with options to modify how the community is
modified. Extended communities may be set using an inline
list OR a reference to an existing defined set (but not
both).''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Config',
                [], [],
                '''                Configuration data for the set-ext-community action
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('inline', REFERENCE_CLASS, 'Inline', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline',
                [], [],
                '''                Set the extended community values for the action inline with
                a list.
                ''',
                'inline',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('reference', REFERENCE_CLASS, 'Reference', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference',
                [], [],
                '''                Provide a reference to an extended community set for the
                set-ext-community action
                ''',
                'reference',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.State',
                [], [],
                '''                Operational state data for the set-ext-community action
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'set-ext-community',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions', REFERENCE_CLASS,
            '''Top-level container for BGP-specific actions''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.Config',
                [], [],
                '''                Configuration data for BGP-specific actions
                ''',
                'config',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('set-as-path-prepend', REFERENCE_CLASS, 'SetAsPathPrepend', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend',
                [], [],
                '''                action to prepend local AS number to the AS-path a
                specified number of times
                ''',
                'set_as_path_prepend',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('set-community', REFERENCE_CLASS, 'SetCommunity', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity',
                [], [],
                '''                Action to set the community attributes of the route, along
                with options to modify how the community is modified.
                Communities may be set using an inline list OR
                reference to an existing defined set (not both).
                ''',
                'set_community',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('set-ext-community', REFERENCE_CLASS, 'SetExtCommunity', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity',
                [], [],
                '''                Action to set the extended community attributes of the
                route, along with options to modify how the community is
                modified. Extended communities may be set using an inline
                list OR a reference to an existing defined set (but not
                both).
                ''',
                'set_ext_community',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.State',
                [], [],
                '''                Operational state data for BGP-specific actions
                ''',
                'state',
                'openconfig-bgp-policy', False, is_config=False),
            ],
            'openconfig-bgp-policy',
            'bgp-actions',
            _yang_ns._namespaces['openconfig-bgp-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions', REFERENCE_CLASS,
            '''Top-level container for policy action statements''',
            False, 
            [
            _MetaInfoClassMember('bgp-actions', REFERENCE_CLASS, 'BgpActions', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions',
                [], [],
                '''                Top-level container for BGP-specific actions
                ''',
                'bgp_actions',
                'openconfig-bgp-policy', False),
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.Config',
                [], [],
                '''                Configuration data for policy actions
                ''',
                'config',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('igp-actions', REFERENCE_CLASS, 'IgpActions', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions',
                [], [],
                '''                Actions to set IGP route attributes; these actions
                apply to multiple IGPs
                ''',
                'igp_actions',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.State',
                [], [],
                '''                Operational state data for policy actions
                ''',
                'state',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'actions',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement', REFERENCE_LIST,
            '''Policy statements group conditions and actions
within a policy definition.  They are evaluated in
the order specified (see the description of policy
evaluation at the top of this module.''',
            False, 
            [
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                Reference to list key
                ''',
                'name',
                'openconfig-routing-policy', True),
            _MetaInfoClassMember('actions', REFERENCE_CLASS, 'Actions', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions',
                [], [],
                '''                Top-level container for policy action statements
                ''',
                'actions',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('conditions', REFERENCE_CLASS, 'Conditions', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions',
                [], [],
                '''                Condition statements for the current policy statement
                ''',
                'conditions',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Config',
                [], [],
                '''                Configuration data for policy statements
                ''',
                'config',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.State',
                [], [],
                '''                Operational state data for policy statements
                ''',
                'state',
                'openconfig-routing-policy', False, is_config=False),
            ],
            'openconfig-routing-policy',
            'statement',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements', REFERENCE_CLASS,
            '''Enclosing container for policy statements''',
            False, 
            [
            _MetaInfoClassMember('statement', REFERENCE_LIST, 'Statement', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement',
                [], [],
                '''                Policy statements group conditions and actions
                within a policy definition.  They are evaluated in
                the order specified (see the description of policy
                evaluation at the top of this module.
                ''',
                'statement',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'statements',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions.PolicyDefinition' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions.PolicyDefinition', REFERENCE_LIST,
            '''List of top-level policy definitions, keyed by unique
name.  These policy definitions are expected to be
referenced (by name) in policy chains specified in import
or export configuration statements.''',
            False, 
            [
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                Reference to the list key
                ''',
                'name',
                'openconfig-routing-policy', True),
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Config',
                [], [],
                '''                Configuration data for policy defintions
                ''',
                'config',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.State',
                [], [],
                '''                Operational state data for policy definitions
                ''',
                'state',
                'openconfig-routing-policy', False, is_config=False),
            _MetaInfoClassMember('statements', REFERENCE_CLASS, 'Statements', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements',
                [], [],
                '''                Enclosing container for policy statements
                ''',
                'statements',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'policy-definition',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy.PolicyDefinitions' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy.PolicyDefinitions', REFERENCE_CLASS,
            '''Enclosing container for the list of top-level policy
 definitions''',
            False, 
            [
            _MetaInfoClassMember('policy-definition', REFERENCE_LIST, 'PolicyDefinition', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions.PolicyDefinition',
                [], [],
                '''                List of top-level policy definitions, keyed by unique
                name.  These policy definitions are expected to be
                referenced (by name) in policy chains specified in import
                or export configuration statements.
                ''',
                'policy_definition',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'policy-definitions',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
    'RoutingPolicy' : {
        'meta_info' : _MetaInfoClass('RoutingPolicy', REFERENCE_CLASS,
            '''Top-level container for all routing policy configuration''',
            False, 
            [
            _MetaInfoClassMember('defined-sets', REFERENCE_CLASS, 'DefinedSets', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.DefinedSets',
                [], [],
                '''                Predefined sets of attributes used in policy match
                statements
                ''',
                'defined_sets',
                'openconfig-routing-policy', False),
            _MetaInfoClassMember('policy-definitions', REFERENCE_CLASS, 'PolicyDefinitions', '',
                'ydk.models.ydktest.openconfig_routing_policy', 'RoutingPolicy.PolicyDefinitions',
                [], [],
                '''                Enclosing container for the list of top-level policy
                 definitions
                ''',
                'policy_definitions',
                'openconfig-routing-policy', False),
            ],
            'openconfig-routing-policy',
            'routing-policy',
            _yang_ns._namespaces['openconfig-routing-policy'],
            'ydk.models.ydktest.openconfig_routing_policy'
        ),
    },
}
_meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.Config']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.State']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Config']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.State']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.PrefixSets']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.Config']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.NeighborSets.NeighborSet']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.State']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.NeighborSets.NeighborSet']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.NeighborSets.NeighborSet']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.NeighborSets']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.TagSets.TagSet.Config']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.TagSets.TagSet']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.TagSets.TagSet.State']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.TagSets.TagSet']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.TagSets.TagSet']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.TagSets']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.Config']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.State']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.Config']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.State']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.Config']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.State']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.PrefixSets']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.NeighborSets']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.TagSets']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets']['meta_info']
_meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets']['meta_info'].parent =_meta_table['RoutingPolicy.DefinedSets']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.IgpConditions']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Config']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.State']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition']['meta_info'].parent =_meta_table['RoutingPolicy.PolicyDefinitions']['meta_info']
_meta_table['RoutingPolicy.DefinedSets']['meta_info'].parent =_meta_table['RoutingPolicy']['meta_info']
_meta_table['RoutingPolicy.PolicyDefinitions']['meta_info'].parent =_meta_table['RoutingPolicy']['meta_info']
