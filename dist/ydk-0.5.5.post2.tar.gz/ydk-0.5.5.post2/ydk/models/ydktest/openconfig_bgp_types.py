""" openconfig_bgp_types 

This module contains general data definitions for use in BGP
policy. It can be imported by modules that make use of BGP
attributes

"""


import re
import collections

from enum import Enum

from ydk.types import Empty, YList, YLeafList, DELETE, Decimal64, FixedBitsDict

from ydk.errors import YPYError, YPYModelError



class BgpOriginAttrTypeEnum(Enum):
    """
    BgpOriginAttrTypeEnum

    Type definition for standard BGP origin attribute

    .. data:: IGP = 0

    	Origin of the NLRI is internal

    .. data:: EGP = 1

    	Origin of the NLRI is EGP

    .. data:: INCOMPLETE = 2

    	Origin of the NLRI is neither IGP or EGP

    """

    IGP = 0

    EGP = 1

    INCOMPLETE = 2


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['BgpOriginAttrTypeEnum']


class BgpSessionDirectionEnum(Enum):
    """
    BgpSessionDirectionEnum

    Type to describe the direction of NLRI transmission

    .. data:: INBOUND = 0

    	Refers to all NLRI received from the BGP peer

    .. data:: OUTBOUND = 1

    	Refers to all NLRI advertised to the BGP peer

    """

    INBOUND = 0

    OUTBOUND = 1


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['BgpSessionDirectionEnum']


class CommunityTypeEnum(Enum):
    """
    CommunityTypeEnum

    type describing variations of community attributes\:

    STANDARD\: standard BGP community [rfc1997]

    EXTENDED\: extended BGP community [rfc4360]

    BOTH\: both standard and extended community

    .. data:: STANDARD = 0

    	send only standard communities

    .. data:: EXTENDED = 1

    	send only extended communities

    .. data:: BOTH = 2

    	send both standard and extended communities

    .. data:: NONE = 3

    	do not send any community attribute

    """

    STANDARD = 0

    EXTENDED = 1

    BOTH = 2

    NONE = 3


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['CommunityTypeEnum']


class PeerTypeEnum(Enum):
    """
    PeerTypeEnum

    labels a peer or peer group as explicitly internal or

    external

    .. data:: INTERNAL = 0

    	internal (iBGP) peer

    .. data:: EXTERNAL = 1

    	external (eBGP) peer

    """

    INTERNAL = 0

    EXTERNAL = 1


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['PeerTypeEnum']



class Bgp_CapabilityIdentity(object):
    """
    Base identity for a BGP capability
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        pass

    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['Bgp_CapabilityIdentity']['meta_info']


class Afi_Safi_TypeIdentity(object):
    """
    Base identity type for AFI,SAFI tuples for BGP\-4
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        pass

    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['Afi_Safi_TypeIdentity']['meta_info']


class Bgp_Well_Known_Std_CommunityIdentity(object):
    """
    Reserved communities within the standard community space
    defined by RFC1997. These communities must fall within the
    range 0x00000000 to 0xFFFFFFFF
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        pass

    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['Bgp_Well_Known_Std_CommunityIdentity']['meta_info']


class Remove_Private_As_OptionIdentity(object):
    """
    Base identity for options for removing private autonomous
    system numbers from the AS\_PATH attribute
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        pass

    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['Remove_Private_As_OptionIdentity']['meta_info']


class MpbgpIdentity(Bgp_CapabilityIdentity):
    """
    Multi\-protocol extensions to BGP
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Bgp_CapabilityIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['MpbgpIdentity']['meta_info']


class Route_RefreshIdentity(Bgp_CapabilityIdentity):
    """
    The BGP route\-refresh functionality
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Bgp_CapabilityIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['Route_RefreshIdentity']['meta_info']


class Asn32Identity(Bgp_CapabilityIdentity):
    """
    4\-byte (32\-bit) AS number functionality
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Bgp_CapabilityIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['Asn32Identity']['meta_info']


class Graceful_RestartIdentity(Bgp_CapabilityIdentity):
    """
    Graceful restart functionality
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Bgp_CapabilityIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['Graceful_RestartIdentity']['meta_info']


class Add_PathsIdentity(Bgp_CapabilityIdentity):
    """
    BGP add\-paths
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Bgp_CapabilityIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['Add_PathsIdentity']['meta_info']


class Ipv4_UnicastIdentity(Afi_Safi_TypeIdentity):
    """
    IPv4 unicast (AFI,SAFI = 1,1)
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Afi_Safi_TypeIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['Ipv4_UnicastIdentity']['meta_info']


class Ipv6_UnicastIdentity(Afi_Safi_TypeIdentity):
    """
    IPv6 unicast (AFI,SAFI = 2,1)
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Afi_Safi_TypeIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['Ipv6_UnicastIdentity']['meta_info']


class Ipv4_Labeled_UnicastIdentity(Afi_Safi_TypeIdentity):
    """
    Labeled IPv4 unicast (AFI,SAFI = 1,4)
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Afi_Safi_TypeIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['Ipv4_Labeled_UnicastIdentity']['meta_info']


class Ipv6_Labeled_UnicastIdentity(Afi_Safi_TypeIdentity):
    """
    Labeled IPv6 unicast (AFI,SAFI = 2,4)
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Afi_Safi_TypeIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['Ipv6_Labeled_UnicastIdentity']['meta_info']


class L3Vpn_Ipv4_UnicastIdentity(Afi_Safi_TypeIdentity):
    """
    Unicast IPv4 MPLS L3VPN (AFI,SAFI = 1,128)
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Afi_Safi_TypeIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['L3Vpn_Ipv4_UnicastIdentity']['meta_info']


class L3Vpn_Ipv6_UnicastIdentity(Afi_Safi_TypeIdentity):
    """
    Unicast IPv6 MPLS L3VPN (AFI,SAFI = 2,128)
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Afi_Safi_TypeIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['L3Vpn_Ipv6_UnicastIdentity']['meta_info']


class L3Vpn_Ipv4_MulticastIdentity(Afi_Safi_TypeIdentity):
    """
    Multicast IPv4 MPLS L3VPN (AFI,SAFI = 1,129)
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Afi_Safi_TypeIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['L3Vpn_Ipv4_MulticastIdentity']['meta_info']


class L3Vpn_Ipv6_MulticastIdentity(Afi_Safi_TypeIdentity):
    """
    Multicast IPv6 MPLS L3VPN (AFI,SAFI = 2,129)
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Afi_Safi_TypeIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['L3Vpn_Ipv6_MulticastIdentity']['meta_info']


class L2Vpn_VplsIdentity(Afi_Safi_TypeIdentity):
    """
    BGP\-signalled VPLS (AFI,SAFI = 25,65)
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Afi_Safi_TypeIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['L2Vpn_VplsIdentity']['meta_info']


class L2Vpn_EvpnIdentity(Afi_Safi_TypeIdentity):
    """
    BGP MPLS Based Ethernet VPN (AFI,SAFI = 25,70)
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Afi_Safi_TypeIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['L2Vpn_EvpnIdentity']['meta_info']


class No_ExportIdentity(Bgp_Well_Known_Std_CommunityIdentity):
    """
    Do not export NLRI received carrying this community outside
    the bounds of this autonomous system, or this confederation if
    the local autonomous system is a confederation member AS. This
    community has a value of 0xFFFFFF01.
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Bgp_Well_Known_Std_CommunityIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['No_ExportIdentity']['meta_info']


class No_AdvertiseIdentity(Bgp_Well_Known_Std_CommunityIdentity):
    """
    All NLRI received carrying this community must not be
    advertised to other BGP peers. This community has a value of
    0xFFFFFF02.
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Bgp_Well_Known_Std_CommunityIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['No_AdvertiseIdentity']['meta_info']


class No_Export_SubconfedIdentity(Bgp_Well_Known_Std_CommunityIdentity):
    """
    All NLRI received carrying this community must not be
    advertised to external BGP peers \- including over confederation
    sub\-AS boundaries. This community has a value of 0xFFFFFF03.
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Bgp_Well_Known_Std_CommunityIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['No_Export_SubconfedIdentity']['meta_info']


class NopeerIdentity(Bgp_Well_Known_Std_CommunityIdentity):
    """
    An autonomous system receiving NLRI tagged with this community
    is advised not to readvertise the NLRI to external bi\-lateral
    peer autonomous systems. An AS may also filter received NLRI
    from bilateral peer sessions when they are tagged with this
    community value
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Bgp_Well_Known_Std_CommunityIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['NopeerIdentity']['meta_info']


class Private_As_Remove_AllIdentity(Remove_Private_As_OptionIdentity):
    """
    Strip all private autonmous system numbers from the AS\_PATH.
    This action is performed regardless of the other content of the
    AS\_PATH attribute, and for all instances of private AS numbers
    within that attribute.
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Remove_Private_As_OptionIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['Private_As_Remove_AllIdentity']['meta_info']


class Private_As_Replace_AllIdentity(Remove_Private_As_OptionIdentity):
    """
    Replace all instances of private autonomous system numbers in
    the AS\_PATH with the local BGP speaker's autonomous system
    number. This action is performed regardless of the other
    content of the AS\_PATH attribute, and for all instances of
    private AS number within that attribute.
    
    

    """

    _prefix = 'oc-bgp-types'
    _revision = '2016-06-21'

    def __init__(self):
        Remove_Private_As_OptionIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_bgp_types as meta
        return meta._meta_table['Private_As_Replace_AllIdentity']['meta_info']


