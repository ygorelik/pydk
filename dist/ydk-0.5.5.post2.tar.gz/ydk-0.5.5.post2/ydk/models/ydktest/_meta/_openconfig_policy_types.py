
import re
import collections

from enum import Enum

from ydk._core._dm_meta_info import _MetaInfoClassMember, _MetaInfoClass, _MetaInfoEnum
from ydk._core._dm_meta_info import ATTRIBUTE, REFERENCE_CLASS, REFERENCE_LIST, REFERENCE_LEAFLIST, ANYXML_CLASS
from ydk._core._dm_meta_info import REFERENCE_IDENTITY_CLASS, REFERENCE_ENUM_CLASS, REFERENCE_BITS, REFERENCE_UNION

from ydk.types import Empty, YList, YLeafList, DELETE, Decimal64, FixedBitsDict
from ydk.errors import YPYError, YPYModelError
from ydk.providers._importer import _yang_ns

_meta_table = {
    'MatchSetOptionsTypeEnum' : _MetaInfoEnum('MatchSetOptionsTypeEnum',
        'ydk.models.ydktest.openconfig_policy_types', 'MatchSetOptionsTypeEnum',
        '''Options that govern the behavior of a match statement.  The
default behavior is ANY, i.e., the given value matches any
of the members of the defined set''',
        {
            'ANY':'ANY',
            'ALL':'ALL',
            'INVERT':'INVERT',
        }, 'openconfig-policy-types', _yang_ns._namespaces['openconfig-policy-types']),
    'MatchSetOptionsRestrictedTypeEnum' : _MetaInfoEnum('MatchSetOptionsRestrictedTypeEnum',
        'ydk.models.ydktest.openconfig_policy_types', 'MatchSetOptionsRestrictedTypeEnum',
        '''Options that govern the behavior of a match statement.  The
default behavior is ANY, i.e., the given value matches any
of the members of the defined set.  Note this type is a
restricted version of the match-set-options-type.''',
        {
            'ANY':'ANY',
            'INVERT':'INVERT',
        }, 'openconfig-policy-types', _yang_ns._namespaces['openconfig-policy-types']),
    'Attribute_ComparisonIdentity' : {
        'meta_info' : _MetaInfoClass('Attribute_ComparisonIdentity', REFERENCE_IDENTITY_CLASS,
            '''base type for supported comparison operators on route
attributes''',
            False, 
            [
            ],
            'openconfig-policy-types',
            'ATTRIBUTE_COMPARISON',
            _yang_ns._namespaces['openconfig-policy-types'],
            'ydk.models.ydktest.openconfig_policy_types'
        ),
    },
    'Install_Protocol_TypeIdentity' : {
        'meta_info' : _MetaInfoClass('Install_Protocol_TypeIdentity', REFERENCE_IDENTITY_CLASS,
            '''Base type for protocols which can install prefixes into the
RIB''',
            False, 
            [
            ],
            'openconfig-policy-types',
            'INSTALL_PROTOCOL_TYPE',
            _yang_ns._namespaces['openconfig-policy-types'],
            'ydk.models.ydktest.openconfig_policy_types'
        ),
    },
    'Attribute_EqIdentity' : {
        'meta_info' : _MetaInfoClass('Attribute_EqIdentity', REFERENCE_IDENTITY_CLASS,
            '''== comparison''',
            False, 
            [
            ],
            'openconfig-policy-types',
            'ATTRIBUTE_EQ',
            _yang_ns._namespaces['openconfig-policy-types'],
            'ydk.models.ydktest.openconfig_policy_types'
        ),
    },
    'Attribute_GeIdentity' : {
        'meta_info' : _MetaInfoClass('Attribute_GeIdentity', REFERENCE_IDENTITY_CLASS,
            '''>= comparison''',
            False, 
            [
            ],
            'openconfig-policy-types',
            'ATTRIBUTE_GE',
            _yang_ns._namespaces['openconfig-policy-types'],
            'ydk.models.ydktest.openconfig_policy_types'
        ),
    },
    'Attribute_LeIdentity' : {
        'meta_info' : _MetaInfoClass('Attribute_LeIdentity', REFERENCE_IDENTITY_CLASS,
            '''<= comparison''',
            False, 
            [
            ],
            'openconfig-policy-types',
            'ATTRIBUTE_LE',
            _yang_ns._namespaces['openconfig-policy-types'],
            'ydk.models.ydktest.openconfig_policy_types'
        ),
    },
    'BgpIdentity' : {
        'meta_info' : _MetaInfoClass('BgpIdentity', REFERENCE_IDENTITY_CLASS,
            '''BGP''',
            False, 
            [
            ],
            'openconfig-policy-types',
            'BGP',
            _yang_ns._namespaces['openconfig-policy-types'],
            'ydk.models.ydktest.openconfig_policy_types'
        ),
    },
    'IsisIdentity' : {
        'meta_info' : _MetaInfoClass('IsisIdentity', REFERENCE_IDENTITY_CLASS,
            '''IS-IS''',
            False, 
            [
            ],
            'openconfig-policy-types',
            'ISIS',
            _yang_ns._namespaces['openconfig-policy-types'],
            'ydk.models.ydktest.openconfig_policy_types'
        ),
    },
    'OspfIdentity' : {
        'meta_info' : _MetaInfoClass('OspfIdentity', REFERENCE_IDENTITY_CLASS,
            '''OSPFv2''',
            False, 
            [
            ],
            'openconfig-policy-types',
            'OSPF',
            _yang_ns._namespaces['openconfig-policy-types'],
            'ydk.models.ydktest.openconfig_policy_types'
        ),
    },
    'Ospf3Identity' : {
        'meta_info' : _MetaInfoClass('Ospf3Identity', REFERENCE_IDENTITY_CLASS,
            '''OSPFv3''',
            False, 
            [
            ],
            'openconfig-policy-types',
            'OSPF3',
            _yang_ns._namespaces['openconfig-policy-types'],
            'ydk.models.ydktest.openconfig_policy_types'
        ),
    },
    'StaticIdentity' : {
        'meta_info' : _MetaInfoClass('StaticIdentity', REFERENCE_IDENTITY_CLASS,
            '''Locally-installed static route''',
            False, 
            [
            ],
            'openconfig-policy-types',
            'STATIC',
            _yang_ns._namespaces['openconfig-policy-types'],
            'ydk.models.ydktest.openconfig_policy_types'
        ),
    },
    'Directly_ConnectedIdentity' : {
        'meta_info' : _MetaInfoClass('Directly_ConnectedIdentity', REFERENCE_IDENTITY_CLASS,
            '''A directly connected route''',
            False, 
            [
            ],
            'openconfig-policy-types',
            'DIRECTLY_CONNECTED',
            _yang_ns._namespaces['openconfig-policy-types'],
            'ydk.models.ydktest.openconfig_policy_types'
        ),
    },
    'Local_AggregateIdentity' : {
        'meta_info' : _MetaInfoClass('Local_AggregateIdentity', REFERENCE_IDENTITY_CLASS,
            '''Locally defined aggregate route''',
            False, 
            [
            ],
            'openconfig-policy-types',
            'LOCAL_AGGREGATE',
            _yang_ns._namespaces['openconfig-policy-types'],
            'ydk.models.ydktest.openconfig_policy_types'
        ),
    },
}
