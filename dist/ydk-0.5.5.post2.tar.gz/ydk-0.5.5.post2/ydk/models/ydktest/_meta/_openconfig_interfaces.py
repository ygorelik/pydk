
import re
import collections

from enum import Enum

from ydk._core._dm_meta_info import _MetaInfoClassMember, _MetaInfoClass, _MetaInfoEnum
from ydk._core._dm_meta_info import ATTRIBUTE, REFERENCE_CLASS, REFERENCE_LIST, REFERENCE_LEAFLIST, ANYXML_CLASS
from ydk._core._dm_meta_info import REFERENCE_IDENTITY_CLASS, REFERENCE_ENUM_CLASS, REFERENCE_BITS, REFERENCE_UNION

from ydk.types import Empty, YList, YLeafList, DELETE, Decimal64, FixedBitsDict
from ydk.errors import YPYError, YPYModelError
from ydk.providers._importer import _yang_ns

_meta_table = {
    'Interfaces.Interface.Config' : {
        'meta_info' : _MetaInfoClass('Interfaces.Interface.Config', REFERENCE_CLASS,
            '''Configurable items at the global, physical interface
level''',
            False, 
            [
            _MetaInfoClassMember('description', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                A textual description of the interface.
                
                A server implementation MAY map this leaf to the ifAlias
                MIB object.  Such an implementation needs to use some
                mechanism to handle the differences in size and characters
                allowed between this leaf and ifAlias.  The definition of
                such a mechanism is outside the scope of this document.
                
                Since ifAlias is defined to be stored in non-volatile
                storage, the MIB implementation MUST map ifAlias to the
                value of 'description' in the persistently stored
                datastore.
                
                Specifically, if the device supports ':startup', when
                ifAlias is read the device MUST return the value of
                'description' in the 'startup' datastore, and when it is
                written, it MUST be written to the 'running' and 'startup'
                datastores.  Note that it is up to the implementation to
                
                decide whether to modify this single leaf in 'startup' or
                perform an implicit copy-config from 'running' to
                'startup'.
                
                If the device does not support ':startup', ifAlias MUST
                be mapped to the 'description' leaf in the 'running'
                datastore.
                ''',
                'description',
                'openconfig-interfaces', False),
            _MetaInfoClassMember('enabled', ATTRIBUTE, 'bool', 'boolean',
                None, None,
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                This leaf contains the configured, desired state of the
                interface.
                
                Systems that implement the IF-MIB use the value of this
                leaf in the 'running' datastore to set
                IF-MIB.ifAdminStatus to 'up' or 'down' after an ifEntry
                has been initialized, as described in RFC 2863.
                
                Changes in this leaf in the 'running' datastore are
                reflected in ifAdminStatus, but if ifAdminStatus is
                changed over SNMP, this leaf is not affected.
                ''',
                'enabled',
                'openconfig-interfaces', False, default_value='True'),
            _MetaInfoClassMember('mtu', ATTRIBUTE, 'int', 'uint16',
                None, None,
                [('0', '65535')], [],
                '''                Set the max transmission unit size in octets
                for the physical interface.  If this is not set, the mtu is
                set to the operational default -- e.g., 1514 bytes on an
                Ethernet interface.
                ''',
                'mtu',
                'openconfig-interfaces', False),
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The name of the interface.
                
                A device MAY restrict the allowed values for this leaf,
                possibly depending on the type of the interface.
                For system-controlled interfaces, this leaf is the
                device-specific name of the interface.  The 'config false'
                list interfaces/interface[name]/state contains the currently
                existing interfaces on the device.
                
                If a client tries to create configuration for a
                system-controlled interface that is not present in the
                corresponding state list, the server MAY reject
                the request if the implementation does not support
                pre-provisioning of interfaces or if the name refers to
                an interface that can never exist in the system.  A
                NETCONF server MUST reply with an rpc-error with the
                error-tag 'invalid-value' in this case.
                
                The IETF model in RFC 7223 provides YANG features for the
                following (i.e., pre-provisioning and arbitrary-names),
                however they are omitted here:
                
                 If the device supports pre-provisioning of interface
                 configuration, the 'pre-provisioning' feature is
                 advertised.
                
                 If the device allows arbitrarily named user-controlled
                 interfaces, the 'arbitrary-names' feature is advertised.
                
                When a configured user-controlled interface is created by
                the system, it is instantiated with the same name in the
                /interfaces/interface[name]/state list.
                ''',
                'name',
                'openconfig-interfaces', False),
            _MetaInfoClassMember('type', REFERENCE_IDENTITY_CLASS, 'InterfaceTypeIdentity', 'identityref',
                'ydk.models.ydktest.ietf_interfaces', 'InterfaceTypeIdentity',
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The type of the interface.
                
                When an interface entry is created, a server MAY
                initialize the type leaf with a valid value, e.g., if it
                is possible to derive the type from the name of the
                interface.
                
                If a client tries to set the type of an interface to a
                value that can never be used by the system, e.g., if the
                type is not supported or if the type does not match the
                name of the interface, the server MUST reject the request.
                A NETCONF server MUST reply with an rpc-error with the
                error-tag 'invalid-value' in this case.
                ''',
                'type',
                'openconfig-interfaces', False),
            ],
            'openconfig-interfaces',
            'config',
            _yang_ns._namespaces['openconfig-interfaces'],
            'ydk.models.ydktest.openconfig_interfaces'
        ),
    },
    'Interfaces.Interface.State.Counters' : {
        'meta_info' : _MetaInfoClass('Interfaces.Interface.State.Counters', REFERENCE_CLASS,
            '''A collection of interface-related statistics objects.''',
            False, 
            [
            _MetaInfoClassMember('in-broadcast-pkts', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The number of packets, delivered by this sub-layer to a
                higher (sub-)layer, that were addressed to a broadcast
                address at this sub-layer.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'in_broadcast_pkts',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('in-discards', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                Changed the counter type to counter64.
                
                The number of inbound packets that were chosen to be
                discarded even though no errors had been detected to
                prevent their being deliverable to a higher-layer
                protocol.  One possible reason for discarding such a
                packet could be to free up buffer space.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'in_discards',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('in-errors', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                Changed the counter type to counter64.
                
                For packet-oriented interfaces, the number of inbound
                packets that contained errors preventing them from being
                deliverable to a higher-layer protocol.  For character-
                oriented or fixed-length interfaces, the number of
                inbound transmission units that contained errors
                preventing them from being deliverable to a higher-layer
                protocol.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'in_errors',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('in-multicast-pkts', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                
                The number of packets, delivered by this sub-layer to a
                higher (sub-)layer, that were addressed to a multicast
                address at this sub-layer.  For a MAC-layer protocol,
                this includes both Group and Functional addresses.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'in_multicast_pkts',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('in-octets', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The total number of octets received on the interface,
                including framing characters.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'in_octets',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('in-unicast-pkts', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The number of packets, delivered by this sub-layer to a
                higher (sub-)layer, that were not addressed to a
                multicast or broadcast address at this sub-layer.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'in_unicast_pkts',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('in-unknown-protos', ATTRIBUTE, 'int', 'yang:counter32',
                None, None,
                [('0', '4294967295')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                Changed the counter type to counter64.
                
                For packet-oriented interfaces, the number of packets
                received via the interface that were discarded because
                of an unknown or unsupported protocol.  For
                character-oriented or fixed-length interfaces that
                support protocol multiplexing, the number of
                transmission units received via the interface that were
                discarded because of an unknown or unsupported protocol.
                For any interface that does not support protocol
                multiplexing, this counter is not present.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'in_unknown_protos',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('last-clear', ATTRIBUTE, 'str', 'yang:date-and-time',
                None, None,
                [], [b'\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?(Z|[\\+\\-]\\d{2}:\\d{2})'],
                '''                Indicates the last time the interface counters were
                cleared.
                ''',
                'last_clear',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('out-broadcast-pkts', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The total number of packets that higher-level protocols
                requested be transmitted, and that were addressed to a
                broadcast address at this sub-layer, including those
                that were discarded or not sent.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'out_broadcast_pkts',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('out-discards', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                Changed the counter type to counter64.
                
                The number of outbound packets that were chosen to be
                discarded even though no errors had been detected to
                prevent their being transmitted.  One possible reason
                for discarding such a packet could be to free up buffer
                space.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'out_discards',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('out-errors', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                Changed the counter type to counter64.
                
                For packet-oriented interfaces, the number of outbound
                packets that could not be transmitted because of errors.
                For character-oriented or fixed-length interfaces, the
                number of outbound transmission units that could not be
                transmitted because of errors.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'out_errors',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('out-multicast-pkts', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                Changed the counter type to counter64.
                
                The total number of packets that higher-level protocols
                requested be transmitted, and that were addressed to a
                multicast address at this sub-layer, including those
                that were discarded or not sent.  For a MAC-layer
                protocol, this includes both Group and Functional
                addresses.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'out_multicast_pkts',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('out-octets', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                Changed the counter type to counter64.
                
                The total number of octets transmitted out of the
                interface, including framing characters.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'out_octets',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('out-unicast-pkts', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The total number of packets that higher-level protocols
                requested be transmitted, and that were not addressed
                to a multicast or broadcast address at this sub-layer,
                including those that were discarded or not sent.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'out_unicast_pkts',
                'openconfig-interfaces', False, is_config=False),
            ],
            'openconfig-interfaces',
            'counters',
            _yang_ns._namespaces['openconfig-interfaces'],
            'ydk.models.ydktest.openconfig_interfaces'
        ),
    },
    'Interfaces.Interface.State.AdminStatusEnum' : _MetaInfoEnum('AdminStatusEnum',
        'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.State.AdminStatusEnum',
        '''[adapted from IETF interfaces model (RFC 7223)]

The desired state of the interface.  In RFC 7223 this leaf
has the same read semantics as ifAdminStatus.  Here, it
reflects the administrative state as set by enabling or
disabling the interface.''',
        {
            'UP':'UP',
            'DOWN':'DOWN',
            'TESTING':'TESTING',
        }, 'openconfig-interfaces', _yang_ns._namespaces['openconfig-interfaces']),
    'Interfaces.Interface.State.OperStatusEnum' : _MetaInfoEnum('OperStatusEnum',
        'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.State.OperStatusEnum',
        '''[adapted from IETF interfaces model (RFC 7223)]

The current operational state of the interface.

This leaf has the same semantics as ifOperStatus.''',
        {
            'UP':'UP',
            'DOWN':'DOWN',
            'TESTING':'TESTING',
            'UNKNOWN':'UNKNOWN',
            'DORMANT':'DORMANT',
            'NOT_PRESENT':'NOT_PRESENT',
            'LOWER_LAYER_DOWN':'LOWER_LAYER_DOWN',
        }, 'openconfig-interfaces', _yang_ns._namespaces['openconfig-interfaces']),
    'Interfaces.Interface.State' : {
        'meta_info' : _MetaInfoClass('Interfaces.Interface.State', REFERENCE_CLASS,
            '''Operational state data at the global interface level''',
            False, 
            [
            _MetaInfoClassMember('admin-status', REFERENCE_ENUM_CLASS, 'AdminStatusEnum', 'enumeration',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.State.AdminStatusEnum',
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The desired state of the interface.  In RFC 7223 this leaf
                has the same read semantics as ifAdminStatus.  Here, it
                reflects the administrative state as set by enabling or
                disabling the interface.
                ''',
                'admin_status',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('counters', REFERENCE_CLASS, 'Counters', '',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.State.Counters',
                [], [],
                '''                A collection of interface-related statistics objects.
                ''',
                'counters',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('description', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                A textual description of the interface.
                
                A server implementation MAY map this leaf to the ifAlias
                MIB object.  Such an implementation needs to use some
                mechanism to handle the differences in size and characters
                allowed between this leaf and ifAlias.  The definition of
                such a mechanism is outside the scope of this document.
                
                Since ifAlias is defined to be stored in non-volatile
                storage, the MIB implementation MUST map ifAlias to the
                value of 'description' in the persistently stored
                datastore.
                
                Specifically, if the device supports ':startup', when
                ifAlias is read the device MUST return the value of
                'description' in the 'startup' datastore, and when it is
                written, it MUST be written to the 'running' and 'startup'
                datastores.  Note that it is up to the implementation to
                
                decide whether to modify this single leaf in 'startup' or
                perform an implicit copy-config from 'running' to
                'startup'.
                
                If the device does not support ':startup', ifAlias MUST
                be mapped to the 'description' leaf in the 'running'
                datastore.
                ''',
                'description',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('enabled', ATTRIBUTE, 'bool', 'boolean',
                None, None,
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                This leaf contains the configured, desired state of the
                interface.
                
                Systems that implement the IF-MIB use the value of this
                leaf in the 'running' datastore to set
                IF-MIB.ifAdminStatus to 'up' or 'down' after an ifEntry
                has been initialized, as described in RFC 2863.
                
                Changes in this leaf in the 'running' datastore are
                reflected in ifAdminStatus, but if ifAdminStatus is
                changed over SNMP, this leaf is not affected.
                ''',
                'enabled',
                'openconfig-interfaces', False, default_value='True', is_config=False),
            _MetaInfoClassMember('ifindex', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                System assigned number for each interface.  Corresponds to
                ifIndex object in SNMP Interface MIB
                ''',
                'ifindex',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('last-change', ATTRIBUTE, 'int', 'yang:timeticks',
                None, None,
                [('0', '4294967295')], [],
                '''                Date and time of the last state change of the interface
                (e.g., up-to-down transition).   This corresponds to the
                ifLastChange object in the standard interface MIB.
                ''',
                'last_change',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('mtu', ATTRIBUTE, 'int', 'uint16',
                None, None,
                [('0', '65535')], [],
                '''                Set the max transmission unit size in octets
                for the physical interface.  If this is not set, the mtu is
                set to the operational default -- e.g., 1514 bytes on an
                Ethernet interface.
                ''',
                'mtu',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The name of the interface.
                
                A device MAY restrict the allowed values for this leaf,
                possibly depending on the type of the interface.
                For system-controlled interfaces, this leaf is the
                device-specific name of the interface.  The 'config false'
                list interfaces/interface[name]/state contains the currently
                existing interfaces on the device.
                
                If a client tries to create configuration for a
                system-controlled interface that is not present in the
                corresponding state list, the server MAY reject
                the request if the implementation does not support
                pre-provisioning of interfaces or if the name refers to
                an interface that can never exist in the system.  A
                NETCONF server MUST reply with an rpc-error with the
                error-tag 'invalid-value' in this case.
                
                The IETF model in RFC 7223 provides YANG features for the
                following (i.e., pre-provisioning and arbitrary-names),
                however they are omitted here:
                
                 If the device supports pre-provisioning of interface
                 configuration, the 'pre-provisioning' feature is
                 advertised.
                
                 If the device allows arbitrarily named user-controlled
                 interfaces, the 'arbitrary-names' feature is advertised.
                
                When a configured user-controlled interface is created by
                the system, it is instantiated with the same name in the
                /interfaces/interface[name]/state list.
                ''',
                'name',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('oper-status', REFERENCE_ENUM_CLASS, 'OperStatusEnum', 'enumeration',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.State.OperStatusEnum',
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The current operational state of the interface.
                
                This leaf has the same semantics as ifOperStatus.
                ''',
                'oper_status',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('type', REFERENCE_IDENTITY_CLASS, 'InterfaceTypeIdentity', 'identityref',
                'ydk.models.ydktest.ietf_interfaces', 'InterfaceTypeIdentity',
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The type of the interface.
                
                When an interface entry is created, a server MAY
                initialize the type leaf with a valid value, e.g., if it
                is possible to derive the type from the name of the
                interface.
                
                If a client tries to set the type of an interface to a
                value that can never be used by the system, e.g., if the
                type is not supported or if the type does not match the
                name of the interface, the server MUST reject the request.
                A NETCONF server MUST reply with an rpc-error with the
                error-tag 'invalid-value' in this case.
                ''',
                'type',
                'openconfig-interfaces', False, is_config=False),
            ],
            'openconfig-interfaces',
            'state',
            _yang_ns._namespaces['openconfig-interfaces'],
            'ydk.models.ydktest.openconfig_interfaces'
        ),
    },
    'Interfaces.Interface.HoldTime.Config' : {
        'meta_info' : _MetaInfoClass('Interfaces.Interface.HoldTime.Config', REFERENCE_CLASS,
            '''Configuration data for interface hold-time settings.''',
            False, 
            [
            _MetaInfoClassMember('down', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                Dampens advertisement when the interface transitions from
                up to down.  A zero value means dampening is turned off,
                i.e., immediate notification.
                ''',
                'down',
                'openconfig-interfaces', False, default_value="0"),
            _MetaInfoClassMember('up', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                Dampens advertisement when the interface
                transitions from down to up.  A zero value means dampening
                is turned off, i.e., immediate notification.
                ''',
                'up',
                'openconfig-interfaces', False, default_value="0"),
            ],
            'openconfig-interfaces',
            'config',
            _yang_ns._namespaces['openconfig-interfaces'],
            'ydk.models.ydktest.openconfig_interfaces'
        ),
    },
    'Interfaces.Interface.HoldTime.State' : {
        'meta_info' : _MetaInfoClass('Interfaces.Interface.HoldTime.State', REFERENCE_CLASS,
            '''Operational state data for interface hold-time.''',
            False, 
            [
            _MetaInfoClassMember('down', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                Dampens advertisement when the interface transitions from
                up to down.  A zero value means dampening is turned off,
                i.e., immediate notification.
                ''',
                'down',
                'openconfig-interfaces', False, default_value="0", is_config=False),
            _MetaInfoClassMember('up', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                Dampens advertisement when the interface
                transitions from down to up.  A zero value means dampening
                is turned off, i.e., immediate notification.
                ''',
                'up',
                'openconfig-interfaces', False, default_value="0", is_config=False),
            ],
            'openconfig-interfaces',
            'state',
            _yang_ns._namespaces['openconfig-interfaces'],
            'ydk.models.ydktest.openconfig_interfaces'
        ),
    },
    'Interfaces.Interface.HoldTime' : {
        'meta_info' : _MetaInfoClass('Interfaces.Interface.HoldTime', REFERENCE_CLASS,
            '''Top-level container for hold-time settings to enable
dampening advertisements of interface transitions.''',
            False, 
            [
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.HoldTime.Config',
                [], [],
                '''                Configuration data for interface hold-time settings.
                ''',
                'config',
                'openconfig-interfaces', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.HoldTime.State',
                [], [],
                '''                Operational state data for interface hold-time.
                ''',
                'state',
                'openconfig-interfaces', False, is_config=False),
            ],
            'openconfig-interfaces',
            'hold-time',
            _yang_ns._namespaces['openconfig-interfaces'],
            'ydk.models.ydktest.openconfig_interfaces'
        ),
    },
    'Interfaces.Interface.Subinterfaces.Subinterface.Config' : {
        'meta_info' : _MetaInfoClass('Interfaces.Interface.Subinterfaces.Subinterface.Config', REFERENCE_CLASS,
            '''Configurable items at the subinterface level''',
            False, 
            [
            _MetaInfoClassMember('description', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                A textual description of the interface.
                
                A server implementation MAY map this leaf to the ifAlias
                MIB object.  Such an implementation needs to use some
                mechanism to handle the differences in size and characters
                allowed between this leaf and ifAlias.  The definition of
                such a mechanism is outside the scope of this document.
                
                Since ifAlias is defined to be stored in non-volatile
                storage, the MIB implementation MUST map ifAlias to the
                value of 'description' in the persistently stored
                datastore.
                
                Specifically, if the device supports ':startup', when
                ifAlias is read the device MUST return the value of
                'description' in the 'startup' datastore, and when it is
                written, it MUST be written to the 'running' and 'startup'
                datastores.  Note that it is up to the implementation to
                
                decide whether to modify this single leaf in 'startup' or
                perform an implicit copy-config from 'running' to
                'startup'.
                
                If the device does not support ':startup', ifAlias MUST
                be mapped to the 'description' leaf in the 'running'
                datastore.
                ''',
                'description',
                'openconfig-interfaces', False),
            _MetaInfoClassMember('enabled', ATTRIBUTE, 'bool', 'boolean',
                None, None,
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                This leaf contains the configured, desired state of the
                interface.
                
                Systems that implement the IF-MIB use the value of this
                leaf in the 'running' datastore to set
                IF-MIB.ifAdminStatus to 'up' or 'down' after an ifEntry
                has been initialized, as described in RFC 2863.
                
                Changes in this leaf in the 'running' datastore are
                reflected in ifAdminStatus, but if ifAdminStatus is
                changed over SNMP, this leaf is not affected.
                ''',
                'enabled',
                'openconfig-interfaces', False, default_value='True'),
            _MetaInfoClassMember('index', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                The index of the subinterface, or logical interface number.
                On systems with no support for subinterfaces, or not using
                subinterfaces, this value should default to 0, i.e., the
                default subinterface.
                ''',
                'index',
                'openconfig-interfaces', False, default_value="0"),
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The name of the interface.
                
                A device MAY restrict the allowed values for this leaf,
                possibly depending on the type of the interface.
                For system-controlled interfaces, this leaf is the
                device-specific name of the interface.  The 'config false'
                list interfaces/interface[name]/state contains the currently
                existing interfaces on the device.
                
                If a client tries to create configuration for a
                system-controlled interface that is not present in the
                corresponding state list, the server MAY reject
                the request if the implementation does not support
                pre-provisioning of interfaces or if the name refers to
                an interface that can never exist in the system.  A
                NETCONF server MUST reply with an rpc-error with the
                error-tag 'invalid-value' in this case.
                
                The IETF model in RFC 7223 provides YANG features for the
                following (i.e., pre-provisioning and arbitrary-names),
                however they are omitted here:
                
                 If the device supports pre-provisioning of interface
                 configuration, the 'pre-provisioning' feature is
                 advertised.
                
                 If the device allows arbitrarily named user-controlled
                 interfaces, the 'arbitrary-names' feature is advertised.
                
                When a configured user-controlled interface is created by
                the system, it is instantiated with the same name in the
                /interfaces/interface[name]/state list.
                ''',
                'name',
                'openconfig-interfaces', False),
            ],
            'openconfig-interfaces',
            'config',
            _yang_ns._namespaces['openconfig-interfaces'],
            'ydk.models.ydktest.openconfig_interfaces'
        ),
    },
    'Interfaces.Interface.Subinterfaces.Subinterface.State.Counters' : {
        'meta_info' : _MetaInfoClass('Interfaces.Interface.Subinterfaces.Subinterface.State.Counters', REFERENCE_CLASS,
            '''A collection of interface-related statistics objects.''',
            False, 
            [
            _MetaInfoClassMember('in-broadcast-pkts', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The number of packets, delivered by this sub-layer to a
                higher (sub-)layer, that were addressed to a broadcast
                address at this sub-layer.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'in_broadcast_pkts',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('in-discards', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                Changed the counter type to counter64.
                
                The number of inbound packets that were chosen to be
                discarded even though no errors had been detected to
                prevent their being deliverable to a higher-layer
                protocol.  One possible reason for discarding such a
                packet could be to free up buffer space.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'in_discards',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('in-errors', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                Changed the counter type to counter64.
                
                For packet-oriented interfaces, the number of inbound
                packets that contained errors preventing them from being
                deliverable to a higher-layer protocol.  For character-
                oriented or fixed-length interfaces, the number of
                inbound transmission units that contained errors
                preventing them from being deliverable to a higher-layer
                protocol.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'in_errors',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('in-multicast-pkts', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                
                The number of packets, delivered by this sub-layer to a
                higher (sub-)layer, that were addressed to a multicast
                address at this sub-layer.  For a MAC-layer protocol,
                this includes both Group and Functional addresses.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'in_multicast_pkts',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('in-octets', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The total number of octets received on the interface,
                including framing characters.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'in_octets',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('in-unicast-pkts', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The number of packets, delivered by this sub-layer to a
                higher (sub-)layer, that were not addressed to a
                multicast or broadcast address at this sub-layer.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'in_unicast_pkts',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('in-unknown-protos', ATTRIBUTE, 'int', 'yang:counter32',
                None, None,
                [('0', '4294967295')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                Changed the counter type to counter64.
                
                For packet-oriented interfaces, the number of packets
                received via the interface that were discarded because
                of an unknown or unsupported protocol.  For
                character-oriented or fixed-length interfaces that
                support protocol multiplexing, the number of
                transmission units received via the interface that were
                discarded because of an unknown or unsupported protocol.
                For any interface that does not support protocol
                multiplexing, this counter is not present.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'in_unknown_protos',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('last-clear', ATTRIBUTE, 'str', 'yang:date-and-time',
                None, None,
                [], [b'\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?(Z|[\\+\\-]\\d{2}:\\d{2})'],
                '''                Indicates the last time the interface counters were
                cleared.
                ''',
                'last_clear',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('out-broadcast-pkts', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The total number of packets that higher-level protocols
                requested be transmitted, and that were addressed to a
                broadcast address at this sub-layer, including those
                that were discarded or not sent.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'out_broadcast_pkts',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('out-discards', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                Changed the counter type to counter64.
                
                The number of outbound packets that were chosen to be
                discarded even though no errors had been detected to
                prevent their being transmitted.  One possible reason
                for discarding such a packet could be to free up buffer
                space.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'out_discards',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('out-errors', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                Changed the counter type to counter64.
                
                For packet-oriented interfaces, the number of outbound
                packets that could not be transmitted because of errors.
                For character-oriented or fixed-length interfaces, the
                number of outbound transmission units that could not be
                transmitted because of errors.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'out_errors',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('out-multicast-pkts', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                Changed the counter type to counter64.
                
                The total number of packets that higher-level protocols
                requested be transmitted, and that were addressed to a
                multicast address at this sub-layer, including those
                that were discarded or not sent.  For a MAC-layer
                protocol, this includes both Group and Functional
                addresses.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'out_multicast_pkts',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('out-octets', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                Changed the counter type to counter64.
                
                The total number of octets transmitted out of the
                interface, including framing characters.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'out_octets',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('out-unicast-pkts', ATTRIBUTE, 'int', 'yang:counter64',
                None, None,
                [('0', '18446744073709551615')], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The total number of packets that higher-level protocols
                requested be transmitted, and that were not addressed
                to a multicast or broadcast address at this sub-layer,
                including those that were discarded or not sent.
                
                Discontinuities in the value of this counter can occur
                at re-initialization of the management system, and at
                other times as indicated by the value of
                'discontinuity-time'.
                ''',
                'out_unicast_pkts',
                'openconfig-interfaces', False, is_config=False),
            ],
            'openconfig-interfaces',
            'counters',
            _yang_ns._namespaces['openconfig-interfaces'],
            'ydk.models.ydktest.openconfig_interfaces'
        ),
    },
    'Interfaces.Interface.Subinterfaces.Subinterface.State.AdminStatusEnum' : _MetaInfoEnum('AdminStatusEnum',
        'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.Subinterfaces.Subinterface.State.AdminStatusEnum',
        '''[adapted from IETF interfaces model (RFC 7223)]

The desired state of the interface.  In RFC 7223 this leaf
has the same read semantics as ifAdminStatus.  Here, it
reflects the administrative state as set by enabling or
disabling the interface.''',
        {
            'UP':'UP',
            'DOWN':'DOWN',
            'TESTING':'TESTING',
        }, 'openconfig-interfaces', _yang_ns._namespaces['openconfig-interfaces']),
    'Interfaces.Interface.Subinterfaces.Subinterface.State.OperStatusEnum' : _MetaInfoEnum('OperStatusEnum',
        'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.Subinterfaces.Subinterface.State.OperStatusEnum',
        '''[adapted from IETF interfaces model (RFC 7223)]

The current operational state of the interface.

This leaf has the same semantics as ifOperStatus.''',
        {
            'UP':'UP',
            'DOWN':'DOWN',
            'TESTING':'TESTING',
            'UNKNOWN':'UNKNOWN',
            'DORMANT':'DORMANT',
            'NOT_PRESENT':'NOT_PRESENT',
            'LOWER_LAYER_DOWN':'LOWER_LAYER_DOWN',
        }, 'openconfig-interfaces', _yang_ns._namespaces['openconfig-interfaces']),
    'Interfaces.Interface.Subinterfaces.Subinterface.State' : {
        'meta_info' : _MetaInfoClass('Interfaces.Interface.Subinterfaces.Subinterface.State', REFERENCE_CLASS,
            '''Operational state data for logical interfaces''',
            False, 
            [
            _MetaInfoClassMember('admin-status', REFERENCE_ENUM_CLASS, 'AdminStatusEnum', 'enumeration',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.Subinterfaces.Subinterface.State.AdminStatusEnum',
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The desired state of the interface.  In RFC 7223 this leaf
                has the same read semantics as ifAdminStatus.  Here, it
                reflects the administrative state as set by enabling or
                disabling the interface.
                ''',
                'admin_status',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('counters', REFERENCE_CLASS, 'Counters', '',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.Subinterfaces.Subinterface.State.Counters',
                [], [],
                '''                A collection of interface-related statistics objects.
                ''',
                'counters',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('description', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                A textual description of the interface.
                
                A server implementation MAY map this leaf to the ifAlias
                MIB object.  Such an implementation needs to use some
                mechanism to handle the differences in size and characters
                allowed between this leaf and ifAlias.  The definition of
                such a mechanism is outside the scope of this document.
                
                Since ifAlias is defined to be stored in non-volatile
                storage, the MIB implementation MUST map ifAlias to the
                value of 'description' in the persistently stored
                datastore.
                
                Specifically, if the device supports ':startup', when
                ifAlias is read the device MUST return the value of
                'description' in the 'startup' datastore, and when it is
                written, it MUST be written to the 'running' and 'startup'
                datastores.  Note that it is up to the implementation to
                
                decide whether to modify this single leaf in 'startup' or
                perform an implicit copy-config from 'running' to
                'startup'.
                
                If the device does not support ':startup', ifAlias MUST
                be mapped to the 'description' leaf in the 'running'
                datastore.
                ''',
                'description',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('enabled', ATTRIBUTE, 'bool', 'boolean',
                None, None,
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                This leaf contains the configured, desired state of the
                interface.
                
                Systems that implement the IF-MIB use the value of this
                leaf in the 'running' datastore to set
                IF-MIB.ifAdminStatus to 'up' or 'down' after an ifEntry
                has been initialized, as described in RFC 2863.
                
                Changes in this leaf in the 'running' datastore are
                reflected in ifAdminStatus, but if ifAdminStatus is
                changed over SNMP, this leaf is not affected.
                ''',
                'enabled',
                'openconfig-interfaces', False, default_value='True', is_config=False),
            _MetaInfoClassMember('ifindex', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                System assigned number for each interface.  Corresponds to
                ifIndex object in SNMP Interface MIB
                ''',
                'ifindex',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('index', ATTRIBUTE, 'int', 'uint32',
                None, None,
                [('0', '4294967295')], [],
                '''                The index of the subinterface, or logical interface number.
                On systems with no support for subinterfaces, or not using
                subinterfaces, this value should default to 0, i.e., the
                default subinterface.
                ''',
                'index',
                'openconfig-interfaces', False, default_value="0", is_config=False),
            _MetaInfoClassMember('last-change', ATTRIBUTE, 'int', 'yang:timeticks',
                None, None,
                [('0', '4294967295')], [],
                '''                Date and time of the last state change of the interface
                (e.g., up-to-down transition).   This corresponds to the
                ifLastChange object in the standard interface MIB.
                ''',
                'last_change',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The name of the interface.
                
                A device MAY restrict the allowed values for this leaf,
                possibly depending on the type of the interface.
                For system-controlled interfaces, this leaf is the
                device-specific name of the interface.  The 'config false'
                list interfaces/interface[name]/state contains the currently
                existing interfaces on the device.
                
                If a client tries to create configuration for a
                system-controlled interface that is not present in the
                corresponding state list, the server MAY reject
                the request if the implementation does not support
                pre-provisioning of interfaces or if the name refers to
                an interface that can never exist in the system.  A
                NETCONF server MUST reply with an rpc-error with the
                error-tag 'invalid-value' in this case.
                
                The IETF model in RFC 7223 provides YANG features for the
                following (i.e., pre-provisioning and arbitrary-names),
                however they are omitted here:
                
                 If the device supports pre-provisioning of interface
                 configuration, the 'pre-provisioning' feature is
                 advertised.
                
                 If the device allows arbitrarily named user-controlled
                 interfaces, the 'arbitrary-names' feature is advertised.
                
                When a configured user-controlled interface is created by
                the system, it is instantiated with the same name in the
                /interfaces/interface[name]/state list.
                ''',
                'name',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('oper-status', REFERENCE_ENUM_CLASS, 'OperStatusEnum', 'enumeration',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.Subinterfaces.Subinterface.State.OperStatusEnum',
                [], [],
                '''                [adapted from IETF interfaces model (RFC 7223)]
                
                The current operational state of the interface.
                
                This leaf has the same semantics as ifOperStatus.
                ''',
                'oper_status',
                'openconfig-interfaces', False, is_config=False),
            ],
            'openconfig-interfaces',
            'state',
            _yang_ns._namespaces['openconfig-interfaces'],
            'ydk.models.ydktest.openconfig_interfaces'
        ),
    },
    'Interfaces.Interface.Subinterfaces.Subinterface' : {
        'meta_info' : _MetaInfoClass('Interfaces.Interface.Subinterfaces.Subinterface', REFERENCE_LIST,
            '''The list of subinterfaces (logical interfaces) associated
with a physical interface''',
            False, 
            [
            _MetaInfoClassMember('index', ATTRIBUTE, 'int', 'leafref',
                None, None,
                [('0', '4294967295')], [],
                '''                The index number of the subinterface -- used to address
                the logical interface
                ''',
                'index',
                'openconfig-interfaces', True),
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.Subinterfaces.Subinterface.Config',
                [], [],
                '''                Configurable items at the subinterface level
                ''',
                'config',
                'openconfig-interfaces', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.Subinterfaces.Subinterface.State',
                [], [],
                '''                Operational state data for logical interfaces
                ''',
                'state',
                'openconfig-interfaces', False, is_config=False),
            ],
            'openconfig-interfaces',
            'subinterface',
            _yang_ns._namespaces['openconfig-interfaces'],
            'ydk.models.ydktest.openconfig_interfaces'
        ),
    },
    'Interfaces.Interface.Subinterfaces' : {
        'meta_info' : _MetaInfoClass('Interfaces.Interface.Subinterfaces', REFERENCE_CLASS,
            '''Enclosing container for the list of subinterfaces associated
with a physical interface''',
            False, 
            [
            _MetaInfoClassMember('subinterface', REFERENCE_LIST, 'Subinterface', '',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.Subinterfaces.Subinterface',
                [], [],
                '''                The list of subinterfaces (logical interfaces) associated
                with a physical interface
                ''',
                'subinterface',
                'openconfig-interfaces', False),
            ],
            'openconfig-interfaces',
            'subinterfaces',
            _yang_ns._namespaces['openconfig-interfaces'],
            'ydk.models.ydktest.openconfig_interfaces'
        ),
    },
    'Interfaces.Interface' : {
        'meta_info' : _MetaInfoClass('Interfaces.Interface', REFERENCE_LIST,
            '''The list of named interfaces on the device.''',
            False, 
            [
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'leafref',
                None, None,
                [], [],
                '''                References the configured name of the interface
                ''',
                'name',
                'openconfig-interfaces', True),
            _MetaInfoClassMember('config', REFERENCE_CLASS, 'Config', '',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.Config',
                [], [],
                '''                Configurable items at the global, physical interface
                level
                ''',
                'config',
                'openconfig-interfaces', False),
            _MetaInfoClassMember('hold-time', REFERENCE_CLASS, 'HoldTime', '',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.HoldTime',
                [], [],
                '''                Top-level container for hold-time settings to enable
                dampening advertisements of interface transitions.
                ''',
                'hold_time',
                'openconfig-interfaces', False),
            _MetaInfoClassMember('state', REFERENCE_CLASS, 'State', '',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.State',
                [], [],
                '''                Operational state data at the global interface level
                ''',
                'state',
                'openconfig-interfaces', False, is_config=False),
            _MetaInfoClassMember('subinterfaces', REFERENCE_CLASS, 'Subinterfaces', '',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface.Subinterfaces',
                [], [],
                '''                Enclosing container for the list of subinterfaces associated
                with a physical interface
                ''',
                'subinterfaces',
                'openconfig-interfaces', False),
            ],
            'openconfig-interfaces',
            'interface',
            _yang_ns._namespaces['openconfig-interfaces'],
            'ydk.models.ydktest.openconfig_interfaces'
        ),
    },
    'Interfaces' : {
        'meta_info' : _MetaInfoClass('Interfaces', REFERENCE_CLASS,
            '''Top level container for interfaces, including configuration
and state data.''',
            False, 
            [
            _MetaInfoClassMember('interface', REFERENCE_LIST, 'Interface', '',
                'ydk.models.ydktest.openconfig_interfaces', 'Interfaces.Interface',
                [], [],
                '''                The list of named interfaces on the device.
                ''',
                'interface',
                'openconfig-interfaces', False),
            ],
            'openconfig-interfaces',
            'interfaces',
            _yang_ns._namespaces['openconfig-interfaces'],
            'ydk.models.ydktest.openconfig_interfaces'
        ),
    },
}
_meta_table['Interfaces.Interface.State.Counters']['meta_info'].parent =_meta_table['Interfaces.Interface.State']['meta_info']
_meta_table['Interfaces.Interface.HoldTime.Config']['meta_info'].parent =_meta_table['Interfaces.Interface.HoldTime']['meta_info']
_meta_table['Interfaces.Interface.HoldTime.State']['meta_info'].parent =_meta_table['Interfaces.Interface.HoldTime']['meta_info']
_meta_table['Interfaces.Interface.Subinterfaces.Subinterface.State.Counters']['meta_info'].parent =_meta_table['Interfaces.Interface.Subinterfaces.Subinterface.State']['meta_info']
_meta_table['Interfaces.Interface.Subinterfaces.Subinterface.Config']['meta_info'].parent =_meta_table['Interfaces.Interface.Subinterfaces.Subinterface']['meta_info']
_meta_table['Interfaces.Interface.Subinterfaces.Subinterface.State']['meta_info'].parent =_meta_table['Interfaces.Interface.Subinterfaces.Subinterface']['meta_info']
_meta_table['Interfaces.Interface.Subinterfaces.Subinterface']['meta_info'].parent =_meta_table['Interfaces.Interface.Subinterfaces']['meta_info']
_meta_table['Interfaces.Interface.Config']['meta_info'].parent =_meta_table['Interfaces.Interface']['meta_info']
_meta_table['Interfaces.Interface.State']['meta_info'].parent =_meta_table['Interfaces.Interface']['meta_info']
_meta_table['Interfaces.Interface.HoldTime']['meta_info'].parent =_meta_table['Interfaces.Interface']['meta_info']
_meta_table['Interfaces.Interface.Subinterfaces']['meta_info'].parent =_meta_table['Interfaces.Interface']['meta_info']
_meta_table['Interfaces.Interface']['meta_info'].parent =_meta_table['Interfaces']['meta_info']
