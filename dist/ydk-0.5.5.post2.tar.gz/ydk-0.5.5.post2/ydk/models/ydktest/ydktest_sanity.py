""" ydktest_sanity 

This module contains a collection of YANG definitions
for sanity package.

This module contains definitions
for the following management objects\:


Copyright (c) 2013\-2014 by Cisco Systems, Inc.
All rights reserved.

"""


import re
import collections

from enum import Enum

from ydk.types import Empty, YList, YLeafList, DELETE, Decimal64, FixedBitsDict

from ydk.errors import YPYError, YPYModelError



class YdkEnumIntTestEnum(Enum):
    """
    YdkEnumIntTestEnum

    Int or any

    .. data:: any = 4096

    	Any value

    """

    any = 4096


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _ydktest_sanity as meta
        return meta._meta_table['YdkEnumIntTestEnum']


class YdkEnumTestEnum(Enum):
    """
    YdkEnumTestEnum

    YDK Enum test

    .. data:: not_set = 0

    	Not Set

    .. data:: none = 1

    	None

    .. data:: local = 2

    	Local

    .. data:: remote = 3

    	Remote

    """

    not_set = 0

    none = 1

    local = 2

    remote = 3


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _ydktest_sanity as meta
        return meta._meta_table['YdkEnumTestEnum']



class BaseIdentityIdentity(object):
    """
    
    
    

    """

    _prefix = 'ydkut'
    _revision = '2015-11-17'

    def __init__(self):
        pass

    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _ydktest_sanity as meta
        return meta._meta_table['BaseIdentityIdentity']['meta_info']


class SubTest(object):
    """
    
    
    .. attribute:: one_aug
    
    	config for one\_level data
    	**type**\:   :py:class:`OneAug <ydk.models.ydktest.ydktest_sanity.SubTest.OneAug>`
    
    

    """

    _prefix = 'ydkut'
    _revision = '2016-04-25'

    def __init__(self):
        self.ylist_key_names = []

        self.one_aug = SubTest.OneAug()
        self.one_aug.parent = self


    class OneAug(object):
        """
        config for one\_level data
        
        .. attribute:: name
        
        	this is string value
        	**type**\:  str
        
        .. attribute:: number
        
        	integer value type
        	**type**\:  int
        
        	**range:** \-2147483648..2147483647
        
        

        """

        _prefix = 'ydkut'
        _revision = '2016-04-25'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = []

            self.name = None
            self.number = None

        @property
        def _common_path(self):

            return '/ydktest-sanity-submodule:sub-test/ydktest-sanity-submodule:one-aug'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.name is not None:
                return True

            if self.number is not None:
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['SubTest.OneAug']['meta_info']

    @property
    def _common_path(self):

        return '/ydktest-sanity-submodule:sub-test'

    def is_config(self):
        ''' Returns True if this instance represents config data else returns False '''
        return True

    def _has_data(self):
        if self.one_aug is not None and self.one_aug._has_data():
            return True

        return False

    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _ydktest_sanity as meta
        return meta._meta_table['SubTest']['meta_info']


class Runner(object):
    """
    
    
    .. attribute:: inbtw_list
    
    	config for one\_level list data
    	**type**\:   :py:class:`InbtwList <ydk.models.ydktest.ydktest_sanity.Runner.InbtwList>`
    
    .. attribute:: leaf_ref
    
    	
    	**type**\:   :py:class:`LeafRef <ydk.models.ydktest.ydktest_sanity.Runner.LeafRef>`
    
    .. attribute:: mand_list
    
    	
    	**type**\: list of    :py:class:`MandList <ydk.models.ydktest.ydktest_sanity.Runner.MandList>`
    
    .. attribute:: not_supported_1
    
    	
    	**type**\:   :py:class:`NotSupported1 <ydk.models.ydktest.ydktest_sanity.Runner.NotSupported1>`
    
    .. attribute:: not_supported_2
    
    	
    	**type**\: list of    :py:class:`NotSupported2 <ydk.models.ydktest.ydktest_sanity.Runner.NotSupported2>`
    
    .. attribute:: one
    
    	config for one\_level data
    	**type**\:   :py:class:`One <ydk.models.ydktest.ydktest_sanity.Runner.One>`
    
    .. attribute:: one_key_list
    
    	
    	**type**\: list of    :py:class:`OneKeyList <ydk.models.ydktest.ydktest_sanity.Runner.OneKeyList>`
    
    .. attribute:: one_list
    
    	config for one\_level list data
    	**type**\:   :py:class:`OneList <ydk.models.ydktest.ydktest_sanity.Runner.OneList>`
    
    .. attribute:: runner_2
    
    	
    	**type**\:   :py:class:`Runner2 <ydk.models.ydktest.ydktest_sanity.Runner.Runner2>`
    
    	**presence node**\: True
    
    .. attribute:: three
    
    	config for one\_level data
    	**type**\:   :py:class:`Three <ydk.models.ydktest.ydktest_sanity.Runner.Three>`
    
    .. attribute:: three_list
    
    	config for one\_level list data
    	**type**\:   :py:class:`ThreeList <ydk.models.ydktest.ydktest_sanity.Runner.ThreeList>`
    
    .. attribute:: two
    
    	config for one\_level data
    	**type**\:   :py:class:`Two <ydk.models.ydktest.ydktest_sanity.Runner.Two>`
    
    .. attribute:: two_key_list
    
    	
    	**type**\: list of    :py:class:`TwoKeyList <ydk.models.ydktest.ydktest_sanity.Runner.TwoKeyList>`
    
    .. attribute:: two_list
    
    	config for one\_level list data
    	**type**\:   :py:class:`TwoList <ydk.models.ydktest.ydktest_sanity.Runner.TwoList>`
    
    .. attribute:: ytypes
    
    	config for one\_level data types
    	**type**\:   :py:class:`Ytypes <ydk.models.ydktest.ydktest_sanity.Runner.Ytypes>`
    
    

    """

    _prefix = 'ydkut'
    _revision = '2015-11-17'

    def __init__(self):
        self.ylist_key_names = []

        self.inbtw_list = Runner.InbtwList()
        self.inbtw_list.parent = self
        self.leaf_ref = Runner.LeafRef()
        self.leaf_ref.parent = self
        self.mand_list = YList()
        self.mand_list.parent = self
        self.mand_list.name = 'mand_list'
        self.not_supported_1 = Runner.NotSupported1()
        self.not_supported_1.parent = self
        self.not_supported_2 = YList()
        self.not_supported_2.parent = self
        self.not_supported_2.name = 'not_supported_2'
        self.one = Runner.One()
        self.one.parent = self
        self.one_key_list = YList()
        self.one_key_list.parent = self
        self.one_key_list.name = 'one_key_list'
        self.one_list = Runner.OneList()
        self.one_list.parent = self
        self.runner_2 = None
        self.three = Runner.Three()
        self.three.parent = self
        self.three_list = Runner.ThreeList()
        self.three_list.parent = self
        self.two = Runner.Two()
        self.two.parent = self
        self.two_key_list = YList()
        self.two_key_list.parent = self
        self.two_key_list.name = 'two_key_list'
        self.two_list = Runner.TwoList()
        self.two_list.parent = self
        self.ytypes = Runner.Ytypes()
        self.ytypes.parent = self


    class Ytypes(object):
        """
        config for one\_level data types
        
        .. attribute:: built_in_t
        
        	config for built\-in types
        	**type**\:   :py:class:`BuiltInT <ydk.models.ydktest.ydktest_sanity.Runner.Ytypes.BuiltInT>`
        
        .. attribute:: derived_t
        
        	config for one\_level derived data types
        	**type**\:   :py:class:`DerivedT <ydk.models.ydktest.ydktest_sanity.Runner.Ytypes.DerivedT>`
        
        .. attribute:: enabled
        
        	
        	**type**\:  :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: none
        
        	
        	**type**\:   :py:class:`None_ <ydk.models.ydktest.ydktest_sanity.Runner.Ytypes.None_>`
        
        

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = []

            self.built_in_t = Runner.Ytypes.BuiltInT()
            self.built_in_t.parent = self
            self.derived_t = Runner.Ytypes.DerivedT()
            self.derived_t.parent = self
            self.enabled = None
            self.none = Runner.Ytypes.None_()
            self.none.parent = self


        class None_(object):
            """
            
            
            .. attribute:: test
            
            	
            	**type**\:  str
            
            

            """

            _prefix = 'ydkut'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.test = None

            @property
            def _common_path(self):

                return '/ydktest-sanity:runner/ydktest-sanity:ytypes/ydktest-sanity:none'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.test is not None:
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.Ytypes.None_']['meta_info']


        class BuiltInT(object):
            """
            config for built\-in types
            
            .. attribute:: bincoded
            
            	this is binary value
            	**type**\:  str
            
            .. attribute:: bits_llist
            
            	
            	**type**\:  list of   :py:class:`BitsLlist <ydk.models.ydktest.ydktest_sanity.Runner.Ytypes.BuiltInT.BitsLlist>`
            
            .. attribute:: bits_value
            
            	
            	**type**\:   :py:class:`YdkBitsType <ydk.models.ydktest.ydktest_types.YdkBitsType>`
            
            	**default value**\: auto-sense-speed
            
            .. attribute:: bool_value
            
            	this is boolean type value
            	**type**\:  bool
            
            .. attribute:: deci64
            
            	this is decimal value
            	**type**\:  Decimal64
            
            	**range:** 1..3.14 \| 10..10 \| 20..92233720368547758.07
            
            .. attribute:: embeded_enum
            
            	enum embeded in leaf
            	**type**\:   :py:class:`EmbededEnumEnum <ydk.models.ydktest.ydktest_sanity.Runner.Ytypes.BuiltInT.EmbededEnumEnum>`
            
            .. attribute:: emptee
            
            	this is empty value
            	**type**\:  :py:class:`Empty<ydk.types.Empty>`
            
            .. attribute:: enum_int_value
            
            	enum int type
            	**type**\: one of the below types:
            
            	**type**\:   :py:class:`YdkEnumIntTestEnum <ydk.models.ydktest.ydktest_sanity.YdkEnumIntTestEnum>`
            
            
            ----
            	**type**\:  int
            
            	**range:** 1..4096
            
            
            ----
            .. attribute:: enum_llist
            
            	A leaf\-list of enum
            	**type**\:  list of   :py:class:`YdkEnumTestEnum <ydk.models.ydktest.ydktest_sanity.YdkEnumTestEnum>`
            
            .. attribute:: enum_value
            
            	this is enum type value
            	**type**\:   :py:class:`YdkEnumTestEnum <ydk.models.ydktest.ydktest_sanity.YdkEnumTestEnum>`
            
            .. attribute:: identity_llist
            
            	A leaf\-list of identityref
            	**type**\:  
            		list of   :py:class:`BaseIdentityIdentity <ydk.models.ydktest.ydktest_sanity.BaseIdentityIdentity>`
            
            .. attribute:: identity_ref_value
            
            	
            	**type**\:   :py:class:`BaseIdentityIdentity <ydk.models.ydktest.ydktest_sanity.BaseIdentityIdentity>`
            
            .. attribute:: leaf_ref
            
            	leaf\-ref
            	**type**\:  int
            
            	**range:** \-128..127
            
            	**refers to**\:  :py:class:`number8 <ydk.models.ydktest.ydktest_sanity.Runner.Ytypes.BuiltInT>`
            
            .. attribute:: llstring
            
            	A list of string
            	**type**\:  list of str
            
            .. attribute:: llunion
            
            	A list of union
            	**type**\: one of the below types:
            
            	**type**\:  list of int
            
            	**range:** \-32768..32767
            
            
            ----
            	**type**\:  list of str
            
            
            ----
            .. attribute:: name
            
            	this is string value
            	**type**\:  str
            
            .. attribute:: number16
            
            	16 bit integer value type
            	**type**\:  int
            
            	**range:** \-32768..32767
            
            .. attribute:: number32
            
            	integer value type
            	**type**\:  int
            
            	**range:** \-2147483648..0 \| 10..10 \| 19..19 \| 1000..2147483647
            
            .. attribute:: number64
            
            	integer value type
            	**type**\:  int
            
            	**range:** \-9223372036854775808..9223372036854775807
            
            .. attribute:: number8
            
            	 8 bit integer value type
            	**type**\:  int
            
            	**range:** \-128..127
            
            .. attribute:: status
            
            	Whether cable is connected or not
            	**type**\:   :py:class:`StatusEnum <ydk.models.ydktest.ydktest_sanity.Runner.Ytypes.BuiltInT.StatusEnum>`
            
            .. attribute:: u_number16
            
            	16 bit uinteger value type
            	**type**\:  int
            
            	**range:** 0..65535
            
            .. attribute:: u_number32
            
            	32 bit uinteger value type
            	**type**\:  int
            
            	**range:** 0..4294967295
            
            .. attribute:: u_number64
            
            	64 bit uinteger value type
            	**type**\:  int
            
            	**range:** 0..18446744073709551615
            
            .. attribute:: u_number8
            
            	 8 bit uinteger value type
            	**type**\:  int
            
            	**range:** 0..255
            
            .. attribute:: younion
            
            	union test value
            	**type**\: one of the below types:
            
            	**type**\:   :py:class:`YdkEnumTestEnum <ydk.models.ydktest.ydktest_sanity.YdkEnumTestEnum>`
            
            
            ----
            	**type**\:  int
            
            	**range:** 0..63
            
            
            ----
            .. attribute:: younion_list
            
            	members of the younion
            	**type**\: one of the below types:
            
            	**type**\:  list of int
            
            	**range:** 0..4294967295
            
            
            ----
            	**type**\:  list of str
            
            
            ----
            
            ----
            	**type**\:  list of str
            
            
            ----
            	**type**\:  list of str
            
            
            ----
            .. attribute:: younion_recursive
            
            	Recursive union leaf
            	**type**\: one of the below types:
            
            	**type**\:  int
            
            	**range:** 0..4294967295
            
            
            ----
            	**type**\:  str
            
            
            ----
            
            ----
            	**type**\:  int
            
            	**range:** \-128..127
            
            
            ----
            

            """

            _prefix = 'ydkut'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.bincoded = None
                self.bits_llist = YLeafList()
                self.bits_llist.parent = self
                self.bits_llist.name = 'bits_llist'
                from ydk.models.ydktest.ydktest_types import YdkBitsType
                self.bits_value = YdkBitsType()
                self.bool_value = None
                self.deci64 = None
                self.embeded_enum = None
                self.emptee = None
                self.enum_int_value = None
                self.enum_llist = YLeafList()
                self.enum_llist.parent = self
                self.enum_llist.name = 'enum_llist'
                self.enum_value = None
                self.identity_llist = YLeafList()
                self.identity_llist.parent = self
                self.identity_llist.name = 'identity_llist'
                self.identity_ref_value = None
                self.leaf_ref = None
                self.llstring = YLeafList()
                self.llstring.parent = self
                self.llstring.name = 'llstring'
                self.llunion = YLeafList()
                self.llunion.parent = self
                self.llunion.name = 'llunion'
                self.name = None
                self.number16 = None
                self.number32 = None
                self.number64 = None
                self.number8 = None
                self.status = None
                self.u_number16 = None
                self.u_number32 = None
                self.u_number64 = None
                self.u_number8 = None
                self.younion = None
                self.younion_list = YLeafList()
                self.younion_list.parent = self
                self.younion_list.name = 'younion_list'
                self.younion_recursive = None

            class EmbededEnumEnum(Enum):
                """
                EmbededEnumEnum

                enum embeded in leaf

                .. data:: zero = 0

                .. data:: two = 1

                .. data:: seven = 7

                """

                zero = 0

                two = 1

                seven = 7


                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _ydktest_sanity as meta
                    return meta._meta_table['Runner.Ytypes.BuiltInT.EmbededEnumEnum']


            class StatusEnum(Enum):
                """
                StatusEnum

                Whether cable is connected or not

                .. data:: good = 0

                .. data:: not_connected = 1

                """

                good = 0

                not_connected = 1


                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _ydktest_sanity as meta
                    return meta._meta_table['Runner.Ytypes.BuiltInT.StatusEnum']


            class BitsLlist(FixedBitsDict):
                """
                BitsLlist

                Keys are:- disable\-nagle , auto\-sense\-speed

                """

                def __init__(self):
                    dictionary_ = { 
                        'disable-nagle': False,
                        'auto-sense-speed': False,
                    }
                    pos_map_ = { 
                        'disable-nagle': 0,
                        'auto-sense-speed': 1,
                    }
                    super().__init__(dictionary_, pos_map_)

            @property
            def _common_path(self):

                return '/ydktest-sanity:runner/ydktest-sanity:ytypes/ydktest-sanity:built-in-t'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.bincoded is not None:
                    return True

                if self.bits_llist is not None:
                    for child in self.bits_llist:
                        if child is not None:
                            if child._has_data():
                                return True

                if self.bits_value is not None:
                    if self.bits_value._has_data():
                        return True

                if self.bool_value is not None:
                    return True

                if self.deci64 is not None:
                    return True

                if self.embeded_enum is not None:
                    return True

                if self.emptee is not None:
                    return True

                if self.enum_int_value is not None:
                    return True

                if self.enum_llist is not None:
                    for child in self.enum_llist:
                        if child is not None:
                            return True

                if self.enum_value is not None:
                    return True

                if self.identity_llist is not None:
                    for child_ref in self.identity_llist:
                        if child_ref._has_data():
                            return True

                if self.identity_ref_value is not None:
                    return True

                if self.leaf_ref is not None:
                    return True

                if self.llstring is not None:
                    for child in self.llstring:
                        if child is not None:
                            return True

                if self.llunion is not None:
                    for child in self.llunion:
                        if child is not None:
                            return True

                if self.name is not None:
                    return True

                if self.number16 is not None:
                    return True

                if self.number32 is not None:
                    return True

                if self.number64 is not None:
                    return True

                if self.number8 is not None:
                    return True

                if self.status is not None:
                    return True

                if self.u_number16 is not None:
                    return True

                if self.u_number32 is not None:
                    return True

                if self.u_number64 is not None:
                    return True

                if self.u_number8 is not None:
                    return True

                if self.younion is not None:
                    return True

                if self.younion_list is not None:
                    for child in self.younion_list:
                        if child is not None:
                            return True

                if self.younion_recursive is not None:
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.Ytypes.BuiltInT']['meta_info']


        class DerivedT(object):
            """
            config for one\_level derived data types
            
            

            """

            _prefix = 'ydkut'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []


            @property
            def _common_path(self):

                return '/ydktest-sanity:runner/ydktest-sanity:ytypes/ydktest-sanity:derived-t'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.Ytypes.DerivedT']['meta_info']

        @property
        def _common_path(self):

            return '/ydktest-sanity:runner/ydktest-sanity:ytypes'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.built_in_t is not None and self.built_in_t._has_data():
                return True

            if self.derived_t is not None and self.derived_t._has_data():
                return True

            if self.enabled is not None:
                return True

            if self.none is not None and self.none._has_data():
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.Ytypes']['meta_info']


    class Three(object):
        """
        config for one\_level data
        
        .. attribute:: name
        
        	this is string value
        	**type**\:  str
        
        .. attribute:: number
        
        	integer value type
        	**type**\:  int
        
        	**range:** \-2147483648..2147483647
        
        .. attribute:: sub1
        
        	subconfig1 for config container
        	**type**\:   :py:class:`Sub1 <ydk.models.ydktest.ydktest_sanity.Runner.Three.Sub1>`
        
        

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = []

            self.name = None
            self.number = None
            self.sub1 = Runner.Three.Sub1()
            self.sub1.parent = self


        class Sub1(object):
            """
            subconfig1 for config container
            
            .. attribute:: number
            
            	integer value type
            	**type**\:  int
            
            	**range:** \-2147483648..2147483647
            
            .. attribute:: sub2
            
            	subconfig2 for config container
            	**type**\:   :py:class:`Sub2 <ydk.models.ydktest.ydktest_sanity.Runner.Three.Sub1.Sub2>`
            
            

            """

            _prefix = 'ydkut'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.number = None
                self.sub2 = Runner.Three.Sub1.Sub2()
                self.sub2.parent = self


            class Sub2(object):
                """
                subconfig2 for config container
                
                .. attribute:: number
                
                	integer value type
                	**type**\:  int
                
                	**range:** \-2147483648..2147483647
                
                

                """

                _prefix = 'ydkut'
                _revision = '2015-11-17'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = []

                    self.number = None

                @property
                def _common_path(self):

                    return '/ydktest-sanity:runner/ydktest-sanity:three/ydktest-sanity:sub1/ydktest-sanity:sub2'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.number is not None:
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _ydktest_sanity as meta
                    return meta._meta_table['Runner.Three.Sub1.Sub2']['meta_info']

            @property
            def _common_path(self):

                return '/ydktest-sanity:runner/ydktest-sanity:three/ydktest-sanity:sub1'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.number is not None:
                    return True

                if self.sub2 is not None and self.sub2._has_data():
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.Three.Sub1']['meta_info']

        @property
        def _common_path(self):

            return '/ydktest-sanity:runner/ydktest-sanity:three'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.name is not None:
                return True

            if self.number is not None:
                return True

            if self.sub1 is not None and self.sub1._has_data():
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.Three']['meta_info']


    class InbtwList(object):
        """
        config for one\_level list data
        
        .. attribute:: ldata
        
        	one list data
        	**type**\: list of    :py:class:`Ldata <ydk.models.ydktest.ydktest_sanity.Runner.InbtwList.Ldata>`
        
        

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = []

            self.ldata = YList()
            self.ldata.parent = self
            self.ldata.name = 'ldata'


        class Ldata(object):
            """
            one list data
            
            .. attribute:: number  <key>
            
            	integer value type
            	**type**\:  int
            
            	**range:** \-2147483648..2147483647
            
            .. attribute:: name
            
            	this is string value
            	**type**\:  str
            
            .. attribute:: subc
            
            	one list subcontainer data
            	**type**\:   :py:class:`Subc <ydk.models.ydktest.ydktest_sanity.Runner.InbtwList.Ldata.Subc>`
            
            

            """

            _prefix = 'ydkut'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = ['number']

                self.number = None
                self.name = None
                self.subc = Runner.InbtwList.Ldata.Subc()
                self.subc.parent = self


            class Subc(object):
                """
                one list subcontainer data
                
                .. attribute:: name
                
                	this is string value
                	**type**\:  str
                
                .. attribute:: number
                
                	integer value type
                	**type**\:  int
                
                	**range:** \-2147483648..2147483647
                
                .. attribute:: subc_subl1
                
                	one list data
                	**type**\: list of    :py:class:`SubcSubl1 <ydk.models.ydktest.ydktest_sanity.Runner.InbtwList.Ldata.Subc.SubcSubl1>`
                
                

                """

                _prefix = 'ydkut'
                _revision = '2015-11-17'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = []

                    self.name = None
                    self.number = None
                    self.subc_subl1 = YList()
                    self.subc_subl1.parent = self
                    self.subc_subl1.name = 'subc_subl1'


                class SubcSubl1(object):
                    """
                    one list data
                    
                    .. attribute:: number  <key>
                    
                    	integer value type
                    	**type**\:  int
                    
                    	**range:** \-2147483648..2147483647
                    
                    .. attribute:: name
                    
                    	this is string value
                    	**type**\:  str
                    
                    

                    """

                    _prefix = 'ydkut'
                    _revision = '2015-11-17'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = ['number']

                        self.number = None
                        self.name = None

                    @property
                    def _common_path(self):
                        if self.parent is None:
                            raise YPYModelError('parent is not set . Cannot derive path.')
                        if self.number is None:
                            raise YPYModelError('Key property number is None')

                        return self.parent._common_path +'/ydktest-sanity:subc-subl1[ydktest-sanity:number = ' + str(self.number) + ']'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return True

                    def _has_data(self):
                        if self.number is not None:
                            return True

                        if self.name is not None:
                            return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _ydktest_sanity as meta
                        return meta._meta_table['Runner.InbtwList.Ldata.Subc.SubcSubl1']['meta_info']

                @property
                def _common_path(self):
                    if self.parent is None:
                        raise YPYModelError('parent is not set . Cannot derive path.')

                    return self.parent._common_path +'/ydktest-sanity:subc'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.name is not None:
                        return True

                    if self.number is not None:
                        return True

                    if self.subc_subl1 is not None:
                        for child_ref in self.subc_subl1:
                            if child_ref._has_data():
                                return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _ydktest_sanity as meta
                    return meta._meta_table['Runner.InbtwList.Ldata.Subc']['meta_info']

            @property
            def _common_path(self):
                if self.number is None:
                    raise YPYModelError('Key property number is None')

                return '/ydktest-sanity:runner/ydktest-sanity:inbtw-list/ydktest-sanity:ldata[ydktest-sanity:number = ' + str(self.number) + ']'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.number is not None:
                    return True

                if self.name is not None:
                    return True

                if self.subc is not None and self.subc._has_data():
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.InbtwList.Ldata']['meta_info']

        @property
        def _common_path(self):

            return '/ydktest-sanity:runner/ydktest-sanity:inbtw-list'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.ldata is not None:
                for child_ref in self.ldata:
                    if child_ref._has_data():
                        return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.InbtwList']['meta_info']


    class OneKeyList(object):
        """
        
        
        .. attribute:: testy  <key>
        
        	
        	**type**\:  str
        
        .. attribute:: test
        
        	
        	**type**\:   :py:class:`Test <ydk.models.ydktest.ydktest_sanity.Runner.OneKeyList.Test>`
        
        

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = ['testy']

            self.testy = None
            self.test = Runner.OneKeyList.Test()
            self.test.parent = self


        class Test(object):
            """
            
            
            .. attribute:: best
            
            	
            	**type**\:   :py:class:`Best <ydk.models.ydktest.ydktest_sanity.Runner.OneKeyList.Test.Best>`
            
            

            """

            _prefix = 'ydkut'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.best = Runner.OneKeyList.Test.Best()
                self.best.parent = self


            class Best(object):
                """
                
                
                .. attribute:: gest
                
                	
                	**type**\:  str
                
                

                """

                _prefix = 'ydkut'
                _revision = '2015-11-17'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = []

                    self.gest = None

                @property
                def _common_path(self):
                    if self.parent is None:
                        raise YPYModelError('parent is not set . Cannot derive path.')

                    return self.parent._common_path +'/ydktest-sanity:best'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.gest is not None:
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _ydktest_sanity as meta
                    return meta._meta_table['Runner.OneKeyList.Test.Best']['meta_info']

            @property
            def _common_path(self):
                if self.parent is None:
                    raise YPYModelError('parent is not set . Cannot derive path.')

                return self.parent._common_path +'/ydktest-sanity:test'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.best is not None and self.best._has_data():
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.OneKeyList.Test']['meta_info']

        @property
        def _common_path(self):
            if self.testy is None:
                raise YPYModelError('Key property testy is None')

            return '/ydktest-sanity:runner/ydktest-sanity:one-key-list[ydktest-sanity:testy = ' + str(self.testy) + ']'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.testy is not None:
                return True

            if self.test is not None and self.test._has_data():
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.OneKeyList']['meta_info']


    class MandList(object):
        """
        
        
        .. attribute:: name  <key>
        
        	
        	**type**\:  str
        
        .. attribute:: num
        
        	
        	**type**\:  int
        
        	**range:** \-32768..32767
        
        	**mandatory**\: True
        
        

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = ['name']

            self.name = None
            self.num = None

        @property
        def _common_path(self):
            if self.name is None:
                raise YPYModelError('Key property name is None')

            return '/ydktest-sanity:runner/ydktest-sanity:mand-list[ydktest-sanity:name = ' + str(self.name) + ']'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.name is not None:
                return True

            if self.num is not None:
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.MandList']['meta_info']


    class NotSupported2(object):
        """
        
        
        .. attribute:: number  <key>
        
        	Integer key for not supported list
        	**type**\:  int
        
        	**range:** \-2147483648..2147483647
        
        

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = ['number']

            self.number = None

        @property
        def _common_path(self):
            if self.number is None:
                raise YPYModelError('Key property number is None')

            return '/ydktest-sanity:runner/ydktest-sanity:not-supported-2[ydktest-sanity:number = ' + str(self.number) + ']'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.number is not None:
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.NotSupported2']['meta_info']


    class TwoKeyList(object):
        """
        
        
        .. attribute:: first  <key>
        
        	
        	**type**\:  str
        
        .. attribute:: second  <key>
        
        	
        	**type**\:  int
        
        	**range:** 0..4294967295
        
        .. attribute:: property
        
        	
        	**type**\:  str
        
        

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = ['first','second']

            self.first = None
            self.second = None
            self.property = None

        @property
        def _common_path(self):
            if self.first is None:
                raise YPYModelError('Key property first is None')
            if self.second is None:
                raise YPYModelError('Key property second is None')

            return '/ydktest-sanity:runner/ydktest-sanity:two-key-list[ydktest-sanity:first = ' + str(self.first) + '][ydktest-sanity:second = ' + str(self.second) + ']'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.first is not None:
                return True

            if self.second is not None:
                return True

            if self.property is not None:
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.TwoKeyList']['meta_info']


    class Two(object):
        """
        config for one\_level data
        
        .. attribute:: name
        
        	this is string value
        	**type**\:  str
        
        .. attribute:: number
        
        	integer value type
        	**type**\:  int
        
        	**range:** \-2147483648..2147483647
        
        .. attribute:: sub1
        
        	subconfig1 for config container
        	**type**\:   :py:class:`Sub1 <ydk.models.ydktest.ydktest_sanity.Runner.Two.Sub1>`
        
        

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = []

            self.name = None
            self.number = None
            self.sub1 = Runner.Two.Sub1()
            self.sub1.parent = self


        class Sub1(object):
            """
            subconfig1 for config container
            
            .. attribute:: number
            
            	integer value type
            	**type**\:  int
            
            	**range:** \-2147483648..2147483647
            
            

            """

            _prefix = 'ydkut'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.number = None

            @property
            def _common_path(self):

                return '/ydktest-sanity:runner/ydktest-sanity:two/ydktest-sanity:sub1'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.number is not None:
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.Two.Sub1']['meta_info']

        @property
        def _common_path(self):

            return '/ydktest-sanity:runner/ydktest-sanity:two'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.name is not None:
                return True

            if self.number is not None:
                return True

            if self.sub1 is not None and self.sub1._has_data():
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.Two']['meta_info']


    class ThreeList(object):
        """
        config for one\_level list data
        
        .. attribute:: ldata
        
        	one list data
        	**type**\: list of    :py:class:`Ldata <ydk.models.ydktest.ydktest_sanity.Runner.ThreeList.Ldata>`
        
        

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = []

            self.ldata = YList()
            self.ldata.parent = self
            self.ldata.name = 'ldata'


        class Ldata(object):
            """
            one list data
            
            .. attribute:: number  <key>
            
            	integer value type
            	**type**\:  int
            
            	**range:** \-2147483648..2147483647
            
            .. attribute:: name
            
            	this is string value
            	**type**\:  str
            
            .. attribute:: subl1
            
            	one list data
            	**type**\: list of    :py:class:`Subl1 <ydk.models.ydktest.ydktest_sanity.Runner.ThreeList.Ldata.Subl1>`
            
            

            """

            _prefix = 'ydkut'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = ['number']

                self.number = None
                self.name = None
                self.subl1 = YList()
                self.subl1.parent = self
                self.subl1.name = 'subl1'


            class Subl1(object):
                """
                one list data
                
                .. attribute:: number  <key>
                
                	integer value type
                	**type**\:  int
                
                	**range:** \-2147483648..2147483647
                
                .. attribute:: name
                
                	this is string value
                	**type**\:  str
                
                .. attribute:: sub_subl1
                
                	one list data
                	**type**\: list of    :py:class:`SubSubl1 <ydk.models.ydktest.ydktest_sanity.Runner.ThreeList.Ldata.Subl1.SubSubl1>`
                
                

                """

                _prefix = 'ydkut'
                _revision = '2015-11-17'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = ['number']

                    self.number = None
                    self.name = None
                    self.sub_subl1 = YList()
                    self.sub_subl1.parent = self
                    self.sub_subl1.name = 'sub_subl1'


                class SubSubl1(object):
                    """
                    one list data
                    
                    .. attribute:: number  <key>
                    
                    	integer value type
                    	**type**\:  int
                    
                    	**range:** \-2147483648..2147483647
                    
                    .. attribute:: name
                    
                    	this is string value
                    	**type**\:  str
                    
                    

                    """

                    _prefix = 'ydkut'
                    _revision = '2015-11-17'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = ['number']

                        self.number = None
                        self.name = None

                    @property
                    def _common_path(self):
                        if self.parent is None:
                            raise YPYModelError('parent is not set . Cannot derive path.')
                        if self.number is None:
                            raise YPYModelError('Key property number is None')

                        return self.parent._common_path +'/ydktest-sanity:sub-subl1[ydktest-sanity:number = ' + str(self.number) + ']'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return True

                    def _has_data(self):
                        if self.number is not None:
                            return True

                        if self.name is not None:
                            return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _ydktest_sanity as meta
                        return meta._meta_table['Runner.ThreeList.Ldata.Subl1.SubSubl1']['meta_info']

                @property
                def _common_path(self):
                    if self.parent is None:
                        raise YPYModelError('parent is not set . Cannot derive path.')
                    if self.number is None:
                        raise YPYModelError('Key property number is None')

                    return self.parent._common_path +'/ydktest-sanity:subl1[ydktest-sanity:number = ' + str(self.number) + ']'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.number is not None:
                        return True

                    if self.name is not None:
                        return True

                    if self.sub_subl1 is not None:
                        for child_ref in self.sub_subl1:
                            if child_ref._has_data():
                                return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _ydktest_sanity as meta
                    return meta._meta_table['Runner.ThreeList.Ldata.Subl1']['meta_info']

            @property
            def _common_path(self):
                if self.number is None:
                    raise YPYModelError('Key property number is None')

                return '/ydktest-sanity:runner/ydktest-sanity:three-list/ydktest-sanity:ldata[ydktest-sanity:number = ' + str(self.number) + ']'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.number is not None:
                    return True

                if self.name is not None:
                    return True

                if self.subl1 is not None:
                    for child_ref in self.subl1:
                        if child_ref._has_data():
                            return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.ThreeList.Ldata']['meta_info']

        @property
        def _common_path(self):

            return '/ydktest-sanity:runner/ydktest-sanity:three-list'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.ldata is not None:
                for child_ref in self.ldata:
                    if child_ref._has_data():
                        return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.ThreeList']['meta_info']


    class LeafRef(object):
        """
        
        
        .. attribute:: one
        
        	
        	**type**\:   :py:class:`One <ydk.models.ydktest.ydktest_sanity.Runner.LeafRef.One>`
        
        .. attribute:: ref_inbtw
        
        	
        	**type**\:  str
        
        	**refers to**\:  :py:class:`name <ydk.models.ydktest.ydktest_sanity.Runner.InbtwList.Ldata.Subc.SubcSubl1>`
        
        .. attribute:: ref_one_name
        
        	
        	**type**\:  str
        
        	**refers to**\:  :py:class:`name <ydk.models.ydktest.ydktest_sanity.Runner.One>`
        
        .. attribute:: ref_three_sub1_sub2_number
        
        	
        	**type**\:  int
        
        	**range:** \-2147483648..2147483647
        
        	**refers to**\:  :py:class:`number <ydk.models.ydktest.ydktest_sanity.Runner.Three.Sub1.Sub2>`
        
        .. attribute:: ref_two_sub1_number
        
        	
        	**type**\:  int
        
        	**range:** \-2147483648..2147483647
        
        	**refers to**\:  :py:class:`number <ydk.models.ydktest.ydktest_sanity.Runner.Two.Sub1>`
        
        

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = []

            self.one = Runner.LeafRef.One()
            self.one.parent = self
            self.ref_inbtw = None
            self.ref_one_name = None
            self.ref_three_sub1_sub2_number = None
            self.ref_two_sub1_number = None


        class One(object):
            """
            
            
            .. attribute:: name_of_one
            
            	
            	**type**\:  str
            
            	**pattern:** (([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])(%[\\p{N}\\p{L}]+)?
            
            .. attribute:: two
            
            	
            	**type**\:   :py:class:`Two <ydk.models.ydktest.ydktest_sanity.Runner.LeafRef.One.Two>`
            
            

            """

            _prefix = 'ydkut'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.name_of_one = None
                self.two = Runner.LeafRef.One.Two()
                self.two.parent = self


            class Two(object):
                """
                
                
                .. attribute:: self_ref_one_name
                
                	
                	**type**\:  str
                
                	**refers to**\:  :py:class:`ref_one_name <ydk.models.ydktest.ydktest_sanity.Runner.LeafRef>`
                
                

                """

                _prefix = 'ydkut'
                _revision = '2015-11-17'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = []

                    self.self_ref_one_name = None

                @property
                def _common_path(self):

                    return '/ydktest-sanity:runner/ydktest-sanity:leaf-ref/ydktest-sanity:one/ydktest-sanity:two'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.self_ref_one_name is not None:
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _ydktest_sanity as meta
                    return meta._meta_table['Runner.LeafRef.One.Two']['meta_info']

            @property
            def _common_path(self):

                return '/ydktest-sanity:runner/ydktest-sanity:leaf-ref/ydktest-sanity:one'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.name_of_one is not None:
                    return True

                if self.two is not None and self.two._has_data():
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.LeafRef.One']['meta_info']

        @property
        def _common_path(self):

            return '/ydktest-sanity:runner/ydktest-sanity:leaf-ref'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.one is not None and self.one._has_data():
                return True

            if self.ref_inbtw is not None:
                return True

            if self.ref_one_name is not None:
                return True

            if self.ref_three_sub1_sub2_number is not None:
                return True

            if self.ref_two_sub1_number is not None:
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.LeafRef']['meta_info']


    class TwoList(object):
        """
        config for one\_level list data
        
        .. attribute:: ldata
        
        	one list data
        	**type**\: list of    :py:class:`Ldata <ydk.models.ydktest.ydktest_sanity.Runner.TwoList.Ldata>`
        
        

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = []

            self.ldata = YList()
            self.ldata.parent = self
            self.ldata.name = 'ldata'


        class Ldata(object):
            """
            one list data
            
            .. attribute:: number  <key>
            
            	integer value type
            	**type**\:  int
            
            	**range:** \-2147483648..2147483647
            
            .. attribute:: name
            
            	this is string value
            	**type**\:  str
            
            .. attribute:: subl1
            
            	one list data
            	**type**\: list of    :py:class:`Subl1 <ydk.models.ydktest.ydktest_sanity.Runner.TwoList.Ldata.Subl1>`
            
            

            """

            _prefix = 'ydkut'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = ['number']

                self.number = None
                self.name = None
                self.subl1 = YList()
                self.subl1.parent = self
                self.subl1.name = 'subl1'


            class Subl1(object):
                """
                one list data
                
                .. attribute:: number  <key>
                
                	integer value type
                	**type**\:  int
                
                	**range:** \-2147483648..2147483647
                
                .. attribute:: name
                
                	this is string value
                	**type**\:  str
                
                

                """

                _prefix = 'ydkut'
                _revision = '2015-11-17'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = ['number']

                    self.number = None
                    self.name = None

                @property
                def _common_path(self):
                    if self.parent is None:
                        raise YPYModelError('parent is not set . Cannot derive path.')
                    if self.number is None:
                        raise YPYModelError('Key property number is None')

                    return self.parent._common_path +'/ydktest-sanity:subl1[ydktest-sanity:number = ' + str(self.number) + ']'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.number is not None:
                        return True

                    if self.name is not None:
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _ydktest_sanity as meta
                    return meta._meta_table['Runner.TwoList.Ldata.Subl1']['meta_info']

            @property
            def _common_path(self):
                if self.number is None:
                    raise YPYModelError('Key property number is None')

                return '/ydktest-sanity:runner/ydktest-sanity:two-list/ydktest-sanity:ldata[ydktest-sanity:number = ' + str(self.number) + ']'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.number is not None:
                    return True

                if self.name is not None:
                    return True

                if self.subl1 is not None:
                    for child_ref in self.subl1:
                        if child_ref._has_data():
                            return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.TwoList.Ldata']['meta_info']

        @property
        def _common_path(self):

            return '/ydktest-sanity:runner/ydktest-sanity:two-list'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.ldata is not None:
                for child_ref in self.ldata:
                    if child_ref._has_data():
                        return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.TwoList']['meta_info']


    class NotSupported1(object):
        """
        
        
        .. attribute:: not_supported_1_2
        
        	
        	**type**\:   :py:class:`NotSupported12 <ydk.models.ydktest.ydktest_sanity.Runner.NotSupported1.NotSupported12>`
        
        .. attribute:: not_supported_leaf
        
        	
        	**type**\:  str
        
        

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = []

            self.not_supported_1_2 = Runner.NotSupported1.NotSupported12()
            self.not_supported_1_2.parent = self
            self.not_supported_leaf = None


        class NotSupported12(object):
            """
            
            
            .. attribute:: some_leaf
            
            	
            	**type**\:  str
            
            

            """

            _prefix = 'ydkut'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.some_leaf = None

            @property
            def _common_path(self):

                return '/ydktest-sanity:runner/ydktest-sanity:not-supported-1/ydktest-sanity:not-supported-1-2'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.some_leaf is not None:
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.NotSupported1.NotSupported12']['meta_info']

        @property
        def _common_path(self):

            return '/ydktest-sanity:runner/ydktest-sanity:not-supported-1'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.not_supported_1_2 is not None and self.not_supported_1_2._has_data():
                return True

            if self.not_supported_leaf is not None:
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.NotSupported1']['meta_info']


    class OneList(object):
        """
        config for one\_level list data
        
        .. attribute:: identity_list
        
        	one list data
        	**type**\: list of    :py:class:`IdentityList <ydk.models.ydktest.ydktest_sanity.Runner.OneList.IdentityList>`
        
        .. attribute:: ldata
        
        	one list data
        	**type**\: list of    :py:class:`Ldata <ydk.models.ydktest.ydktest_sanity.Runner.OneList.Ldata>`
        
        .. attribute:: one_aug_list
        
        	config for one\_level list data
        	**type**\:   :py:class:`OneAugList <ydk.models.ydktest.ydktest_sanity.Runner.OneList.OneAugList>`
        
        

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = []

            self.identity_list = YList()
            self.identity_list.parent = self
            self.identity_list.name = 'identity_list'
            self.ldata = YList()
            self.ldata.parent = self
            self.ldata.name = 'ldata'
            self.one_aug_list = Runner.OneList.OneAugList()
            self.one_aug_list.parent = self


        class Ldata(object):
            """
            one list data
            
            .. attribute:: number  <key>
            
            	integer value type
            	**type**\:  int
            
            	**range:** \-2147483648..2147483647
            
            .. attribute:: name
            
            	this is string value
            	**type**\:  str
            
            

            """

            _prefix = 'ydkut'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = ['number']

                self.number = None
                self.name = None

            @property
            def _common_path(self):
                if self.number is None:
                    raise YPYModelError('Key property number is None')

                return '/ydktest-sanity:runner/ydktest-sanity:one-list/ydktest-sanity:ldata[ydktest-sanity:number = ' + str(self.number) + ']'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.number is not None:
                    return True

                if self.name is not None:
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.OneList.Ldata']['meta_info']


        class IdentityList(object):
            """
            one list data
            
            .. attribute:: id_ref  <key>
            
            	leafref key
            	**type**\:   :py:class:`BaseIdentityIdentity <ydk.models.ydktest.ydktest_sanity.BaseIdentityIdentity>`
            
            .. attribute:: config
            
            	
            	**type**\:   :py:class:`Config <ydk.models.ydktest.ydktest_sanity.Runner.OneList.IdentityList.Config>`
            
            

            """

            _prefix = 'ydkut'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = ['id_ref']

                self.id_ref = None
                self.config = Runner.OneList.IdentityList.Config()
                self.config.parent = self


            class Config(object):
                """
                
                
                .. attribute:: id
                
                	base id id ref
                	**type**\:   :py:class:`BaseIdentityIdentity <ydk.models.ydktest.ydktest_sanity.BaseIdentityIdentity>`
                
                

                """

                _prefix = 'ydkut'
                _revision = '2015-11-17'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = []

                    self.id = None

                @property
                def _common_path(self):
                    if self.parent is None:
                        raise YPYModelError('parent is not set . Cannot derive path.')

                    return self.parent._common_path +'/ydktest-sanity:config'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.id is not None:
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _ydktest_sanity as meta
                    return meta._meta_table['Runner.OneList.IdentityList.Config']['meta_info']

            @property
            def _common_path(self):
                if self.id_ref is None:
                    raise YPYModelError('Key property id_ref is None')

                return '/ydktest-sanity:runner/ydktest-sanity:one-list/ydktest-sanity:identity-list[ydktest-sanity:id-ref = ' + str(self.id_ref) + ']'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.id_ref is not None:
                    return True

                if self.config is not None and self.config._has_data():
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.OneList.IdentityList']['meta_info']


        class OneAugList(object):
            """
            config for one\_level list data
            
            .. attribute:: enabled
            
            	integer value type
            	**type**\:  bool
            
            .. attribute:: ldata
            
            	one list data
            	**type**\: list of    :py:class:`Ldata <ydk.models.ydktest.ydktest_sanity.Runner.OneList.OneAugList.Ldata>`
            
            

            """

            _prefix = 'ysanity-augm'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.enabled = None
                self.ldata = YList()
                self.ldata.parent = self
                self.ldata.name = 'ldata'


            class Ldata(object):
                """
                one list data
                
                .. attribute:: number  <key>
                
                	integer value type
                	**type**\:  int
                
                	**range:** \-2147483648..2147483647
                
                .. attribute:: name
                
                	this is string value
                	**type**\:  str
                
                

                """

                _prefix = 'ysanity-augm'
                _revision = '2015-11-17'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = ['number']

                    self.number = None
                    self.name = None

                @property
                def _common_path(self):
                    if self.number is None:
                        raise YPYModelError('Key property number is None')

                    return '/ydktest-sanity:runner/ydktest-sanity:one-list/ydktest-sanity-augm:one-aug-list/ydktest-sanity-augm:ldata[ydktest-sanity-augm:number = ' + str(self.number) + ']'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.number is not None:
                        return True

                    if self.name is not None:
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _ydktest_sanity as meta
                    return meta._meta_table['Runner.OneList.OneAugList.Ldata']['meta_info']

            @property
            def _common_path(self):

                return '/ydktest-sanity:runner/ydktest-sanity:one-list/ydktest-sanity-augm:one-aug-list'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.enabled is not None:
                    return True

                if self.ldata is not None:
                    for child_ref in self.ldata:
                        if child_ref._has_data():
                            return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.OneList.OneAugList']['meta_info']

        @property
        def _common_path(self):

            return '/ydktest-sanity:runner/ydktest-sanity:one-list'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.identity_list is not None:
                for child_ref in self.identity_list:
                    if child_ref._has_data():
                        return True

            if self.ldata is not None:
                for child_ref in self.ldata:
                    if child_ref._has_data():
                        return True

            if self.one_aug_list is not None and self.one_aug_list._has_data():
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.OneList']['meta_info']


    class Runner2(object):
        """
        
        
        .. attribute:: some_leaf
        
        	
        	**type**\:  str
        
        .. attribute:: _is_presence
        
        	Is present if this instance represents presence container else not
        	**type**\: bool
        
        

        This class is a :ref:`presence class<presence-class>`

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = []

            self._is_presence = True
            self.some_leaf = None

        @property
        def _common_path(self):

            return '/ydktest-sanity:runner/ydktest-sanity:runner-2'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self._is_presence:
                return True
            if self.some_leaf is not None:
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.Runner2']['meta_info']


    class One(object):
        """
        config for one\_level data
        
        .. attribute:: augmented_leaf
        
        	
        	**type**\:  str
        
        .. attribute:: config
        
        	test
        	**type**\:  anyxml
        
        .. attribute:: name
        
        	this is string value
        	**type**\:  str
        
        .. attribute:: number
        
        	integer value type
        	**type**\:  int
        
        	**range:** \-2147483648..2147483647
        
        .. attribute:: one_aug
        
        	config for one\_level data
        	**type**\:   :py:class:`OneAug <ydk.models.ydktest.ydktest_sanity.Runner.One.OneAug>`
        
        

        """

        _prefix = 'ydkut'
        _revision = '2015-11-17'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = []

            self.augmented_leaf = None
            self.config = None
            self.name = None
            self.number = None
            self.one_aug = Runner.One.OneAug()
            self.one_aug.parent = self


        class OneAug(object):
            """
            config for one\_level data
            
            .. attribute:: name
            
            	this is string value
            	**type**\:  str
            
            .. attribute:: number
            
            	integer value type
            	**type**\:  int
            
            	**range:** \-2147483648..2147483647
            
            

            """

            _prefix = 'ysanity-augm'
            _revision = '2015-11-17'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.name = None
                self.number = None

            @property
            def _common_path(self):

                return '/ydktest-sanity:runner/ydktest-sanity:one/ydktest-sanity-augm:one-aug'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.name is not None:
                    return True

                if self.number is not None:
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _ydktest_sanity as meta
                return meta._meta_table['Runner.One.OneAug']['meta_info']

        @property
        def _common_path(self):

            return '/ydktest-sanity:runner/ydktest-sanity:one'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.augmented_leaf is not None:
                return True

            if self.config is not None:
                return True

            if self.name is not None:
                return True

            if self.number is not None:
                return True

            if self.one_aug is not None and self.one_aug._has_data():
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['Runner.One']['meta_info']

    @property
    def _common_path(self):

        return '/ydktest-sanity:runner'

    def is_config(self):
        ''' Returns True if this instance represents config data else returns False '''
        return True

    def _has_data(self):
        if self.inbtw_list is not None and self.inbtw_list._has_data():
            return True

        if self.leaf_ref is not None and self.leaf_ref._has_data():
            return True

        if self.mand_list is not None:
            for child_ref in self.mand_list:
                if child_ref._has_data():
                    return True

        if self.not_supported_1 is not None and self.not_supported_1._has_data():
            return True

        if self.not_supported_2 is not None:
            for child_ref in self.not_supported_2:
                if child_ref._has_data():
                    return True

        if self.one is not None and self.one._has_data():
            return True

        if self.one_key_list is not None:
            for child_ref in self.one_key_list:
                if child_ref._has_data():
                    return True

        if self.one_list is not None and self.one_list._has_data():
            return True

        if self.runner_2 is not None and self.runner_2._has_data():
            return True

        if self.three is not None and self.three._has_data():
            return True

        if self.three_list is not None and self.three_list._has_data():
            return True

        if self.two is not None and self.two._has_data():
            return True

        if self.two_key_list is not None:
            for child_ref in self.two_key_list:
                if child_ref._has_data():
                    return True

        if self.two_list is not None and self.two_list._has_data():
            return True

        if self.ytypes is not None and self.ytypes._has_data():
            return True

        return False

    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _ydktest_sanity as meta
        return meta._meta_table['Runner']['meta_info']


class ConditionalInterface(object):
    """
    
    
    .. attribute:: ds0channelnumber
    
    	
    	**type**\:  int
    
    	**range:** 0..65535
    
    .. attribute:: ifmtu
    
    	
    	**type**\:  int
    
    	**range:** 0..4294967295
    
    .. attribute:: iftype
    
    	
    	**type**\:   :py:class:`IftypeEnum <ydk.models.ydktest.ydktest_sanity.ConditionalInterface.IftypeEnum>`
    
    

    """

    _prefix = 'ydkut'
    _revision = '2015-11-17'

    def __init__(self):
        self.ylist_key_names = []

        self.ds0channelnumber = None
        self.ifmtu = None
        self.iftype = None

    class IftypeEnum(Enum):
        """
        IftypeEnum

        .. data:: ethernet = 0

        .. data:: atm = 1

        .. data:: ds0 = 2

        """

        ethernet = 0

        atm = 1

        ds0 = 2


        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _ydktest_sanity as meta
            return meta._meta_table['ConditionalInterface.IftypeEnum']


    @property
    def _common_path(self):

        return '/ydktest-sanity:conditional-interface'

    def is_config(self):
        ''' Returns True if this instance represents config data else returns False '''
        return True

    def _has_data(self):
        if self.ds0channelnumber is not None:
            return True

        if self.ifmtu is not None:
            return True

        if self.iftype is not None:
            return True

        return False

    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _ydktest_sanity as meta
        return meta._meta_table['ConditionalInterface']['meta_info']


class ChildIdentityIdentity(BaseIdentityIdentity):
    """
    
    
    

    """

    _prefix = 'ydkut'
    _revision = '2015-11-17'

    def __init__(self):
        BaseIdentityIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _ydktest_sanity as meta
        return meta._meta_table['ChildIdentityIdentity']['meta_info']


class ChildChildIdentityIdentity(ChildIdentityIdentity):
    """
    
    
    

    """

    _prefix = 'ydkut'
    _revision = '2015-11-17'

    def __init__(self):
        ChildIdentityIdentity.__init__(self)
        self.ylist_key_names = []


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _ydktest_sanity as meta
        return meta._meta_table['ChildChildIdentityIdentity']['meta_info']


