
import re
import collections

from enum import Enum

from ydk._core._dm_meta_info import _MetaInfoClassMember, _MetaInfoClass, _MetaInfoEnum
from ydk._core._dm_meta_info import ATTRIBUTE, REFERENCE_CLASS, REFERENCE_LIST, REFERENCE_LEAFLIST, ANYXML_CLASS
from ydk._core._dm_meta_info import REFERENCE_IDENTITY_CLASS, REFERENCE_ENUM_CLASS, REFERENCE_BITS, REFERENCE_UNION

from ydk.types import Empty, YList, YLeafList, DELETE, Decimal64, FixedBitsDict
from ydk.errors import YPYError, YPYModelError
from ydk.providers._importer import _yang_ns

_meta_table = {
    'Address_FamilyIdentity' : {
        'meta_info' : _MetaInfoClass('Address_FamilyIdentity', REFERENCE_IDENTITY_CLASS,
            '''A base identity for all address families''',
            False, 
            [
            ],
            'openconfig-types',
            'ADDRESS_FAMILY',
            _yang_ns._namespaces['openconfig-types'],
            'ydk.models.ydktest.openconfig_types'
        ),
    },
    'Ipv4Identity' : {
        'meta_info' : _MetaInfoClass('Ipv4Identity', REFERENCE_IDENTITY_CLASS,
            '''The IPv4 address family''',
            False, 
            [
            ],
            'openconfig-types',
            'IPV4',
            _yang_ns._namespaces['openconfig-types'],
            'ydk.models.ydktest.openconfig_types'
        ),
    },
    'Ipv6Identity' : {
        'meta_info' : _MetaInfoClass('Ipv6Identity', REFERENCE_IDENTITY_CLASS,
            '''The IPv6 address family''',
            False, 
            [
            ],
            'openconfig-types',
            'IPV6',
            _yang_ns._namespaces['openconfig-types'],
            'ydk.models.ydktest.openconfig_types'
        ),
    },
}
