
import re
import collections

from enum import Enum

from ydk._core._dm_meta_info import _MetaInfoClassMember, _MetaInfoClass, _MetaInfoEnum
from ydk._core._dm_meta_info import ATTRIBUTE, REFERENCE_CLASS, REFERENCE_LIST, REFERENCE_LEAFLIST, ANYXML_CLASS
from ydk._core._dm_meta_info import REFERENCE_IDENTITY_CLASS, REFERENCE_ENUM_CLASS, REFERENCE_BITS, REFERENCE_UNION

from ydk.types import Empty, YList, YLeafList, DELETE, Decimal64, FixedBitsDict
from ydk.errors import YPYError, YPYModelError
from ydk.providers._importer import _yang_ns

_meta_table = {
    'BgpSetCommunityOptionTypeEnum' : _MetaInfoEnum('BgpSetCommunityOptionTypeEnum',
        'ydk.models.ydktest.openconfig_bgp_policy', 'BgpSetCommunityOptionTypeEnum',
        '''Type definition for options when setting the community
attribute in a policy action''',
        {
            'ADD':'ADD',
            'REMOVE':'REMOVE',
            'REPLACE':'REPLACE',
        }, 'openconfig-bgp-policy', _yang_ns._namespaces['openconfig-bgp-policy']),
    'BgpNextHopTypeEnum' : _MetaInfoEnum('BgpNextHopTypeEnum',
        'ydk.models.ydktest.openconfig_bgp_policy', 'BgpNextHopTypeEnum',
        ''' ''',
        {
            'SELF':'SELF',
        }, 'openconfig-bgp-policy', _yang_ns._namespaces['openconfig-bgp-policy']),
    'BgpSetMedTypeEnum' : _MetaInfoEnum('BgpSetMedTypeEnum',
        'ydk.models.ydktest.openconfig_bgp_policy', 'BgpSetMedTypeEnum',
        ''' ''',
        {
            'IGP':'IGP',
        }, 'openconfig-bgp-policy', _yang_ns._namespaces['openconfig-bgp-policy']),
}
