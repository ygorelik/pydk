
import re
import collections

from enum import Enum

from ydk._core._dm_meta_info import _MetaInfoClassMember, _MetaInfoClass, _MetaInfoEnum
from ydk._core._dm_meta_info import ATTRIBUTE, REFERENCE_CLASS, REFERENCE_LIST, REFERENCE_LEAFLIST, ANYXML_CLASS
from ydk._core._dm_meta_info import REFERENCE_IDENTITY_CLASS, REFERENCE_ENUM_CLASS, REFERENCE_BITS, REFERENCE_UNION

from ydk.types import Empty, YList, YLeafList, DELETE, Decimal64, FixedBitsDict
from ydk.errors import YPYError, YPYModelError
from ydk.providers._importer import _yang_ns

_meta_table = {
    'InheritRunner.One' : {
        'meta_info' : _MetaInfoClass('InheritRunner.One', REFERENCE_CLASS,
            '''config for one_level data''',
            False, 
            [
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                this is string value
                ''',
                'name',
                'inherit', False),
            _MetaInfoClassMember('number', ATTRIBUTE, 'int', 'int32',
                None, None,
                [('-2147483648', '2147483647')], [],
                '''                integer value type
                ''',
                'number',
                'inherit', False),
            ],
            'inherit',
            'one',
            _yang_ns._namespaces['inherit'],
            'ydk.models.ydktest.inherit',
        ),
    },
    'InheritRunner' : {
        'meta_info' : _MetaInfoClass('InheritRunner', REFERENCE_CLASS,
            ''' ''',
            False, 
            [
            _MetaInfoClassMember('jumper', ATTRIBUTE, 'int', 'int32',
                None, None,
                [('-2147483648', '2147483647')], [],
                '''                ''',
                'jumper',
                'inherit', False),
            _MetaInfoClassMember('one', REFERENCE_CLASS, 'One', '',
                'ydk.models.ydktest.inherit', 'InheritRunner.One',
                [], [],
                '''                config for one_level data
                ''',
                'one',
                'inherit', False),
            ],
            'inherit',
            'inherit-runner',
            _yang_ns._namespaces['inherit'],
            'ydk.models.ydktest.inherit',
        ),
    },
}
_meta_table['InheritRunner.One']['meta_info'].parent =_meta_table['InheritRunner']['meta_info']
