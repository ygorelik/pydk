
import re
import collections

from enum import Enum

from ydk._core._dm_meta_info import _MetaInfoClassMember, _MetaInfoClass, _MetaInfoEnum
from ydk._core._dm_meta_info import ATTRIBUTE, REFERENCE_CLASS, REFERENCE_LIST, REFERENCE_LEAFLIST, ANYXML_CLASS
from ydk._core._dm_meta_info import REFERENCE_IDENTITY_CLASS, REFERENCE_ENUM_CLASS, REFERENCE_BITS, REFERENCE_UNION

from ydk.types import Empty, YList, YLeafList, DELETE, Decimal64, FixedBitsDict
from ydk.errors import YPYError, YPYModelError
from ydk.providers._importer import _yang_ns

_meta_table = {
    'ActionTypeEnum' : _MetaInfoEnum('ActionTypeEnum',
        'ydk.models.ydktest.ietf_netconf_acm', 'ActionTypeEnum',
        '''Action taken by the server when a particular
rule matches.''',
        {
            'permit':'permit',
            'deny':'deny',
        }, 'ietf-netconf-acm', _yang_ns._namespaces['ietf-netconf-acm']),
    'Nacm.Groups.Group' : {
        'meta_info' : _MetaInfoClass('Nacm.Groups.Group', REFERENCE_LIST,
            '''One NACM Group Entry.  This list will only contain
configured entries, not any entries learned from
any transport protocols.''',
            False, 
            [
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'group-name-type',
                None, None,
                [], [b'[^\\*].*'],
                '''                Group name associated with this entry.
                ''',
                'name',
                'ietf-netconf-acm', True),
            _MetaInfoClassMember('user-name', REFERENCE_LEAFLIST, 'str', 'user-name-type',
                None, None,
                [(1, '18446744073709551615')], [],
                '''                Each entry identifies the username of
                a member of the group associated with
                this entry.
                ''',
                'user_name',
                'ietf-netconf-acm', False),
            ],
            'ietf-netconf-acm',
            'group',
            _yang_ns._namespaces['ietf-netconf-acm'],
            'ydk.models.ydktest.ietf_netconf_acm',
        ),
    },
    'Nacm.Groups' : {
        'meta_info' : _MetaInfoClass('Nacm.Groups', REFERENCE_CLASS,
            '''NETCONF Access Control Groups.''',
            False, 
            [
            _MetaInfoClassMember('group', REFERENCE_LIST, 'Group', '',
                'ydk.models.ydktest.ietf_netconf_acm', 'Nacm.Groups.Group',
                [], [],
                '''                One NACM Group Entry.  This list will only contain
                configured entries, not any entries learned from
                any transport protocols.
                ''',
                'group',
                'ietf-netconf-acm', False),
            ],
            'ietf-netconf-acm',
            'groups',
            _yang_ns._namespaces['ietf-netconf-acm'],
            'ydk.models.ydktest.ietf_netconf_acm',
        ),
    },
    'Nacm.RuleList.Rule' : {
        'meta_info' : _MetaInfoClass('Nacm.RuleList.Rule', REFERENCE_LIST,
            '''One access control rule.

Rules are processed in user-defined order until a match is
found.  A rule matches if 'module-name', 'rule-type', and
'access-operations' match the request.  If a rule
matches, the 'action' leaf determines if access is granted
or not.''',
            False, 
            [
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'string',
                None, None,
                [(1, '18446744073709551615')], [],
                '''                Arbitrary name assigned to the rule.
                ''',
                'name',
                'ietf-netconf-acm', True),
            _MetaInfoClassMember('access-operations', REFERENCE_UNION, 'str', 'union',
                None, None,
                [], [],
                '''                Access operations associated with this rule.
                
                This leaf matches if it has the value '*' or if the
                bit corresponding to the requested operation is set.
                ''',
                'access_operations',
                'ietf-netconf-acm', False, [
                    _MetaInfoClassMember('access-operations', ATTRIBUTE, 'str', 'matchall-string-type',
                        None, None,
                        [], [b'\\*'],
                        '''                        Access operations associated with this rule.
                        
                        This leaf matches if it has the value '*' or if the
                        bit corresponding to the requested operation is set.
                        ''',
                        'access_operations',
                        'ietf-netconf-acm', False, default_value="'*'"),
                    _MetaInfoClassMember('access-operations', REFERENCE_BITS, 'AccessOperationsType', 'access-operations-type',
                        'ydk.models.ydktest.ietf_netconf_acm', 'AccessOperationsType',
                        [], [],
                        '''                        Access operations associated with this rule.
                        
                        This leaf matches if it has the value '*' or if the
                        bit corresponding to the requested operation is set.
                        ''',
                        'access_operations',
                        'ietf-netconf-acm', False, default_value='*'),
                ], default_value="'*'"),
            _MetaInfoClassMember('action', REFERENCE_ENUM_CLASS, 'ActionTypeEnum', 'action-type',
                'ydk.models.ydktest.ietf_netconf_acm', 'ActionTypeEnum',
                [], [],
                '''                The access control action associated with the
                rule.  If a rule is determined to match a
                particular request, then this object is used
                to determine whether to permit or deny the
                request.
                ''',
                'action',
                'ietf-netconf-acm', False, is_mandatory=True),
            _MetaInfoClassMember('comment', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                A textual description of the access rule.
                ''',
                'comment',
                'ietf-netconf-acm', False),
            _MetaInfoClassMember('module-name', REFERENCE_UNION, 'str', 'union',
                None, None,
                [], [],
                '''                Name of the module associated with this rule.
                
                This leaf matches if it has the value '*' or if the
                object being accessed is defined in the module with the
                specified module name.
                ''',
                'module_name',
                'ietf-netconf-acm', False, [
                    _MetaInfoClassMember('module-name', ATTRIBUTE, 'str', 'matchall-string-type',
                        None, None,
                        [], [b'\\*'],
                        '''                        Name of the module associated with this rule.
                        
                        This leaf matches if it has the value '*' or if the
                        object being accessed is defined in the module with the
                        specified module name.
                        ''',
                        'module_name',
                        'ietf-netconf-acm', False, default_value="'*'"),
                    _MetaInfoClassMember('module-name', ATTRIBUTE, 'str', 'string',
                        None, None,
                        [], [],
                        '''                        Name of the module associated with this rule.
                        
                        This leaf matches if it has the value '*' or if the
                        object being accessed is defined in the module with the
                        specified module name.
                        ''',
                        'module_name',
                        'ietf-netconf-acm', False, default_value="'*'"),
                ], default_value="'*'"),
            _MetaInfoClassMember('notification-name', REFERENCE_UNION, 'str', 'union',
                None, None,
                [], [],
                '''                This leaf matches if it has the value '*' or if its
                value equals the requested notification name.
                ''',
                'notification_name',
                'ietf-netconf-acm', False, [
                    _MetaInfoClassMember('notification-name', ATTRIBUTE, 'str', 'matchall-string-type',
                        None, None,
                        [], [b'\\*'],
                        '''                        This leaf matches if it has the value '*' or if its
                        value equals the requested notification name.
                        ''',
                        'notification_name',
                        'ietf-netconf-acm', False),
                    _MetaInfoClassMember('notification-name', ATTRIBUTE, 'str', 'string',
                        None, None,
                        [], [],
                        '''                        This leaf matches if it has the value '*' or if its
                        value equals the requested notification name.
                        ''',
                        'notification_name',
                        'ietf-netconf-acm', False),
                ]),
            _MetaInfoClassMember('path', ATTRIBUTE, 'str', 'node-instance-identifier',
                None, None,
                [], [],
                '''                Data Node Instance Identifier associated with the
                data node controlled by this rule.
                
                Configuration data or state data instance
                identifiers start with a top-level data node.  A
                complete instance identifier is required for this
                type of path value.
                
                The special value '/' refers to all possible
                datastore contents.
                ''',
                'path',
                'ietf-netconf-acm', False, is_mandatory=True),
            _MetaInfoClassMember('rpc-name', REFERENCE_UNION, 'str', 'union',
                None, None,
                [], [],
                '''                This leaf matches if it has the value '*' or if
                its value equals the requested protocol operation
                name.
                ''',
                'rpc_name',
                'ietf-netconf-acm', False, [
                    _MetaInfoClassMember('rpc-name', ATTRIBUTE, 'str', 'matchall-string-type',
                        None, None,
                        [], [b'\\*'],
                        '''                        This leaf matches if it has the value '*' or if
                        its value equals the requested protocol operation
                        name.
                        ''',
                        'rpc_name',
                        'ietf-netconf-acm', False),
                    _MetaInfoClassMember('rpc-name', ATTRIBUTE, 'str', 'string',
                        None, None,
                        [], [],
                        '''                        This leaf matches if it has the value '*' or if
                        its value equals the requested protocol operation
                        name.
                        ''',
                        'rpc_name',
                        'ietf-netconf-acm', False),
                ]),
            ],
            'ietf-netconf-acm',
            'rule',
            _yang_ns._namespaces['ietf-netconf-acm'],
            'ydk.models.ydktest.ietf_netconf_acm',
        ),
    },
    'Nacm.RuleList' : {
        'meta_info' : _MetaInfoClass('Nacm.RuleList', REFERENCE_LIST,
            '''An ordered collection of access control rules.''',
            False, 
            [
            _MetaInfoClassMember('name', ATTRIBUTE, 'str', 'string',
                None, None,
                [(1, '18446744073709551615')], [],
                '''                Arbitrary name assigned to the rule-list.
                ''',
                'name',
                'ietf-netconf-acm', True),
            _MetaInfoClassMember('group', REFERENCE_UNION, 'str', 'union',
                None, None,
                [], [],
                '''                List of administrative groups that will be
                assigned the associated access rights
                defined by the 'rule' list.
                
                The string '*' indicates that all groups apply to the
                entry.
                ''',
                'group',
                'ietf-netconf-acm', False, [
                    _MetaInfoClassMember('group', REFERENCE_LEAFLIST, 'str', 'matchall-string-type',
                        None, None,
                        [], [b'\\*'],
                        '''                        List of administrative groups that will be
                        assigned the associated access rights
                        defined by the 'rule' list.
                        
                        The string '*' indicates that all groups apply to the
                        entry.
                        ''',
                        'group',
                        'ietf-netconf-acm', False),
                    _MetaInfoClassMember('group', REFERENCE_LEAFLIST, 'str', 'group-name-type',
                        None, None,
                        [], [b'[^\\*].*'],
                        '''                        List of administrative groups that will be
                        assigned the associated access rights
                        defined by the 'rule' list.
                        
                        The string '*' indicates that all groups apply to the
                        entry.
                        ''',
                        'group',
                        'ietf-netconf-acm', False),
                ]),
            _MetaInfoClassMember('rule', REFERENCE_LIST, 'Rule', '',
                'ydk.models.ydktest.ietf_netconf_acm', 'Nacm.RuleList.Rule',
                [], [],
                '''                One access control rule.
                
                Rules are processed in user-defined order until a match is
                found.  A rule matches if 'module-name', 'rule-type', and
                'access-operations' match the request.  If a rule
                matches, the 'action' leaf determines if access is granted
                or not.
                ''',
                'rule',
                'ietf-netconf-acm', False),
            ],
            'ietf-netconf-acm',
            'rule-list',
            _yang_ns._namespaces['ietf-netconf-acm'],
            'ydk.models.ydktest.ietf_netconf_acm',
        ),
    },
    'Nacm' : {
        'meta_info' : _MetaInfoClass('Nacm', REFERENCE_CLASS,
            '''Parameters for NETCONF Access Control Model.''',
            False, 
            [
            _MetaInfoClassMember('denied-data-writes', ATTRIBUTE, 'int', 'yang:zero-based-counter32',
                None, None,
                [('0', '4294967295')], [],
                '''                Number of times since the server last restarted that a
                protocol operation request to alter
                a configuration datastore was denied.
                ''',
                'denied_data_writes',
                'ietf-netconf-acm', False, is_config=False, is_mandatory=True),
            _MetaInfoClassMember('denied-notifications', ATTRIBUTE, 'int', 'yang:zero-based-counter32',
                None, None,
                [('0', '4294967295')], [],
                '''                Number of times since the server last restarted that
                a notification was dropped for a subscription because
                access to the event type was denied.
                ''',
                'denied_notifications',
                'ietf-netconf-acm', False, is_config=False, is_mandatory=True),
            _MetaInfoClassMember('denied-operations', ATTRIBUTE, 'int', 'yang:zero-based-counter32',
                None, None,
                [('0', '4294967295')], [],
                '''                Number of times since the server last restarted that a
                protocol operation request was denied.
                ''',
                'denied_operations',
                'ietf-netconf-acm', False, is_config=False, is_mandatory=True),
            _MetaInfoClassMember('enable-external-groups', ATTRIBUTE, 'bool', 'boolean',
                None, None,
                [], [],
                '''                Controls whether the server uses the groups reported by the
                NETCONF transport layer when it assigns the user to a set of
                NACM groups.  If this leaf has the value 'false', any group
                names reported by the transport layer are ignored by the
                server.
                ''',
                'enable_external_groups',
                'ietf-netconf-acm', False, default_value='True'),
            _MetaInfoClassMember('enable-nacm', ATTRIBUTE, 'bool', 'boolean',
                None, None,
                [], [],
                '''                Enables or disables all NETCONF access control
                enforcement.  If 'true', then enforcement
                is enabled.  If 'false', then enforcement
                is disabled.
                ''',
                'enable_nacm',
                'ietf-netconf-acm', False, default_value='True'),
            _MetaInfoClassMember('exec-default', REFERENCE_ENUM_CLASS, 'ActionTypeEnum', 'action-type',
                'ydk.models.ydktest.ietf_netconf_acm', 'ActionTypeEnum',
                [], [],
                '''                Controls whether exec access is granted if no appropriate
                rule is found for a particular protocol operation request.
                ''',
                'exec_default',
                'ietf-netconf-acm', False, default_value='ietf_netconf_acm.ActionTypeEnum.permit'),
            _MetaInfoClassMember('groups', REFERENCE_CLASS, 'Groups', '',
                'ydk.models.ydktest.ietf_netconf_acm', 'Nacm.Groups',
                [], [],
                '''                NETCONF Access Control Groups.
                ''',
                'groups',
                'ietf-netconf-acm', False),
            _MetaInfoClassMember('read-default', REFERENCE_ENUM_CLASS, 'ActionTypeEnum', 'action-type',
                'ydk.models.ydktest.ietf_netconf_acm', 'ActionTypeEnum',
                [], [],
                '''                Controls whether read access is granted if
                no appropriate rule is found for a
                particular read request.
                ''',
                'read_default',
                'ietf-netconf-acm', False, default_value='ietf_netconf_acm.ActionTypeEnum.permit'),
            _MetaInfoClassMember('rule-list', REFERENCE_LIST, 'RuleList', '',
                'ydk.models.ydktest.ietf_netconf_acm', 'Nacm.RuleList',
                [], [],
                '''                An ordered collection of access control rules.
                ''',
                'rule_list',
                'ietf-netconf-acm', False),
            _MetaInfoClassMember('write-default', REFERENCE_ENUM_CLASS, 'ActionTypeEnum', 'action-type',
                'ydk.models.ydktest.ietf_netconf_acm', 'ActionTypeEnum',
                [], [],
                '''                Controls whether create, update, or delete access
                is granted if no appropriate rule is found for a
                particular write request.
                ''',
                'write_default',
                'ietf-netconf-acm', False, default_value='ietf_netconf_acm.ActionTypeEnum.deny'),
            ],
            'ietf-netconf-acm',
            'nacm',
            _yang_ns._namespaces['ietf-netconf-acm'],
            'ydk.models.ydktest.ietf_netconf_acm',
        ),
    },
}
_meta_table['Nacm.Groups.Group']['meta_info'].parent =_meta_table['Nacm.Groups']['meta_info']
_meta_table['Nacm.RuleList.Rule']['meta_info'].parent =_meta_table['Nacm.RuleList']['meta_info']
_meta_table['Nacm.Groups']['meta_info'].parent =_meta_table['Nacm']['meta_info']
_meta_table['Nacm.RuleList']['meta_info'].parent =_meta_table['Nacm']['meta_info']
