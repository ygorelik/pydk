""" openconfig_routing_policy 

This module describes a YANG model for routing policy
configuration. It is a limited subset of all of the policy
configuration parameters available in the variety of vendor
implementations, but supports widely used constructs for managing
how routes are imported, exported, and modified across different
routing protocols.  This module is intended to be used in
conjunction with routing protocol configuration models (e.g.,
BGP) defined in other modules.

Route policy expression\:

Policies are expressed as a set of top\-level policy definitions,
each of which consists of a sequence of policy statements. Policy
statements consist of simple condition\-action tuples. Conditions
may include mutiple match or comparison operations, and similarly
actions may be multitude of changes to route attributes or a
final disposition of accepting or rejecting the route.

Route policy evaluation\:

Policy definitions are referenced in routing protocol
configurations using import and export configuration statements.
The arguments are members of an ordered list of named policy
definitions which comprise a policy chain, and optionally, an
explicit default policy action (i.e., reject or accept).

Evaluation of each policy definition proceeds by evaluating its
corresponding individual policy statements in order.  When a
condition statement in a policy statement is satisfied, the
corresponding action statement is executed.  If the action
statement has either accept\-route or reject\-route actions, policy
evaluation of the current policy definition stops, and no further
policy definitions in the chain are evaluated.

If the condition is not satisfied, then evaluation proceeds to
the next policy statement.  If none of the policy statement
conditions are satisfied, then evaluation of the current policy
definition stops, and the next policy definition in the chain is
evaluated.  When the end of the policy chain is reached, the
default route disposition action is performed (i.e., reject\-route
unless an an alternate default action is specified for the
chain).

Policy 'subroutines' (or nested policies) are supported by
allowing policy statement conditions to reference another policy
definition which applies conditions and actions from the
referenced policy before returning to the calling policy
statement and resuming evaluation.  If the called policy
results in an accept\-route (either explicit or by default), then
the subroutine returns an effective true value to the calling
policy.  Similarly, a reject\-route action returns false.  If the
subroutine returns true, the calling policy continues to evaluate
the remaining conditions (using a modified route if the
subroutine performed any changes to the route).

"""


import re
import collections

from enum import Enum

from ydk.types import Empty, YList, YLeafList, DELETE, Decimal64, FixedBitsDict

from ydk.errors import YPYError, YPYModelError



class DefaultPolicyTypeEnum(Enum):
    """
    DefaultPolicyTypeEnum

    type used to specify default route disposition in

    a policy chain

    .. data:: ACCEPT_ROUTE = 0

    	default policy to accept the route

    .. data:: REJECT_ROUTE = 1

    	default policy to reject the route

    """

    ACCEPT_ROUTE = 0

    REJECT_ROUTE = 1


    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
        return meta._meta_table['DefaultPolicyTypeEnum']



class RoutingPolicy(object):
    """
    Top\-level container for all routing policy configuration
    
    .. attribute:: defined_sets
    
    	Predefined sets of attributes used in policy match statements
    	**type**\:   :py:class:`DefinedSets <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets>`
    
    .. attribute:: policy_definitions
    
    	Enclosing container for the list of top\-level policy  definitions
    	**type**\:   :py:class:`PolicyDefinitions <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions>`
    
    

    """

    _prefix = 'oc-rpol'
    _revision = '2016-05-12'

    def __init__(self):
        self.ylist_key_names = []

        self.defined_sets = RoutingPolicy.DefinedSets()
        self.defined_sets.parent = self
        self.policy_definitions = RoutingPolicy.PolicyDefinitions()
        self.policy_definitions.parent = self


    class DefinedSets(object):
        """
        Predefined sets of attributes used in policy match
        statements
        
        .. attribute:: bgp_defined_sets
        
        	BGP\-related set definitions for policy match conditions
        	**type**\:   :py:class:`BgpDefinedSets <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets>`
        
        .. attribute:: neighbor_sets
        
        	Enclosing container for the list of neighbor set definitions
        	**type**\:   :py:class:`NeighborSets <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.NeighborSets>`
        
        .. attribute:: prefix_sets
        
        	Enclosing container 
        	**type**\:   :py:class:`PrefixSets <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.PrefixSets>`
        
        .. attribute:: tag_sets
        
        	Enclosing container for the list of tag sets
        	**type**\:   :py:class:`TagSets <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.TagSets>`
        
        

        """

        _prefix = 'oc-rpol'
        _revision = '2016-05-12'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = []

            self.bgp_defined_sets = RoutingPolicy.DefinedSets.BgpDefinedSets()
            self.bgp_defined_sets.parent = self
            self.neighbor_sets = RoutingPolicy.DefinedSets.NeighborSets()
            self.neighbor_sets.parent = self
            self.prefix_sets = RoutingPolicy.DefinedSets.PrefixSets()
            self.prefix_sets.parent = self
            self.tag_sets = RoutingPolicy.DefinedSets.TagSets()
            self.tag_sets.parent = self


        class PrefixSets(object):
            """
            Enclosing container 
            
            .. attribute:: prefix_set
            
            	List of the defined prefix sets
            	**type**\: list of    :py:class:`PrefixSet <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.PrefixSets.PrefixSet>`
            
            

            """

            _prefix = 'oc-rpol'
            _revision = '2016-05-12'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.prefix_set = YList()
                self.prefix_set.parent = self
                self.prefix_set.name = 'prefix_set'


            class PrefixSet(object):
                """
                List of the defined prefix sets
                
                .. attribute:: prefix_set_name  <key>
                
                	Reference to prefix name list key
                	**type**\:  str
                
                	**refers to**\:  :py:class:`prefix_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Config>`
                
                .. attribute:: config
                
                	Configuration data for prefix sets
                	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Config>`
                
                .. attribute:: prefixes
                
                	Enclosing container for the list of prefixes in a policy prefix list
                	**type**\:   :py:class:`Prefixes <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes>`
                
                .. attribute:: state
                
                	Operational state data 
                	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.State>`
                
                	**config**\: False
                
                

                """

                _prefix = 'oc-rpol'
                _revision = '2016-05-12'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = ['prefix_set_name']

                    self.prefix_set_name = None
                    self.config = RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Config()
                    self.config.parent = self
                    self.prefixes = RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes()
                    self.prefixes.parent = self
                    self.state = RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.State()
                    self.state.parent = self


                class Config(object):
                    """
                    Configuration data for prefix sets
                    
                    .. attribute:: prefix_set_name
                    
                    	name / label of the prefix set \-\- this is used to reference the set in match conditions
                    	**type**\:  str
                    
                    

                    """

                    _prefix = 'oc-rpol'
                    _revision = '2016-05-12'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = []

                        self.prefix_set_name = None

                    @property
                    def _common_path(self):
                        if self.parent is None:
                            raise YPYModelError('parent is not set . Cannot derive path.')

                        return self.parent._common_path +'/openconfig-routing-policy:config'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return True

                    def _has_data(self):
                        if self.prefix_set_name is not None:
                            return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                        return meta._meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Config']['meta_info']


                class State(object):
                    """
                    Operational state data 
                    
                    .. attribute:: prefix_set_name
                    
                    	name / label of the prefix set \-\- this is used to reference the set in match conditions
                    	**type**\:  str
                    
                    	**config**\: False
                    
                    

                    """

                    _prefix = 'oc-rpol'
                    _revision = '2016-05-12'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = []

                        self.prefix_set_name = None

                    @property
                    def _common_path(self):
                        if self.parent is None:
                            raise YPYModelError('parent is not set . Cannot derive path.')

                        return self.parent._common_path +'/openconfig-routing-policy:state'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return False

                    def _has_data(self):
                        if self.prefix_set_name is not None:
                            return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                        return meta._meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.State']['meta_info']


                class Prefixes(object):
                    """
                    Enclosing container for the list of prefixes in a policy
                    prefix list
                    
                    .. attribute:: prefix
                    
                    	List of prefixes in the prefix set
                    	**type**\: list of    :py:class:`Prefix <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix>`
                    
                    

                    """

                    _prefix = 'oc-rpol'
                    _revision = '2016-05-12'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = []

                        self.prefix = YList()
                        self.prefix.parent = self
                        self.prefix.name = 'prefix'


                    class Prefix(object):
                        """
                        List of prefixes in the prefix set
                        
                        .. attribute:: ip_prefix  <key>
                        
                        	Reference to the ip\-prefix list key
                        	**type**\: one of the below types:
                        
                        	**type**\:  str
                        
                        	**pattern:** (([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])/(([0\-9])\|([1\-2][0\-9])\|(3[0\-2]))
                        
                        
                        ----
                        	**type**\:  str
                        
                        	**pattern:** ((\:\|[0\-9a\-fA\-F]{0,4})\:)([0\-9a\-fA\-F]{0,4}\:){0,5}((([0\-9a\-fA\-F]{0,4}\:)?(\:\|[0\-9a\-fA\-F]{0,4}))\|(((25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])\\.){3}(25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])))(/(([0\-9])\|([0\-9]{2})\|(1[0\-1][0\-9])\|(12[0\-8])))
                        
                        
                        ----
                        .. attribute:: masklength_range  <key>
                        
                        	Reference to the masklength\-range list key
                        	**type**\:  str
                        
                        	**pattern:** ^([0\-9]+\\.\\.[0\-9]+)\|exact$
                        
                        	**refers to**\:  :py:class:`masklength_range <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.Config>`
                        
                        .. attribute:: config
                        
                        	Configuration data for prefix definition
                        	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.Config>`
                        
                        .. attribute:: state
                        
                        	Operational state data for prefix definition
                        	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.State>`
                        
                        	**config**\: False
                        
                        

                        """

                        _prefix = 'oc-rpol'
                        _revision = '2016-05-12'

                        def __init__(self):
                            self.parent = None
                            self.ylist_key_names = ['ip_prefix','masklength_range']

                            self.ip_prefix = None
                            self.masklength_range = None
                            self.config = RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.Config()
                            self.config.parent = self
                            self.state = RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.State()
                            self.state.parent = self


                        class Config(object):
                            """
                            Configuration data for prefix definition
                            
                            .. attribute:: ip_prefix
                            
                            	The prefix member in CIDR notation \-\- while the prefix may be either IPv4 or IPv6, most implementations require all members of the prefix set to be the same address family.  Mixing address types in the same prefix set is likely to cause an error
                            	**type**\: one of the below types:
                            
                            	**type**\:  str
                            
                            	**pattern:** (([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])/(([0\-9])\|([1\-2][0\-9])\|(3[0\-2]))
                            
                            	**mandatory**\: True
                            
                            
                            ----
                            	**type**\:  str
                            
                            	**pattern:** ((\:\|[0\-9a\-fA\-F]{0,4})\:)([0\-9a\-fA\-F]{0,4}\:){0,5}((([0\-9a\-fA\-F]{0,4}\:)?(\:\|[0\-9a\-fA\-F]{0,4}))\|(((25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])\\.){3}(25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])))(/(([0\-9])\|([0\-9]{2})\|(1[0\-1][0\-9])\|(12[0\-8])))
                            
                            	**mandatory**\: True
                            
                            
                            ----
                            .. attribute:: masklength_range
                            
                            	Defines a range for the masklength, or 'exact' if the prefix has an exact length.  Example\: 10.3.192.0/21 through 10.3.192.0/24 would be expressed as prefix\: 10.3.192.0/21, masklength\-range\: 21..24.  Example\: 10.3.192.0/21 would be expressed as prefix\: 10.3.192.0/21, masklength\-range\: exact
                            	**type**\:  str
                            
                            	**pattern:** ^([0\-9]+\\.\\.[0\-9]+)\|exact$
                            
                            

                            """

                            _prefix = 'oc-rpol'
                            _revision = '2016-05-12'

                            def __init__(self):
                                self.parent = None
                                self.ylist_key_names = []

                                self.ip_prefix = None
                                self.masklength_range = None

                            @property
                            def _common_path(self):
                                if self.parent is None:
                                    raise YPYModelError('parent is not set . Cannot derive path.')

                                return self.parent._common_path +'/openconfig-routing-policy:config'

                            def is_config(self):
                                ''' Returns True if this instance represents config data else returns False '''
                                return True

                            def _has_data(self):
                                if self.ip_prefix is not None:
                                    return True

                                if self.masklength_range is not None:
                                    return True

                                return False

                            @staticmethod
                            def _meta_info():
                                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                return meta._meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.Config']['meta_info']


                        class State(object):
                            """
                            Operational state data for prefix definition
                            
                            .. attribute:: ip_prefix
                            
                            	The prefix member in CIDR notation \-\- while the prefix may be either IPv4 or IPv6, most implementations require all members of the prefix set to be the same address family.  Mixing address types in the same prefix set is likely to cause an error
                            	**type**\: one of the below types:
                            
                            	**type**\:  str
                            
                            	**pattern:** (([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])/(([0\-9])\|([1\-2][0\-9])\|(3[0\-2]))
                            
                            	**mandatory**\: True
                            
                            	**config**\: False
                            
                            
                            ----
                            	**type**\:  str
                            
                            	**pattern:** ((\:\|[0\-9a\-fA\-F]{0,4})\:)([0\-9a\-fA\-F]{0,4}\:){0,5}((([0\-9a\-fA\-F]{0,4}\:)?(\:\|[0\-9a\-fA\-F]{0,4}))\|(((25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])\\.){3}(25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])))(/(([0\-9])\|([0\-9]{2})\|(1[0\-1][0\-9])\|(12[0\-8])))
                            
                            	**mandatory**\: True
                            
                            	**config**\: False
                            
                            
                            ----
                            .. attribute:: masklength_range
                            
                            	Defines a range for the masklength, or 'exact' if the prefix has an exact length.  Example\: 10.3.192.0/21 through 10.3.192.0/24 would be expressed as prefix\: 10.3.192.0/21, masklength\-range\: 21..24.  Example\: 10.3.192.0/21 would be expressed as prefix\: 10.3.192.0/21, masklength\-range\: exact
                            	**type**\:  str
                            
                            	**pattern:** ^([0\-9]+\\.\\.[0\-9]+)\|exact$
                            
                            	**config**\: False
                            
                            

                            """

                            _prefix = 'oc-rpol'
                            _revision = '2016-05-12'

                            def __init__(self):
                                self.parent = None
                                self.ylist_key_names = []

                                self.ip_prefix = None
                                self.masklength_range = None

                            @property
                            def _common_path(self):
                                if self.parent is None:
                                    raise YPYModelError('parent is not set . Cannot derive path.')

                                return self.parent._common_path +'/openconfig-routing-policy:state'

                            def is_config(self):
                                ''' Returns True if this instance represents config data else returns False '''
                                return False

                            def _has_data(self):
                                if self.ip_prefix is not None:
                                    return True

                                if self.masklength_range is not None:
                                    return True

                                return False

                            @staticmethod
                            def _meta_info():
                                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                return meta._meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix.State']['meta_info']

                        @property
                        def _common_path(self):
                            if self.parent is None:
                                raise YPYModelError('parent is not set . Cannot derive path.')
                            if self.ip_prefix is None:
                                raise YPYModelError('Key property ip_prefix is None')
                            if self.masklength_range is None:
                                raise YPYModelError('Key property masklength_range is None')

                            return self.parent._common_path +'/openconfig-routing-policy:prefix[openconfig-routing-policy:ip-prefix = ' + str(self.ip_prefix) + '][openconfig-routing-policy:masklength-range = ' + str(self.masklength_range) + ']'

                        def is_config(self):
                            ''' Returns True if this instance represents config data else returns False '''
                            return True

                        def _has_data(self):
                            if self.ip_prefix is not None:
                                return True

                            if self.masklength_range is not None:
                                return True

                            if self.config is not None and self.config._has_data():
                                return True

                            if self.state is not None and self.state._has_data():
                                return True

                            return False

                        @staticmethod
                        def _meta_info():
                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                            return meta._meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes.Prefix']['meta_info']

                    @property
                    def _common_path(self):
                        if self.parent is None:
                            raise YPYModelError('parent is not set . Cannot derive path.')

                        return self.parent._common_path +'/openconfig-routing-policy:prefixes'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return True

                    def _has_data(self):
                        if self.prefix is not None:
                            for child_ref in self.prefix:
                                if child_ref._has_data():
                                    return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                        return meta._meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet.Prefixes']['meta_info']

                @property
                def _common_path(self):
                    if self.prefix_set_name is None:
                        raise YPYModelError('Key property prefix_set_name is None')

                    return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:defined-sets/openconfig-routing-policy:prefix-sets/openconfig-routing-policy:prefix-set[openconfig-routing-policy:prefix-set-name = ' + str(self.prefix_set_name) + ']'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.prefix_set_name is not None:
                        return True

                    if self.config is not None and self.config._has_data():
                        return True

                    if self.prefixes is not None and self.prefixes._has_data():
                        return True

                    if self.state is not None and self.state._has_data():
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                    return meta._meta_table['RoutingPolicy.DefinedSets.PrefixSets.PrefixSet']['meta_info']

            @property
            def _common_path(self):

                return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:defined-sets/openconfig-routing-policy:prefix-sets'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.prefix_set is not None:
                    for child_ref in self.prefix_set:
                        if child_ref._has_data():
                            return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                return meta._meta_table['RoutingPolicy.DefinedSets.PrefixSets']['meta_info']


        class NeighborSets(object):
            """
            Enclosing container for the list of neighbor set
            definitions
            
            .. attribute:: neighbor_set
            
            	List of defined neighbor sets for use in policies
            	**type**\: list of    :py:class:`NeighborSet <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.NeighborSets.NeighborSet>`
            
            

            """

            _prefix = 'oc-rpol'
            _revision = '2016-05-12'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.neighbor_set = YList()
                self.neighbor_set.parent = self
                self.neighbor_set.name = 'neighbor_set'


            class NeighborSet(object):
                """
                List of defined neighbor sets for use in policies.
                
                .. attribute:: neighbor_set_name  <key>
                
                	Reference to the neighbor set name list key
                	**type**\:  str
                
                	**refers to**\:  :py:class:`neighbor_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.Config>`
                
                .. attribute:: config
                
                	Configuration data for neighbor sets
                	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.Config>`
                
                .. attribute:: state
                
                	Operational state data for neighbor sets
                	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.State>`
                
                	**config**\: False
                
                

                """

                _prefix = 'oc-rpol'
                _revision = '2016-05-12'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = ['neighbor_set_name']

                    self.neighbor_set_name = None
                    self.config = RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.Config()
                    self.config.parent = self
                    self.state = RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.State()
                    self.state.parent = self


                class Config(object):
                    """
                    Configuration data for neighbor sets.
                    
                    .. attribute:: address
                    
                    	List of IP addresses in the neighbor set
                    	**type**\: one of the below types:
                    
                    	**type**\:  list of str
                    
                    	**pattern:** (([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])(%[\\p{N}\\p{L}]+)?
                    
                    
                    ----
                    	**type**\:  list of str
                    
                    	**pattern:** ((\:\|[0\-9a\-fA\-F]{0,4})\:)([0\-9a\-fA\-F]{0,4}\:){0,5}((([0\-9a\-fA\-F]{0,4}\:)?(\:\|[0\-9a\-fA\-F]{0,4}))\|(((25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])\\.){3}(25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])))(%[\\p{N}\\p{L}]+)?
                    
                    
                    ----
                    .. attribute:: neighbor_set_name
                    
                    	name / label of the neighbor set \-\- this is used to reference the set in match conditions
                    	**type**\:  str
                    
                    

                    """

                    _prefix = 'oc-rpol'
                    _revision = '2016-05-12'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = []

                        self.address = YLeafList()
                        self.address.parent = self
                        self.address.name = 'address'
                        self.neighbor_set_name = None

                    @property
                    def _common_path(self):
                        if self.parent is None:
                            raise YPYModelError('parent is not set . Cannot derive path.')

                        return self.parent._common_path +'/openconfig-routing-policy:config'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return True

                    def _has_data(self):
                        if self.address is not None:
                            for child in self.address:
                                if child is not None:
                                    return True

                        if self.neighbor_set_name is not None:
                            return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                        return meta._meta_table['RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.Config']['meta_info']


                class State(object):
                    """
                    Operational state data for neighbor sets.
                    
                    .. attribute:: address
                    
                    	List of IP addresses in the neighbor set
                    	**type**\: one of the below types:
                    
                    	**type**\:  list of str
                    
                    	**pattern:** (([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])(%[\\p{N}\\p{L}]+)?
                    
                    	**config**\: False
                    
                    
                    ----
                    	**type**\:  list of str
                    
                    	**pattern:** ((\:\|[0\-9a\-fA\-F]{0,4})\:)([0\-9a\-fA\-F]{0,4}\:){0,5}((([0\-9a\-fA\-F]{0,4}\:)?(\:\|[0\-9a\-fA\-F]{0,4}))\|(((25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])\\.){3}(25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])))(%[\\p{N}\\p{L}]+)?
                    
                    	**config**\: False
                    
                    
                    ----
                    .. attribute:: neighbor_set_name
                    
                    	name / label of the neighbor set \-\- this is used to reference the set in match conditions
                    	**type**\:  str
                    
                    	**config**\: False
                    
                    

                    """

                    _prefix = 'oc-rpol'
                    _revision = '2016-05-12'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = []

                        self.address = YLeafList()
                        self.address.parent = self
                        self.address.name = 'address'
                        self.neighbor_set_name = None

                    @property
                    def _common_path(self):
                        if self.parent is None:
                            raise YPYModelError('parent is not set . Cannot derive path.')

                        return self.parent._common_path +'/openconfig-routing-policy:state'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return False

                    def _has_data(self):
                        if self.address is not None:
                            for child in self.address:
                                if child is not None:
                                    return True

                        if self.neighbor_set_name is not None:
                            return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                        return meta._meta_table['RoutingPolicy.DefinedSets.NeighborSets.NeighborSet.State']['meta_info']

                @property
                def _common_path(self):
                    if self.neighbor_set_name is None:
                        raise YPYModelError('Key property neighbor_set_name is None')

                    return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:defined-sets/openconfig-routing-policy:neighbor-sets/openconfig-routing-policy:neighbor-set[openconfig-routing-policy:neighbor-set-name = ' + str(self.neighbor_set_name) + ']'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.neighbor_set_name is not None:
                        return True

                    if self.config is not None and self.config._has_data():
                        return True

                    if self.state is not None and self.state._has_data():
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                    return meta._meta_table['RoutingPolicy.DefinedSets.NeighborSets.NeighborSet']['meta_info']

            @property
            def _common_path(self):

                return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:defined-sets/openconfig-routing-policy:neighbor-sets'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.neighbor_set is not None:
                    for child_ref in self.neighbor_set:
                        if child_ref._has_data():
                            return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                return meta._meta_table['RoutingPolicy.DefinedSets.NeighborSets']['meta_info']


        class TagSets(object):
            """
            Enclosing container for the list of tag sets.
            
            .. attribute:: tag_set
            
            	List of tag set definitions
            	**type**\: list of    :py:class:`TagSet <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.TagSets.TagSet>`
            
            

            """

            _prefix = 'oc-rpol'
            _revision = '2016-05-12'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.tag_set = YList()
                self.tag_set.parent = self
                self.tag_set.name = 'tag_set'


            class TagSet(object):
                """
                List of tag set definitions.
                
                .. attribute:: tag_set_name  <key>
                
                	Reference to the tag set name list key
                	**type**\:  str
                
                	**refers to**\:  :py:class:`tag_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.TagSets.TagSet.Config>`
                
                .. attribute:: config
                
                	Configuration data for tag sets
                	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.TagSets.TagSet.Config>`
                
                .. attribute:: state
                
                	Operational state data for tag sets
                	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.TagSets.TagSet.State>`
                
                	**config**\: False
                
                

                """

                _prefix = 'oc-rpol'
                _revision = '2016-05-12'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = ['tag_set_name']

                    self.tag_set_name = None
                    self.config = RoutingPolicy.DefinedSets.TagSets.TagSet.Config()
                    self.config.parent = self
                    self.state = RoutingPolicy.DefinedSets.TagSets.TagSet.State()
                    self.state.parent = self


                class Config(object):
                    """
                    Configuration data for tag sets
                    
                    .. attribute:: tag_set_name
                    
                    	name / label of the tag set \-\- this is used to reference the set in match conditions
                    	**type**\:  str
                    
                    .. attribute:: tag_value
                    
                    	Value of the tag set member
                    	**type**\: one of the below types:
                    
                    	**type**\:  list of int
                    
                    	**range:** 0..4294967295
                    
                    
                    ----
                    	**type**\:  list of str
                    
                    	**pattern:** ([0\-9a\-fA\-F]{2}(\:[0\-9a\-fA\-F]{2})\*)?
                    
                    
                    ----
                    

                    """

                    _prefix = 'oc-rpol'
                    _revision = '2016-05-12'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = []

                        self.tag_set_name = None
                        self.tag_value = YLeafList()
                        self.tag_value.parent = self
                        self.tag_value.name = 'tag_value'

                    @property
                    def _common_path(self):
                        if self.parent is None:
                            raise YPYModelError('parent is not set . Cannot derive path.')

                        return self.parent._common_path +'/openconfig-routing-policy:config'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return True

                    def _has_data(self):
                        if self.tag_set_name is not None:
                            return True

                        if self.tag_value is not None:
                            for child in self.tag_value:
                                if child is not None:
                                    return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                        return meta._meta_table['RoutingPolicy.DefinedSets.TagSets.TagSet.Config']['meta_info']


                class State(object):
                    """
                    Operational state data for tag sets
                    
                    .. attribute:: tag_set_name
                    
                    	name / label of the tag set \-\- this is used to reference the set in match conditions
                    	**type**\:  str
                    
                    	**config**\: False
                    
                    .. attribute:: tag_value
                    
                    	Value of the tag set member
                    	**type**\: one of the below types:
                    
                    	**type**\:  list of int
                    
                    	**range:** 0..4294967295
                    
                    	**config**\: False
                    
                    
                    ----
                    	**type**\:  list of str
                    
                    	**pattern:** ([0\-9a\-fA\-F]{2}(\:[0\-9a\-fA\-F]{2})\*)?
                    
                    	**config**\: False
                    
                    
                    ----
                    

                    """

                    _prefix = 'oc-rpol'
                    _revision = '2016-05-12'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = []

                        self.tag_set_name = None
                        self.tag_value = YLeafList()
                        self.tag_value.parent = self
                        self.tag_value.name = 'tag_value'

                    @property
                    def _common_path(self):
                        if self.parent is None:
                            raise YPYModelError('parent is not set . Cannot derive path.')

                        return self.parent._common_path +'/openconfig-routing-policy:state'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return False

                    def _has_data(self):
                        if self.tag_set_name is not None:
                            return True

                        if self.tag_value is not None:
                            for child in self.tag_value:
                                if child is not None:
                                    return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                        return meta._meta_table['RoutingPolicy.DefinedSets.TagSets.TagSet.State']['meta_info']

                @property
                def _common_path(self):
                    if self.tag_set_name is None:
                        raise YPYModelError('Key property tag_set_name is None')

                    return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:defined-sets/openconfig-routing-policy:tag-sets/openconfig-routing-policy:tag-set[openconfig-routing-policy:tag-set-name = ' + str(self.tag_set_name) + ']'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.tag_set_name is not None:
                        return True

                    if self.config is not None and self.config._has_data():
                        return True

                    if self.state is not None and self.state._has_data():
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                    return meta._meta_table['RoutingPolicy.DefinedSets.TagSets.TagSet']['meta_info']

            @property
            def _common_path(self):

                return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:defined-sets/openconfig-routing-policy:tag-sets'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.tag_set is not None:
                    for child_ref in self.tag_set:
                        if child_ref._has_data():
                            return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                return meta._meta_table['RoutingPolicy.DefinedSets.TagSets']['meta_info']


        class BgpDefinedSets(object):
            """
            BGP\-related set definitions for policy match conditions
            
            .. attribute:: as_path_sets
            
            	Enclosing container for list of define AS path sets
            	**type**\:   :py:class:`AsPathSets <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets>`
            
            .. attribute:: community_sets
            
            	Enclosing container for list of defined BGP community sets
            	**type**\:   :py:class:`CommunitySets <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets>`
            
            .. attribute:: ext_community_sets
            
            	Enclosing container for list of extended BGP community sets
            	**type**\:   :py:class:`ExtCommunitySets <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets>`
            
            

            """

            _prefix = 'oc-bgp-pol'
            _revision = '2016-06-21'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = []

                self.as_path_sets = RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets()
                self.as_path_sets.parent = self
                self.community_sets = RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets()
                self.community_sets.parent = self
                self.ext_community_sets = RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets()
                self.ext_community_sets.parent = self


            class CommunitySets(object):
                """
                Enclosing container for list of defined BGP community sets
                
                .. attribute:: community_set
                
                	List of defined BGP community sets
                	**type**\: list of    :py:class:`CommunitySet <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet>`
                
                

                """

                _prefix = 'oc-bgp-pol'
                _revision = '2016-06-21'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = []

                    self.community_set = YList()
                    self.community_set.parent = self
                    self.community_set.name = 'community_set'


                class CommunitySet(object):
                    """
                    List of defined BGP community sets
                    
                    .. attribute:: community_set_name  <key>
                    
                    	Reference to list key
                    	**type**\:  str
                    
                    	**refers to**\:  :py:class:`community_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.Config>`
                    
                    .. attribute:: config
                    
                    	Configuration data for BGP community sets
                    	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.Config>`
                    
                    .. attribute:: state
                    
                    	Operational state data for BGP community sets
                    	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.State>`
                    
                    	**config**\: False
                    
                    

                    """

                    _prefix = 'oc-bgp-pol'
                    _revision = '2016-06-21'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = ['community_set_name']

                        self.community_set_name = None
                        self.config = RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.Config()
                        self.config.parent = self
                        self.state = RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.State()
                        self.state.parent = self


                    class Config(object):
                        """
                        Configuration data for BGP community sets
                        
                        .. attribute:: community_member
                        
                        	members of the community set
                        	**type**\: one of the below types:
                        
                        	**type**\:  list of int
                        
                        	**range:** 65536..4294901759
                        
                        
                        ----
                        	**type**\:  list of str
                        
                        	**pattern:** ([0\-9]+\:[0\-9]+)
                        
                        
                        ----
                        
                        ----
                        	**type**\:  list of str
                        
                        
                        ----
                        	**type**\:  
                        		list of   :py:class:`Bgp_Well_Known_Std_CommunityIdentity <ydk.models.ydktest.openconfig_bgp_types.Bgp_Well_Known_Std_CommunityIdentity>`
                        
                        
                        ----
                        .. attribute:: community_set_name
                        
                        	name / label of the community set \-\- this is used to reference the set in match conditions
                        	**type**\:  str
                        
                        

                        """

                        _prefix = 'oc-bgp-pol'
                        _revision = '2016-06-21'

                        def __init__(self):
                            self.parent = None
                            self.ylist_key_names = []

                            self.community_member = YLeafList()
                            self.community_member.parent = self
                            self.community_member.name = 'community_member'
                            self.community_set_name = None

                        @property
                        def _common_path(self):
                            if self.parent is None:
                                raise YPYModelError('parent is not set . Cannot derive path.')

                            return self.parent._common_path +'/openconfig-bgp-policy:config'

                        def is_config(self):
                            ''' Returns True if this instance represents config data else returns False '''
                            return True

                        def _has_data(self):
                            if self.community_member is not None:
                                for child in self.community_member:
                                    if child is not None:
                                        return True

                            if self.community_set_name is not None:
                                return True

                            return False

                        @staticmethod
                        def _meta_info():
                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                            return meta._meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.Config']['meta_info']


                    class State(object):
                        """
                        Operational state data for BGP community sets
                        
                        .. attribute:: community_member
                        
                        	members of the community set
                        	**type**\: one of the below types:
                        
                        	**type**\:  list of int
                        
                        	**range:** 65536..4294901759
                        
                        	**config**\: False
                        
                        
                        ----
                        	**type**\:  list of str
                        
                        	**pattern:** ([0\-9]+\:[0\-9]+)
                        
                        	**config**\: False
                        
                        
                        ----
                        
                        ----
                        	**type**\:  list of str
                        
                        	**config**\: False
                        
                        
                        ----
                        	**type**\:  
                        		list of   :py:class:`Bgp_Well_Known_Std_CommunityIdentity <ydk.models.ydktest.openconfig_bgp_types.Bgp_Well_Known_Std_CommunityIdentity>`
                        
                        	**config**\: False
                        
                        
                        ----
                        .. attribute:: community_set_name
                        
                        	name / label of the community set \-\- this is used to reference the set in match conditions
                        	**type**\:  str
                        
                        	**config**\: False
                        
                        

                        """

                        _prefix = 'oc-bgp-pol'
                        _revision = '2016-06-21'

                        def __init__(self):
                            self.parent = None
                            self.ylist_key_names = []

                            self.community_member = YLeafList()
                            self.community_member.parent = self
                            self.community_member.name = 'community_member'
                            self.community_set_name = None

                        @property
                        def _common_path(self):
                            if self.parent is None:
                                raise YPYModelError('parent is not set . Cannot derive path.')

                            return self.parent._common_path +'/openconfig-bgp-policy:state'

                        def is_config(self):
                            ''' Returns True if this instance represents config data else returns False '''
                            return False

                        def _has_data(self):
                            if self.community_member is not None:
                                for child in self.community_member:
                                    if child is not None:
                                        return True

                            if self.community_set_name is not None:
                                return True

                            return False

                        @staticmethod
                        def _meta_info():
                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                            return meta._meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet.State']['meta_info']

                    @property
                    def _common_path(self):
                        if self.community_set_name is None:
                            raise YPYModelError('Key property community_set_name is None')

                        return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:defined-sets/openconfig-bgp-policy:bgp-defined-sets/openconfig-bgp-policy:community-sets/openconfig-bgp-policy:community-set[openconfig-bgp-policy:community-set-name = ' + str(self.community_set_name) + ']'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return True

                    def _has_data(self):
                        if self.community_set_name is not None:
                            return True

                        if self.config is not None and self.config._has_data():
                            return True

                        if self.state is not None and self.state._has_data():
                            return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                        return meta._meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet']['meta_info']

                @property
                def _common_path(self):

                    return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:defined-sets/openconfig-bgp-policy:bgp-defined-sets/openconfig-bgp-policy:community-sets'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.community_set is not None:
                        for child_ref in self.community_set:
                            if child_ref._has_data():
                                return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                    return meta._meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets']['meta_info']


            class ExtCommunitySets(object):
                """
                Enclosing container for list of extended BGP community
                sets
                
                .. attribute:: ext_community_set
                
                	List of defined extended BGP community sets
                	**type**\: list of    :py:class:`ExtCommunitySet <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet>`
                
                

                """

                _prefix = 'oc-bgp-pol'
                _revision = '2016-06-21'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = []

                    self.ext_community_set = YList()
                    self.ext_community_set.parent = self
                    self.ext_community_set.name = 'ext_community_set'


                class ExtCommunitySet(object):
                    """
                    List of defined extended BGP community sets
                    
                    .. attribute:: ext_community_set_name  <key>
                    
                    	Reference to list key
                    	**type**\:  str
                    
                    	**refers to**\:  :py:class:`ext_community_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.Config>`
                    
                    .. attribute:: config
                    
                    	Configuration data for extended BGP community sets
                    	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.Config>`
                    
                    .. attribute:: state
                    
                    	Operational state data for extended BGP community sets
                    	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.State>`
                    
                    	**config**\: False
                    
                    

                    """

                    _prefix = 'oc-bgp-pol'
                    _revision = '2016-06-21'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = ['ext_community_set_name']

                        self.ext_community_set_name = None
                        self.config = RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.Config()
                        self.config.parent = self
                        self.state = RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.State()
                        self.state.parent = self


                    class Config(object):
                        """
                        Configuration data for extended BGP community sets
                        
                        .. attribute:: ext_community_member
                        
                        	members of the extended community set
                        	**type**\: one of the below types:
                        
                        	**type**\:  list of str
                        
                        	**pattern:** (6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])\:(4[0\-2][0\-9][0\-4][0\-9][0\-6][0\-7][0\-2][0\-9][0\-6]\|[1\-3][0\-9]{9}\|[1\-9]([0\-9]{1,7})?[0\-9]\|[1\-9])
                        
                        
                        ----
                        	**type**\:  list of str
                        
                        	**pattern:** (([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])
                        
                        
                        ----
                        	**type**\:  list of str
                        
                        	**pattern:** route\\\-target\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])\:(4[0\-2][0\-9][0\-4][0\-9][0\-6][0\-7][0\-2][0\-9][0\-6]\|[1\-3][0\-9]{9}\|[1\-9]([0\-9]{1,7})?[0\-9]\|[1\-9])
                        
                        
                        ----
                        	**type**\:  list of str
                        
                        	**pattern:** route\\\-target\:(([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])
                        
                        
                        ----
                        	**type**\:  list of str
                        
                        	**pattern:** route\\\-origin\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])\:(4[0\-2][0\-9][0\-4][0\-9][0\-6][0\-7][0\-2][0\-9][0\-6]\|[1\-3][0\-9]{9}\|[1\-9]([0\-9]{1,7})?[0\-9]\|[1\-9])
                        
                        
                        ----
                        	**type**\:  list of str
                        
                        	**pattern:** route\\\-origin\:(([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])
                        
                        
                        ----
                        
                        ----
                        	**type**\:  list of str
                        
                        
                        ----
                        .. attribute:: ext_community_set_name
                        
                        	name / label of the extended community set \-\- this is used to reference the set in match conditions
                        	**type**\:  str
                        
                        

                        """

                        _prefix = 'oc-bgp-pol'
                        _revision = '2016-06-21'

                        def __init__(self):
                            self.parent = None
                            self.ylist_key_names = []

                            self.ext_community_member = YLeafList()
                            self.ext_community_member.parent = self
                            self.ext_community_member.name = 'ext_community_member'
                            self.ext_community_set_name = None

                        @property
                        def _common_path(self):
                            if self.parent is None:
                                raise YPYModelError('parent is not set . Cannot derive path.')

                            return self.parent._common_path +'/openconfig-bgp-policy:config'

                        def is_config(self):
                            ''' Returns True if this instance represents config data else returns False '''
                            return True

                        def _has_data(self):
                            if self.ext_community_member is not None:
                                for child in self.ext_community_member:
                                    if child is not None:
                                        return True

                            if self.ext_community_set_name is not None:
                                return True

                            return False

                        @staticmethod
                        def _meta_info():
                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                            return meta._meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.Config']['meta_info']


                    class State(object):
                        """
                        Operational state data for extended BGP community sets
                        
                        .. attribute:: ext_community_member
                        
                        	members of the extended community set
                        	**type**\: one of the below types:
                        
                        	**type**\:  list of str
                        
                        	**pattern:** (6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])\:(4[0\-2][0\-9][0\-4][0\-9][0\-6][0\-7][0\-2][0\-9][0\-6]\|[1\-3][0\-9]{9}\|[1\-9]([0\-9]{1,7})?[0\-9]\|[1\-9])
                        
                        	**config**\: False
                        
                        
                        ----
                        	**type**\:  list of str
                        
                        	**pattern:** (([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])
                        
                        	**config**\: False
                        
                        
                        ----
                        	**type**\:  list of str
                        
                        	**pattern:** route\\\-target\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])\:(4[0\-2][0\-9][0\-4][0\-9][0\-6][0\-7][0\-2][0\-9][0\-6]\|[1\-3][0\-9]{9}\|[1\-9]([0\-9]{1,7})?[0\-9]\|[1\-9])
                        
                        	**config**\: False
                        
                        
                        ----
                        	**type**\:  list of str
                        
                        	**pattern:** route\\\-target\:(([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])
                        
                        	**config**\: False
                        
                        
                        ----
                        	**type**\:  list of str
                        
                        	**pattern:** route\\\-origin\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])\:(4[0\-2][0\-9][0\-4][0\-9][0\-6][0\-7][0\-2][0\-9][0\-6]\|[1\-3][0\-9]{9}\|[1\-9]([0\-9]{1,7})?[0\-9]\|[1\-9])
                        
                        	**config**\: False
                        
                        
                        ----
                        	**type**\:  list of str
                        
                        	**pattern:** route\\\-origin\:(([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])
                        
                        	**config**\: False
                        
                        
                        ----
                        
                        ----
                        	**type**\:  list of str
                        
                        	**config**\: False
                        
                        
                        ----
                        .. attribute:: ext_community_set_name
                        
                        	name / label of the extended community set \-\- this is used to reference the set in match conditions
                        	**type**\:  str
                        
                        	**config**\: False
                        
                        

                        """

                        _prefix = 'oc-bgp-pol'
                        _revision = '2016-06-21'

                        def __init__(self):
                            self.parent = None
                            self.ylist_key_names = []

                            self.ext_community_member = YLeafList()
                            self.ext_community_member.parent = self
                            self.ext_community_member.name = 'ext_community_member'
                            self.ext_community_set_name = None

                        @property
                        def _common_path(self):
                            if self.parent is None:
                                raise YPYModelError('parent is not set . Cannot derive path.')

                            return self.parent._common_path +'/openconfig-bgp-policy:state'

                        def is_config(self):
                            ''' Returns True if this instance represents config data else returns False '''
                            return False

                        def _has_data(self):
                            if self.ext_community_member is not None:
                                for child in self.ext_community_member:
                                    if child is not None:
                                        return True

                            if self.ext_community_set_name is not None:
                                return True

                            return False

                        @staticmethod
                        def _meta_info():
                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                            return meta._meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet.State']['meta_info']

                    @property
                    def _common_path(self):
                        if self.ext_community_set_name is None:
                            raise YPYModelError('Key property ext_community_set_name is None')

                        return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:defined-sets/openconfig-bgp-policy:bgp-defined-sets/openconfig-bgp-policy:ext-community-sets/openconfig-bgp-policy:ext-community-set[openconfig-bgp-policy:ext-community-set-name = ' + str(self.ext_community_set_name) + ']'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return True

                    def _has_data(self):
                        if self.ext_community_set_name is not None:
                            return True

                        if self.config is not None and self.config._has_data():
                            return True

                        if self.state is not None and self.state._has_data():
                            return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                        return meta._meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet']['meta_info']

                @property
                def _common_path(self):

                    return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:defined-sets/openconfig-bgp-policy:bgp-defined-sets/openconfig-bgp-policy:ext-community-sets'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.ext_community_set is not None:
                        for child_ref in self.ext_community_set:
                            if child_ref._has_data():
                                return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                    return meta._meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets']['meta_info']


            class AsPathSets(object):
                """
                Enclosing container for list of define AS path sets
                
                .. attribute:: as_path_set
                
                	List of defined AS path sets
                	**type**\: list of    :py:class:`AsPathSet <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet>`
                
                

                """

                _prefix = 'oc-bgp-pol'
                _revision = '2016-06-21'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = []

                    self.as_path_set = YList()
                    self.as_path_set.parent = self
                    self.as_path_set.name = 'as_path_set'


                class AsPathSet(object):
                    """
                    List of defined AS path sets
                    
                    .. attribute:: as_path_set_name  <key>
                    
                    	Reference to list key
                    	**type**\:  str
                    
                    	**refers to**\:  :py:class:`as_path_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.Config>`
                    
                    .. attribute:: config
                    
                    	Configuration data for AS path sets
                    	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.Config>`
                    
                    .. attribute:: state
                    
                    	Operational state data for AS path sets
                    	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.State>`
                    
                    	**config**\: False
                    
                    

                    """

                    _prefix = 'oc-bgp-pol'
                    _revision = '2016-06-21'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = ['as_path_set_name']

                        self.as_path_set_name = None
                        self.config = RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.Config()
                        self.config.parent = self
                        self.state = RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.State()
                        self.state.parent = self


                    class Config(object):
                        """
                        Configuration data for AS path sets
                        
                        .. attribute:: as_path_set_member
                        
                        	AS path expression \-\- list of ASes in the set
                        	**type**\:  list of str
                        
                        .. attribute:: as_path_set_name
                        
                        	name of the AS path set \-\- this is used to reference the set in match conditions
                        	**type**\:  str
                        
                        

                        """

                        _prefix = 'oc-bgp-pol'
                        _revision = '2016-06-21'

                        def __init__(self):
                            self.parent = None
                            self.ylist_key_names = []

                            self.as_path_set_member = YLeafList()
                            self.as_path_set_member.parent = self
                            self.as_path_set_member.name = 'as_path_set_member'
                            self.as_path_set_name = None

                        @property
                        def _common_path(self):
                            if self.parent is None:
                                raise YPYModelError('parent is not set . Cannot derive path.')

                            return self.parent._common_path +'/openconfig-bgp-policy:config'

                        def is_config(self):
                            ''' Returns True if this instance represents config data else returns False '''
                            return True

                        def _has_data(self):
                            if self.as_path_set_member is not None:
                                for child in self.as_path_set_member:
                                    if child is not None:
                                        return True

                            if self.as_path_set_name is not None:
                                return True

                            return False

                        @staticmethod
                        def _meta_info():
                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                            return meta._meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.Config']['meta_info']


                    class State(object):
                        """
                        Operational state data for AS path sets
                        
                        .. attribute:: as_path_set_member
                        
                        	AS path expression \-\- list of ASes in the set
                        	**type**\:  list of str
                        
                        	**config**\: False
                        
                        .. attribute:: as_path_set_name
                        
                        	name of the AS path set \-\- this is used to reference the set in match conditions
                        	**type**\:  str
                        
                        	**config**\: False
                        
                        

                        """

                        _prefix = 'oc-bgp-pol'
                        _revision = '2016-06-21'

                        def __init__(self):
                            self.parent = None
                            self.ylist_key_names = []

                            self.as_path_set_member = YLeafList()
                            self.as_path_set_member.parent = self
                            self.as_path_set_member.name = 'as_path_set_member'
                            self.as_path_set_name = None

                        @property
                        def _common_path(self):
                            if self.parent is None:
                                raise YPYModelError('parent is not set . Cannot derive path.')

                            return self.parent._common_path +'/openconfig-bgp-policy:state'

                        def is_config(self):
                            ''' Returns True if this instance represents config data else returns False '''
                            return False

                        def _has_data(self):
                            if self.as_path_set_member is not None:
                                for child in self.as_path_set_member:
                                    if child is not None:
                                        return True

                            if self.as_path_set_name is not None:
                                return True

                            return False

                        @staticmethod
                        def _meta_info():
                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                            return meta._meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet.State']['meta_info']

                    @property
                    def _common_path(self):
                        if self.as_path_set_name is None:
                            raise YPYModelError('Key property as_path_set_name is None')

                        return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:defined-sets/openconfig-bgp-policy:bgp-defined-sets/openconfig-bgp-policy:as-path-sets/openconfig-bgp-policy:as-path-set[openconfig-bgp-policy:as-path-set-name = ' + str(self.as_path_set_name) + ']'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return True

                    def _has_data(self):
                        if self.as_path_set_name is not None:
                            return True

                        if self.config is not None and self.config._has_data():
                            return True

                        if self.state is not None and self.state._has_data():
                            return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                        return meta._meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet']['meta_info']

                @property
                def _common_path(self):

                    return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:defined-sets/openconfig-bgp-policy:bgp-defined-sets/openconfig-bgp-policy:as-path-sets'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.as_path_set is not None:
                        for child_ref in self.as_path_set:
                            if child_ref._has_data():
                                return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                    return meta._meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets']['meta_info']

            @property
            def _common_path(self):

                return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:defined-sets/openconfig-bgp-policy:bgp-defined-sets'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.as_path_sets is not None and self.as_path_sets._has_data():
                    return True

                if self.community_sets is not None and self.community_sets._has_data():
                    return True

                if self.ext_community_sets is not None and self.ext_community_sets._has_data():
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                return meta._meta_table['RoutingPolicy.DefinedSets.BgpDefinedSets']['meta_info']

        @property
        def _common_path(self):

            return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:defined-sets'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.bgp_defined_sets is not None and self.bgp_defined_sets._has_data():
                return True

            if self.neighbor_sets is not None and self.neighbor_sets._has_data():
                return True

            if self.prefix_sets is not None and self.prefix_sets._has_data():
                return True

            if self.tag_sets is not None and self.tag_sets._has_data():
                return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
            return meta._meta_table['RoutingPolicy.DefinedSets']['meta_info']


    class PolicyDefinitions(object):
        """
        Enclosing container for the list of top\-level policy
         definitions
        
        .. attribute:: policy_definition
        
        	List of top\-level policy definitions, keyed by unique name.  These policy definitions are expected to be referenced (by name) in policy chains specified in import or export configuration statements
        	**type**\: list of    :py:class:`PolicyDefinition <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition>`
        
        

        """

        _prefix = 'oc-rpol'
        _revision = '2016-05-12'

        def __init__(self):
            self.parent = None
            self.ylist_key_names = []

            self.policy_definition = YList()
            self.policy_definition.parent = self
            self.policy_definition.name = 'policy_definition'


        class PolicyDefinition(object):
            """
            List of top\-level policy definitions, keyed by unique
            name.  These policy definitions are expected to be
            referenced (by name) in policy chains specified in import
            or export configuration statements.
            
            .. attribute:: name  <key>
            
            	Reference to the list key
            	**type**\:  str
            
            	**refers to**\:  :py:class:`name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Config>`
            
            .. attribute:: config
            
            	Configuration data for policy defintions
            	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Config>`
            
            .. attribute:: state
            
            	Operational state data for policy definitions
            	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.State>`
            
            	**config**\: False
            
            .. attribute:: statements
            
            	Enclosing container for policy statements
            	**type**\:   :py:class:`Statements <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements>`
            
            

            """

            _prefix = 'oc-rpol'
            _revision = '2016-05-12'

            def __init__(self):
                self.parent = None
                self.ylist_key_names = ['name']

                self.name = None
                self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Config()
                self.config.parent = self
                self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.State()
                self.state.parent = self
                self.statements = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements()
                self.statements.parent = self


            class Config(object):
                """
                Configuration data for policy defintions
                
                .. attribute:: name
                
                	Name of the top\-level policy definition \-\- this name is used in references to the current policy
                	**type**\:  str
                
                

                """

                _prefix = 'oc-rpol'
                _revision = '2016-05-12'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = []

                    self.name = None

                @property
                def _common_path(self):
                    if self.parent is None:
                        raise YPYModelError('parent is not set . Cannot derive path.')

                    return self.parent._common_path +'/openconfig-routing-policy:config'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.name is not None:
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Config']['meta_info']


            class State(object):
                """
                Operational state data for policy definitions
                
                .. attribute:: name
                
                	Name of the top\-level policy definition \-\- this name is used in references to the current policy
                	**type**\:  str
                
                	**config**\: False
                
                

                """

                _prefix = 'oc-rpol'
                _revision = '2016-05-12'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = []

                    self.name = None

                @property
                def _common_path(self):
                    if self.parent is None:
                        raise YPYModelError('parent is not set . Cannot derive path.')

                    return self.parent._common_path +'/openconfig-routing-policy:state'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return False

                def _has_data(self):
                    if self.name is not None:
                        return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.State']['meta_info']


            class Statements(object):
                """
                Enclosing container for policy statements
                
                .. attribute:: statement
                
                	Policy statements group conditions and actions within a policy definition.  They are evaluated in the order specified (see the description of policy evaluation at the top of this module
                	**type**\: list of    :py:class:`Statement <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement>`
                
                

                """

                _prefix = 'oc-rpol'
                _revision = '2016-05-12'

                def __init__(self):
                    self.parent = None
                    self.ylist_key_names = []

                    self.statement = YList()
                    self.statement.parent = self
                    self.statement.name = 'statement'


                class Statement(object):
                    """
                    Policy statements group conditions and actions
                    within a policy definition.  They are evaluated in
                    the order specified (see the description of policy
                    evaluation at the top of this module.
                    
                    .. attribute:: name  <key>
                    
                    	Reference to list key
                    	**type**\:  str
                    
                    	**refers to**\:  :py:class:`name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Config>`
                    
                    .. attribute:: actions
                    
                    	Top\-level container for policy action statements
                    	**type**\:   :py:class:`Actions <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions>`
                    
                    .. attribute:: conditions
                    
                    	Condition statements for the current policy statement
                    	**type**\:   :py:class:`Conditions <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions>`
                    
                    .. attribute:: config
                    
                    	Configuration data for policy statements
                    	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Config>`
                    
                    .. attribute:: state
                    
                    	Operational state data for policy statements
                    	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.State>`
                    
                    	**config**\: False
                    
                    

                    """

                    _prefix = 'oc-rpol'
                    _revision = '2016-05-12'

                    def __init__(self):
                        self.parent = None
                        self.ylist_key_names = ['name']

                        self.name = None
                        self.actions = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions()
                        self.actions.parent = self
                        self.conditions = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions()
                        self.conditions.parent = self
                        self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Config()
                        self.config.parent = self
                        self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.State()
                        self.state.parent = self


                    class Config(object):
                        """
                        Configuration data for policy statements
                        
                        .. attribute:: name
                        
                        	name of the policy statement
                        	**type**\:  str
                        
                        

                        """

                        _prefix = 'oc-rpol'
                        _revision = '2016-05-12'

                        def __init__(self):
                            self.parent = None
                            self.ylist_key_names = []

                            self.name = None

                        @property
                        def _common_path(self):
                            if self.parent is None:
                                raise YPYModelError('parent is not set . Cannot derive path.')

                            return self.parent._common_path +'/openconfig-routing-policy:config'

                        def is_config(self):
                            ''' Returns True if this instance represents config data else returns False '''
                            return True

                        def _has_data(self):
                            if self.name is not None:
                                return True

                            return False

                        @staticmethod
                        def _meta_info():
                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Config']['meta_info']


                    class State(object):
                        """
                        Operational state data for policy statements
                        
                        .. attribute:: name
                        
                        	name of the policy statement
                        	**type**\:  str
                        
                        	**config**\: False
                        
                        

                        """

                        _prefix = 'oc-rpol'
                        _revision = '2016-05-12'

                        def __init__(self):
                            self.parent = None
                            self.ylist_key_names = []

                            self.name = None

                        @property
                        def _common_path(self):
                            if self.parent is None:
                                raise YPYModelError('parent is not set . Cannot derive path.')

                            return self.parent._common_path +'/openconfig-routing-policy:state'

                        def is_config(self):
                            ''' Returns True if this instance represents config data else returns False '''
                            return False

                        def _has_data(self):
                            if self.name is not None:
                                return True

                            return False

                        @staticmethod
                        def _meta_info():
                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.State']['meta_info']


                    class Conditions(object):
                        """
                        Condition statements for the current policy statement
                        
                        .. attribute:: bgp_conditions
                        
                        	Top\-level container 
                        	**type**\:   :py:class:`BgpConditions <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions>`
                        
                        .. attribute:: config
                        
                        	Configuration data for policy conditions
                        	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.Config>`
                        
                        .. attribute:: igp_conditions
                        
                        	Policy conditions for IGP attributes
                        	**type**\:   :py:class:`IgpConditions <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.IgpConditions>`
                        
                        .. attribute:: match_interface
                        
                        	Top\-level container for interface match conditions
                        	**type**\:   :py:class:`MatchInterface <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface>`
                        
                        .. attribute:: match_neighbor_set
                        
                        	Match a referenced neighbor set according to the logic defined in the match\-set\-options\-leaf
                        	**type**\:   :py:class:`MatchNeighborSet <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet>`
                        
                        .. attribute:: match_prefix_set
                        
                        	Match a referenced prefix\-set according to the logic defined in the match\-set\-options leaf
                        	**type**\:   :py:class:`MatchPrefixSet <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet>`
                        
                        .. attribute:: match_tag_set
                        
                        	Match a referenced tag set according to the logic defined in the match\-options\-set leaf
                        	**type**\:   :py:class:`MatchTagSet <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet>`
                        
                        .. attribute:: state
                        
                        	Operational state data for policy conditions
                        	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.State>`
                        
                        	**config**\: False
                        
                        

                        """

                        _prefix = 'oc-rpol'
                        _revision = '2016-05-12'

                        def __init__(self):
                            self.parent = None
                            self.ylist_key_names = []

                            self.bgp_conditions = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions()
                            self.bgp_conditions.parent = self
                            self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.Config()
                            self.config.parent = self
                            self.igp_conditions = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.IgpConditions()
                            self.igp_conditions.parent = self
                            self.match_interface = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface()
                            self.match_interface.parent = self
                            self.match_neighbor_set = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet()
                            self.match_neighbor_set.parent = self
                            self.match_prefix_set = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet()
                            self.match_prefix_set.parent = self
                            self.match_tag_set = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet()
                            self.match_tag_set.parent = self
                            self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.State()
                            self.state.parent = self


                        class Config(object):
                            """
                            Configuration data for policy conditions
                            
                            .. attribute:: call_policy
                            
                            	Applies the statements from the specified policy definition and then returns control the current policy statement. Note that the called policy may itself call other policies (subject to implementation limitations). This is intended to provide a policy 'subroutine' capability.  The called policy should contain an explicit or a default route disposition that returns an effective true (accept\-route) or false (reject\-route), otherwise the behavior may be ambiguous and implementation dependent
                            	**type**\:  str
                            
                            	**refers to**\:  :py:class:`name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition>`
                            
                            .. attribute:: install_protocol_eq
                            
                            	Condition to check the protocol / method used to install the route into the local routing table
                            	**type**\:   :py:class:`Install_Protocol_TypeIdentity <ydk.models.ydktest.openconfig_policy_types.Install_Protocol_TypeIdentity>`
                            
                            

                            """

                            _prefix = 'oc-rpol'
                            _revision = '2016-05-12'

                            def __init__(self):
                                self.parent = None
                                self.ylist_key_names = []

                                self.call_policy = None
                                self.install_protocol_eq = None

                            @property
                            def _common_path(self):
                                if self.parent is None:
                                    raise YPYModelError('parent is not set . Cannot derive path.')

                                return self.parent._common_path +'/openconfig-routing-policy:config'

                            def is_config(self):
                                ''' Returns True if this instance represents config data else returns False '''
                                return True

                            def _has_data(self):
                                if self.call_policy is not None:
                                    return True

                                if self.install_protocol_eq is not None:
                                    return True

                                return False

                            @staticmethod
                            def _meta_info():
                                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.Config']['meta_info']


                        class State(object):
                            """
                            Operational state data for policy conditions
                            
                            .. attribute:: call_policy
                            
                            	Applies the statements from the specified policy definition and then returns control the current policy statement. Note that the called policy may itself call other policies (subject to implementation limitations). This is intended to provide a policy 'subroutine' capability.  The called policy should contain an explicit or a default route disposition that returns an effective true (accept\-route) or false (reject\-route), otherwise the behavior may be ambiguous and implementation dependent
                            	**type**\:  str
                            
                            	**refers to**\:  :py:class:`name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition>`
                            
                            	**config**\: False
                            
                            .. attribute:: install_protocol_eq
                            
                            	Condition to check the protocol / method used to install the route into the local routing table
                            	**type**\:   :py:class:`Install_Protocol_TypeIdentity <ydk.models.ydktest.openconfig_policy_types.Install_Protocol_TypeIdentity>`
                            
                            	**config**\: False
                            
                            

                            """

                            _prefix = 'oc-rpol'
                            _revision = '2016-05-12'

                            def __init__(self):
                                self.parent = None
                                self.ylist_key_names = []

                                self.call_policy = None
                                self.install_protocol_eq = None

                            @property
                            def _common_path(self):
                                if self.parent is None:
                                    raise YPYModelError('parent is not set . Cannot derive path.')

                                return self.parent._common_path +'/openconfig-routing-policy:state'

                            def is_config(self):
                                ''' Returns True if this instance represents config data else returns False '''
                                return False

                            def _has_data(self):
                                if self.call_policy is not None:
                                    return True

                                if self.install_protocol_eq is not None:
                                    return True

                                return False

                            @staticmethod
                            def _meta_info():
                                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.State']['meta_info']


                        class MatchInterface(object):
                            """
                            Top\-level container for interface match conditions
                            
                            .. attribute:: config
                            
                            	Configuration data for interface match conditions
                            	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface.Config>`
                            
                            .. attribute:: state
                            
                            	Operational state data for interface match conditions
                            	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface.State>`
                            
                            	**config**\: False
                            
                            

                            """

                            _prefix = 'oc-rpol'
                            _revision = '2016-05-12'

                            def __init__(self):
                                self.parent = None
                                self.ylist_key_names = []

                                self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface.Config()
                                self.config.parent = self
                                self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface.State()
                                self.state.parent = self


                            class Config(object):
                                """
                                Configuration data for interface match conditions
                                
                                .. attribute:: interface
                                
                                	Reference to a base interface.  If a reference to a subinterface is required, this leaf must be specified to indicate the base interface
                                	**type**\:  str
                                
                                	**refers to**\:  :py:class:`name <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface>`
                                
                                .. attribute:: subinterface
                                
                                	Reference to a subinterface \-\- this requires the base interface to be specified using the interface leaf in this container.  If only a reference to a base interface is requuired, this leaf should not be set
                                	**type**\:  int
                                
                                	**range:** 0..4294967295
                                
                                	**refers to**\:  :py:class:`index <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.Subinterfaces.Subinterface>`
                                
                                

                                """

                                _prefix = 'oc-rpol'
                                _revision = '2016-05-12'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.interface = None
                                    self.subinterface = None

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-routing-policy:config'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.interface is not None:
                                        return True

                                    if self.subinterface is not None:
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface.Config']['meta_info']


                            class State(object):
                                """
                                Operational state data for interface match conditions
                                
                                .. attribute:: interface
                                
                                	Reference to a base interface.  If a reference to a subinterface is required, this leaf must be specified to indicate the base interface
                                	**type**\:  str
                                
                                	**refers to**\:  :py:class:`name <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface>`
                                
                                	**config**\: False
                                
                                .. attribute:: subinterface
                                
                                	Reference to a subinterface \-\- this requires the base interface to be specified using the interface leaf in this container.  If only a reference to a base interface is requuired, this leaf should not be set
                                	**type**\:  int
                                
                                	**range:** 0..4294967295
                                
                                	**refers to**\:  :py:class:`index <ydk.models.ydktest.openconfig_interfaces.Interfaces.Interface.Subinterfaces.Subinterface>`
                                
                                	**config**\: False
                                
                                

                                """

                                _prefix = 'oc-rpol'
                                _revision = '2016-05-12'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.interface = None
                                    self.subinterface = None

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-routing-policy:state'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return False

                                def _has_data(self):
                                    if self.interface is not None:
                                        return True

                                    if self.subinterface is not None:
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface.State']['meta_info']

                            @property
                            def _common_path(self):
                                if self.parent is None:
                                    raise YPYModelError('parent is not set . Cannot derive path.')

                                return self.parent._common_path +'/openconfig-routing-policy:match-interface'

                            def is_config(self):
                                ''' Returns True if this instance represents config data else returns False '''
                                return True

                            def _has_data(self):
                                if self.config is not None and self.config._has_data():
                                    return True

                                if self.state is not None and self.state._has_data():
                                    return True

                                return False

                            @staticmethod
                            def _meta_info():
                                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchInterface']['meta_info']


                        class MatchPrefixSet(object):
                            """
                            Match a referenced prefix\-set according to the logic
                            defined in the match\-set\-options leaf
                            
                            .. attribute:: config
                            
                            	Configuration data for a prefix\-set condition
                            	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet.Config>`
                            
                            .. attribute:: state
                            
                            	Operational state data for a prefix\-set condition
                            	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet.State>`
                            
                            	**config**\: False
                            
                            

                            """

                            _prefix = 'oc-rpol'
                            _revision = '2016-05-12'

                            def __init__(self):
                                self.parent = None
                                self.ylist_key_names = []

                                self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet.Config()
                                self.config.parent = self
                                self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet.State()
                                self.state.parent = self


                            class Config(object):
                                """
                                Configuration data for a prefix\-set condition
                                
                                .. attribute:: match_set_options
                                
                                	Optional parameter that governs the behaviour of the match operation.  This leaf only supports matching on ANY member of the set or inverting the match.  Matching on ALL is not supported)
                                	**type**\:   :py:class:`MatchSetOptionsRestrictedTypeEnum <ydk.models.ydktest.openconfig_policy_types.MatchSetOptionsRestrictedTypeEnum>`
                                
                                .. attribute:: prefix_set
                                
                                	References a defined prefix set
                                	**type**\:  str
                                
                                	**refers to**\:  :py:class:`prefix_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.PrefixSets.PrefixSet>`
                                
                                

                                """

                                _prefix = 'oc-rpol'
                                _revision = '2016-05-12'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.match_set_options = None
                                    self.prefix_set = None

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-routing-policy:config'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.match_set_options is not None:
                                        return True

                                    if self.prefix_set is not None:
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet.Config']['meta_info']


                            class State(object):
                                """
                                Operational state data for a prefix\-set condition
                                
                                .. attribute:: match_set_options
                                
                                	Optional parameter that governs the behaviour of the match operation.  This leaf only supports matching on ANY member of the set or inverting the match.  Matching on ALL is not supported)
                                	**type**\:   :py:class:`MatchSetOptionsRestrictedTypeEnum <ydk.models.ydktest.openconfig_policy_types.MatchSetOptionsRestrictedTypeEnum>`
                                
                                	**config**\: False
                                
                                .. attribute:: prefix_set
                                
                                	References a defined prefix set
                                	**type**\:  str
                                
                                	**refers to**\:  :py:class:`prefix_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.PrefixSets.PrefixSet>`
                                
                                	**config**\: False
                                
                                

                                """

                                _prefix = 'oc-rpol'
                                _revision = '2016-05-12'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.match_set_options = None
                                    self.prefix_set = None

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-routing-policy:state'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return False

                                def _has_data(self):
                                    if self.match_set_options is not None:
                                        return True

                                    if self.prefix_set is not None:
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet.State']['meta_info']

                            @property
                            def _common_path(self):
                                if self.parent is None:
                                    raise YPYModelError('parent is not set . Cannot derive path.')

                                return self.parent._common_path +'/openconfig-routing-policy:match-prefix-set'

                            def is_config(self):
                                ''' Returns True if this instance represents config data else returns False '''
                                return True

                            def _has_data(self):
                                if self.config is not None and self.config._has_data():
                                    return True

                                if self.state is not None and self.state._has_data():
                                    return True

                                return False

                            @staticmethod
                            def _meta_info():
                                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchPrefixSet']['meta_info']


                        class MatchNeighborSet(object):
                            """
                            Match a referenced neighbor set according to the logic
                            defined in the match\-set\-options\-leaf
                            
                            .. attribute:: config
                            
                            	Configuration data 
                            	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet.Config>`
                            
                            .. attribute:: state
                            
                            	Operational state data 
                            	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet.State>`
                            
                            	**config**\: False
                            
                            

                            """

                            _prefix = 'oc-rpol'
                            _revision = '2016-05-12'

                            def __init__(self):
                                self.parent = None
                                self.ylist_key_names = []

                                self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet.Config()
                                self.config.parent = self
                                self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet.State()
                                self.state.parent = self


                            class Config(object):
                                """
                                Configuration data 
                                
                                .. attribute:: match_set_options
                                
                                	Optional parameter that governs the behaviour of the match operation.  This leaf only supports matching on ANY member of the set or inverting the match.  Matching on ALL is not supported)
                                	**type**\:   :py:class:`MatchSetOptionsRestrictedTypeEnum <ydk.models.ydktest.openconfig_policy_types.MatchSetOptionsRestrictedTypeEnum>`
                                
                                .. attribute:: neighbor_set
                                
                                	References a defined neighbor set
                                	**type**\:  str
                                
                                	**refers to**\:  :py:class:`neighbor_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.NeighborSets.NeighborSet>`
                                
                                

                                """

                                _prefix = 'oc-rpol'
                                _revision = '2016-05-12'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.match_set_options = None
                                    self.neighbor_set = None

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-routing-policy:config'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.match_set_options is not None:
                                        return True

                                    if self.neighbor_set is not None:
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet.Config']['meta_info']


                            class State(object):
                                """
                                Operational state data 
                                
                                .. attribute:: match_set_options
                                
                                	Optional parameter that governs the behaviour of the match operation.  This leaf only supports matching on ANY member of the set or inverting the match.  Matching on ALL is not supported)
                                	**type**\:   :py:class:`MatchSetOptionsRestrictedTypeEnum <ydk.models.ydktest.openconfig_policy_types.MatchSetOptionsRestrictedTypeEnum>`
                                
                                	**config**\: False
                                
                                .. attribute:: neighbor_set
                                
                                	References a defined neighbor set
                                	**type**\:  str
                                
                                	**refers to**\:  :py:class:`neighbor_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.NeighborSets.NeighborSet>`
                                
                                	**config**\: False
                                
                                

                                """

                                _prefix = 'oc-rpol'
                                _revision = '2016-05-12'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.match_set_options = None
                                    self.neighbor_set = None

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-routing-policy:state'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return False

                                def _has_data(self):
                                    if self.match_set_options is not None:
                                        return True

                                    if self.neighbor_set is not None:
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet.State']['meta_info']

                            @property
                            def _common_path(self):
                                if self.parent is None:
                                    raise YPYModelError('parent is not set . Cannot derive path.')

                                return self.parent._common_path +'/openconfig-routing-policy:match-neighbor-set'

                            def is_config(self):
                                ''' Returns True if this instance represents config data else returns False '''
                                return True

                            def _has_data(self):
                                if self.config is not None and self.config._has_data():
                                    return True

                                if self.state is not None and self.state._has_data():
                                    return True

                                return False

                            @staticmethod
                            def _meta_info():
                                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchNeighborSet']['meta_info']


                        class MatchTagSet(object):
                            """
                            Match a referenced tag set according to the logic defined
                            in the match\-options\-set leaf
                            
                            .. attribute:: config
                            
                            	Configuration data for tag\-set conditions
                            	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet.Config>`
                            
                            .. attribute:: state
                            
                            	Operational state data tag\-set conditions
                            	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet.State>`
                            
                            	**config**\: False
                            
                            

                            """

                            _prefix = 'oc-rpol'
                            _revision = '2016-05-12'

                            def __init__(self):
                                self.parent = None
                                self.ylist_key_names = []

                                self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet.Config()
                                self.config.parent = self
                                self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet.State()
                                self.state.parent = self


                            class Config(object):
                                """
                                Configuration data for tag\-set conditions
                                
                                .. attribute:: match_set_options
                                
                                	Optional parameter that governs the behaviour of the match operation.  This leaf only supports matching on ANY member of the set or inverting the match.  Matching on ALL is not supported)
                                	**type**\:   :py:class:`MatchSetOptionsRestrictedTypeEnum <ydk.models.ydktest.openconfig_policy_types.MatchSetOptionsRestrictedTypeEnum>`
                                
                                .. attribute:: tag_set
                                
                                	References a defined tag set
                                	**type**\:  str
                                
                                	**refers to**\:  :py:class:`tag_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.TagSets.TagSet>`
                                
                                

                                """

                                _prefix = 'oc-rpol'
                                _revision = '2016-05-12'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.match_set_options = None
                                    self.tag_set = None

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-routing-policy:config'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.match_set_options is not None:
                                        return True

                                    if self.tag_set is not None:
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet.Config']['meta_info']


                            class State(object):
                                """
                                Operational state data tag\-set conditions
                                
                                .. attribute:: match_set_options
                                
                                	Optional parameter that governs the behaviour of the match operation.  This leaf only supports matching on ANY member of the set or inverting the match.  Matching on ALL is not supported)
                                	**type**\:   :py:class:`MatchSetOptionsRestrictedTypeEnum <ydk.models.ydktest.openconfig_policy_types.MatchSetOptionsRestrictedTypeEnum>`
                                
                                	**config**\: False
                                
                                .. attribute:: tag_set
                                
                                	References a defined tag set
                                	**type**\:  str
                                
                                	**refers to**\:  :py:class:`tag_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.TagSets.TagSet>`
                                
                                	**config**\: False
                                
                                

                                """

                                _prefix = 'oc-rpol'
                                _revision = '2016-05-12'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.match_set_options = None
                                    self.tag_set = None

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-routing-policy:state'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return False

                                def _has_data(self):
                                    if self.match_set_options is not None:
                                        return True

                                    if self.tag_set is not None:
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet.State']['meta_info']

                            @property
                            def _common_path(self):
                                if self.parent is None:
                                    raise YPYModelError('parent is not set . Cannot derive path.')

                                return self.parent._common_path +'/openconfig-routing-policy:match-tag-set'

                            def is_config(self):
                                ''' Returns True if this instance represents config data else returns False '''
                                return True

                            def _has_data(self):
                                if self.config is not None and self.config._has_data():
                                    return True

                                if self.state is not None and self.state._has_data():
                                    return True

                                return False

                            @staticmethod
                            def _meta_info():
                                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.MatchTagSet']['meta_info']


                        class IgpConditions(object):
                            """
                            Policy conditions for IGP attributes
                            
                            

                            """

                            _prefix = 'oc-rpol'
                            _revision = '2016-05-12'

                            def __init__(self):
                                self.parent = None
                                self.ylist_key_names = []


                            @property
                            def _common_path(self):
                                if self.parent is None:
                                    raise YPYModelError('parent is not set . Cannot derive path.')

                                return self.parent._common_path +'/openconfig-routing-policy:igp-conditions'

                            def is_config(self):
                                ''' Returns True if this instance represents config data else returns False '''
                                return True

                            def _has_data(self):
                                return False

                            @staticmethod
                            def _meta_info():
                                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.IgpConditions']['meta_info']


                        class BgpConditions(object):
                            """
                            Top\-level container 
                            
                            .. attribute:: as_path_length
                            
                            	Value and comparison operations for conditions based on the length of the AS path in the route update
                            	**type**\:   :py:class:`AsPathLength <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength>`
                            
                            .. attribute:: community_count
                            
                            	Value and comparison operations for conditions based on the number of communities in the route update
                            	**type**\:   :py:class:`CommunityCount <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount>`
                            
                            .. attribute:: config
                            
                            	Configuration data for BGP\-specific policy conditions
                            	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.Config>`
                            
                            .. attribute:: match_as_path_set
                            
                            	Match a referenced as\-path set according to the logic defined in the match\-set\-options leaf
                            	**type**\:   :py:class:`MatchAsPathSet <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet>`
                            
                            .. attribute:: match_community_set
                            
                            	Top\-level container for match conditions on communities. Match a referenced community\-set according to the logic defined in the match\-set\-options leaf
                            	**type**\:   :py:class:`MatchCommunitySet <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet>`
                            
                            .. attribute:: match_ext_community_set
                            
                            	Match a referenced extended community\-set according to the logic defined in the match\-set\-options leaf
                            	**type**\:   :py:class:`MatchExtCommunitySet <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet>`
                            
                            .. attribute:: state
                            
                            	Operational state data for BGP\-specific policy conditions
                            	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.State>`
                            
                            	**config**\: False
                            
                            

                            """

                            _prefix = 'oc-bgp-pol'
                            _revision = '2016-06-21'

                            def __init__(self):
                                self.parent = None
                                self.ylist_key_names = []

                                self.as_path_length = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength()
                                self.as_path_length.parent = self
                                self.community_count = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount()
                                self.community_count.parent = self
                                self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.Config()
                                self.config.parent = self
                                self.match_as_path_set = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet()
                                self.match_as_path_set.parent = self
                                self.match_community_set = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet()
                                self.match_community_set.parent = self
                                self.match_ext_community_set = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet()
                                self.match_ext_community_set.parent = self
                                self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.State()
                                self.state.parent = self


                            class Config(object):
                                """
                                Configuration data for BGP\-specific policy conditions
                                
                                .. attribute:: afi_safi_in
                                
                                	List of address families which the NLRI may be within
                                	**type**\:  
                                		list of   :py:class:`Afi_Safi_TypeIdentity <ydk.models.ydktest.openconfig_bgp_types.Afi_Safi_TypeIdentity>`
                                
                                .. attribute:: local_pref_eq
                                
                                	Condition to check if the local pref attribute is equal to the specified value
                                	**type**\:  int
                                
                                	**range:** 0..4294967295
                                
                                .. attribute:: med_eq
                                
                                	Condition to check if the received MED value is equal to the specified value
                                	**type**\:  int
                                
                                	**range:** 0..4294967295
                                
                                .. attribute:: next_hop_in
                                
                                	List of next hop addresses to check for in the route update
                                	**type**\: one of the below types:
                                
                                	**type**\:  list of str
                                
                                	**pattern:** (([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])(%[\\p{N}\\p{L}]+)?
                                
                                
                                ----
                                	**type**\:  list of str
                                
                                	**pattern:** ((\:\|[0\-9a\-fA\-F]{0,4})\:)([0\-9a\-fA\-F]{0,4}\:){0,5}((([0\-9a\-fA\-F]{0,4}\:)?(\:\|[0\-9a\-fA\-F]{0,4}))\|(((25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])\\.){3}(25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])))(%[\\p{N}\\p{L}]+)?
                                
                                
                                ----
                                .. attribute:: origin_eq
                                
                                	Condition to check if the route origin is equal to the specified value
                                	**type**\:   :py:class:`BgpOriginAttrTypeEnum <ydk.models.ydktest.openconfig_bgp_types.BgpOriginAttrTypeEnum>`
                                
                                .. attribute:: route_type
                                
                                	Condition to check the route type in the route update
                                	**type**\:   :py:class:`RouteTypeEnum <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.Config.RouteTypeEnum>`
                                
                                

                                """

                                _prefix = 'oc-bgp-pol'
                                _revision = '2016-06-21'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.afi_safi_in = YLeafList()
                                    self.afi_safi_in.parent = self
                                    self.afi_safi_in.name = 'afi_safi_in'
                                    self.local_pref_eq = None
                                    self.med_eq = None
                                    self.next_hop_in = YLeafList()
                                    self.next_hop_in.parent = self
                                    self.next_hop_in.name = 'next_hop_in'
                                    self.origin_eq = None
                                    self.route_type = None

                                class RouteTypeEnum(Enum):
                                    """
                                    RouteTypeEnum

                                    Condition to check the route type in the route update

                                    .. data:: INTERNAL = 0

                                    	route type is internal

                                    .. data:: EXTERNAL = 1

                                    	route type is external

                                    """

                                    INTERNAL = 0

                                    EXTERNAL = 1


                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.Config.RouteTypeEnum']


                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-bgp-policy:config'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.afi_safi_in is not None:
                                        for child_ref in self.afi_safi_in:
                                            if child_ref._has_data():
                                                return True

                                    if self.local_pref_eq is not None:
                                        return True

                                    if self.med_eq is not None:
                                        return True

                                    if self.next_hop_in is not None:
                                        for child in self.next_hop_in:
                                            if child is not None:
                                                return True

                                    if self.origin_eq is not None:
                                        return True

                                    if self.route_type is not None:
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.Config']['meta_info']


                            class State(object):
                                """
                                Operational state data for BGP\-specific policy
                                conditions
                                
                                .. attribute:: afi_safi_in
                                
                                	List of address families which the NLRI may be within
                                	**type**\:  
                                		list of   :py:class:`Afi_Safi_TypeIdentity <ydk.models.ydktest.openconfig_bgp_types.Afi_Safi_TypeIdentity>`
                                
                                	**config**\: False
                                
                                .. attribute:: local_pref_eq
                                
                                	Condition to check if the local pref attribute is equal to the specified value
                                	**type**\:  int
                                
                                	**range:** 0..4294967295
                                
                                	**config**\: False
                                
                                .. attribute:: med_eq
                                
                                	Condition to check if the received MED value is equal to the specified value
                                	**type**\:  int
                                
                                	**range:** 0..4294967295
                                
                                	**config**\: False
                                
                                .. attribute:: next_hop_in
                                
                                	List of next hop addresses to check for in the route update
                                	**type**\: one of the below types:
                                
                                	**type**\:  list of str
                                
                                	**pattern:** (([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])(%[\\p{N}\\p{L}]+)?
                                
                                	**config**\: False
                                
                                
                                ----
                                	**type**\:  list of str
                                
                                	**pattern:** ((\:\|[0\-9a\-fA\-F]{0,4})\:)([0\-9a\-fA\-F]{0,4}\:){0,5}((([0\-9a\-fA\-F]{0,4}\:)?(\:\|[0\-9a\-fA\-F]{0,4}))\|(((25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])\\.){3}(25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])))(%[\\p{N}\\p{L}]+)?
                                
                                	**config**\: False
                                
                                
                                ----
                                .. attribute:: origin_eq
                                
                                	Condition to check if the route origin is equal to the specified value
                                	**type**\:   :py:class:`BgpOriginAttrTypeEnum <ydk.models.ydktest.openconfig_bgp_types.BgpOriginAttrTypeEnum>`
                                
                                	**config**\: False
                                
                                .. attribute:: route_type
                                
                                	Condition to check the route type in the route update
                                	**type**\:   :py:class:`RouteTypeEnum <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.State.RouteTypeEnum>`
                                
                                	**config**\: False
                                
                                

                                """

                                _prefix = 'oc-bgp-pol'
                                _revision = '2016-06-21'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.afi_safi_in = YLeafList()
                                    self.afi_safi_in.parent = self
                                    self.afi_safi_in.name = 'afi_safi_in'
                                    self.local_pref_eq = None
                                    self.med_eq = None
                                    self.next_hop_in = YLeafList()
                                    self.next_hop_in.parent = self
                                    self.next_hop_in.name = 'next_hop_in'
                                    self.origin_eq = None
                                    self.route_type = None

                                class RouteTypeEnum(Enum):
                                    """
                                    RouteTypeEnum

                                    Condition to check the route type in the route update

                                    .. data:: INTERNAL = 0

                                    	route type is internal

                                    .. data:: EXTERNAL = 1

                                    	route type is external

                                    """

                                    INTERNAL = 0

                                    EXTERNAL = 1


                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.State.RouteTypeEnum']


                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-bgp-policy:state'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return False

                                def _has_data(self):
                                    if self.afi_safi_in is not None:
                                        for child_ref in self.afi_safi_in:
                                            if child_ref._has_data():
                                                return True

                                    if self.local_pref_eq is not None:
                                        return True

                                    if self.med_eq is not None:
                                        return True

                                    if self.next_hop_in is not None:
                                        for child in self.next_hop_in:
                                            if child is not None:
                                                return True

                                    if self.origin_eq is not None:
                                        return True

                                    if self.route_type is not None:
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.State']['meta_info']


                            class CommunityCount(object):
                                """
                                Value and comparison operations for conditions based on the
                                number of communities in the route update
                                
                                .. attribute:: config
                                
                                	Configuration data for community count condition
                                	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount.Config>`
                                
                                .. attribute:: state
                                
                                	Operational state data for community count condition
                                	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount.State>`
                                
                                	**config**\: False
                                
                                

                                """

                                _prefix = 'oc-bgp-pol'
                                _revision = '2016-06-21'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount.Config()
                                    self.config.parent = self
                                    self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount.State()
                                    self.state.parent = self


                                class Config(object):
                                    """
                                    Configuration data for community count condition
                                    
                                    .. attribute:: operator
                                    
                                    	type of comparison to be performed
                                    	**type**\:   :py:class:`Attribute_ComparisonIdentity <ydk.models.ydktest.openconfig_policy_types.Attribute_ComparisonIdentity>`
                                    
                                    .. attribute:: value
                                    
                                    	value to compare with the community count
                                    	**type**\:  int
                                    
                                    	**range:** 0..4294967295
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.operator = None
                                        self.value = None

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:config'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return True

                                    def _has_data(self):
                                        if self.operator is not None:
                                            return True

                                        if self.value is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount.Config']['meta_info']


                                class State(object):
                                    """
                                    Operational state data for community count condition
                                    
                                    .. attribute:: operator
                                    
                                    	type of comparison to be performed
                                    	**type**\:   :py:class:`Attribute_ComparisonIdentity <ydk.models.ydktest.openconfig_policy_types.Attribute_ComparisonIdentity>`
                                    
                                    	**config**\: False
                                    
                                    .. attribute:: value
                                    
                                    	value to compare with the community count
                                    	**type**\:  int
                                    
                                    	**range:** 0..4294967295
                                    
                                    	**config**\: False
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.operator = None
                                        self.value = None

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:state'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return False

                                    def _has_data(self):
                                        if self.operator is not None:
                                            return True

                                        if self.value is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount.State']['meta_info']

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-bgp-policy:community-count'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.config is not None and self.config._has_data():
                                        return True

                                    if self.state is not None and self.state._has_data():
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.CommunityCount']['meta_info']


                            class AsPathLength(object):
                                """
                                Value and comparison operations for conditions based on the
                                length of the AS path in the route update
                                
                                .. attribute:: config
                                
                                	Configuration data for AS path length condition
                                	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength.Config>`
                                
                                .. attribute:: state
                                
                                	Operational state data for AS path length condition
                                	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength.State>`
                                
                                	**config**\: False
                                
                                

                                """

                                _prefix = 'oc-bgp-pol'
                                _revision = '2016-06-21'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength.Config()
                                    self.config.parent = self
                                    self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength.State()
                                    self.state.parent = self


                                class Config(object):
                                    """
                                    Configuration data for AS path length condition
                                    
                                    .. attribute:: operator
                                    
                                    	type of comparison to be performed
                                    	**type**\:   :py:class:`Attribute_ComparisonIdentity <ydk.models.ydktest.openconfig_policy_types.Attribute_ComparisonIdentity>`
                                    
                                    .. attribute:: value
                                    
                                    	value to compare with the community count
                                    	**type**\:  int
                                    
                                    	**range:** 0..4294967295
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.operator = None
                                        self.value = None

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:config'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return True

                                    def _has_data(self):
                                        if self.operator is not None:
                                            return True

                                        if self.value is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength.Config']['meta_info']


                                class State(object):
                                    """
                                    Operational state data for AS path length condition
                                    
                                    .. attribute:: operator
                                    
                                    	type of comparison to be performed
                                    	**type**\:   :py:class:`Attribute_ComparisonIdentity <ydk.models.ydktest.openconfig_policy_types.Attribute_ComparisonIdentity>`
                                    
                                    	**config**\: False
                                    
                                    .. attribute:: value
                                    
                                    	value to compare with the community count
                                    	**type**\:  int
                                    
                                    	**range:** 0..4294967295
                                    
                                    	**config**\: False
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.operator = None
                                        self.value = None

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:state'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return False

                                    def _has_data(self):
                                        if self.operator is not None:
                                            return True

                                        if self.value is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength.State']['meta_info']

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-bgp-policy:as-path-length'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.config is not None and self.config._has_data():
                                        return True

                                    if self.state is not None and self.state._has_data():
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.AsPathLength']['meta_info']


                            class MatchCommunitySet(object):
                                """
                                Top\-level container for match conditions on communities.
                                Match a referenced community\-set according to the logic
                                defined in the match\-set\-options leaf
                                
                                .. attribute:: config
                                
                                	Configuration data for match conditions on communities
                                	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet.Config>`
                                
                                .. attribute:: state
                                
                                	Operational state data 
                                	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet.State>`
                                
                                	**config**\: False
                                
                                

                                """

                                _prefix = 'oc-bgp-pol'
                                _revision = '2016-06-21'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet.Config()
                                    self.config.parent = self
                                    self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet.State()
                                    self.state.parent = self


                                class Config(object):
                                    """
                                    Configuration data for match conditions on communities
                                    
                                    .. attribute:: community_set
                                    
                                    	References a defined community set
                                    	**type**\:  str
                                    
                                    	**refers to**\:  :py:class:`community_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet>`
                                    
                                    .. attribute:: match_set_options
                                    
                                    	Optional parameter that governs the behaviour of the match operation
                                    	**type**\:   :py:class:`MatchSetOptionsTypeEnum <ydk.models.ydktest.openconfig_policy_types.MatchSetOptionsTypeEnum>`
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.community_set = None
                                        self.match_set_options = None

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:config'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return True

                                    def _has_data(self):
                                        if self.community_set is not None:
                                            return True

                                        if self.match_set_options is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet.Config']['meta_info']


                                class State(object):
                                    """
                                    Operational state data 
                                    
                                    .. attribute:: community_set
                                    
                                    	References a defined community set
                                    	**type**\:  str
                                    
                                    	**refers to**\:  :py:class:`community_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet>`
                                    
                                    	**config**\: False
                                    
                                    .. attribute:: match_set_options
                                    
                                    	Optional parameter that governs the behaviour of the match operation
                                    	**type**\:   :py:class:`MatchSetOptionsTypeEnum <ydk.models.ydktest.openconfig_policy_types.MatchSetOptionsTypeEnum>`
                                    
                                    	**config**\: False
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.community_set = None
                                        self.match_set_options = None

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:state'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return False

                                    def _has_data(self):
                                        if self.community_set is not None:
                                            return True

                                        if self.match_set_options is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet.State']['meta_info']

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-bgp-policy:match-community-set'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.config is not None and self.config._has_data():
                                        return True

                                    if self.state is not None and self.state._has_data():
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchCommunitySet']['meta_info']


                            class MatchExtCommunitySet(object):
                                """
                                Match a referenced extended community\-set according to the
                                logic defined in the match\-set\-options leaf
                                
                                .. attribute:: config
                                
                                	Configuration data for match conditions on extended communities
                                	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet.Config>`
                                
                                .. attribute:: state
                                
                                	Operational state data for match conditions on extended communities
                                	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet.State>`
                                
                                	**config**\: False
                                
                                

                                """

                                _prefix = 'oc-bgp-pol'
                                _revision = '2016-06-21'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet.Config()
                                    self.config.parent = self
                                    self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet.State()
                                    self.state.parent = self


                                class Config(object):
                                    """
                                    Configuration data for match conditions on extended
                                    communities
                                    
                                    .. attribute:: ext_community_set
                                    
                                    	References a defined extended community set
                                    	**type**\:  str
                                    
                                    	**refers to**\:  :py:class:`ext_community_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet>`
                                    
                                    .. attribute:: match_set_options
                                    
                                    	Optional parameter that governs the behaviour of the match operation
                                    	**type**\:   :py:class:`MatchSetOptionsTypeEnum <ydk.models.ydktest.openconfig_policy_types.MatchSetOptionsTypeEnum>`
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.ext_community_set = None
                                        self.match_set_options = None

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:config'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return True

                                    def _has_data(self):
                                        if self.ext_community_set is not None:
                                            return True

                                        if self.match_set_options is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet.Config']['meta_info']


                                class State(object):
                                    """
                                    Operational state data for match conditions on extended
                                    communities
                                    
                                    .. attribute:: ext_community_set
                                    
                                    	References a defined extended community set
                                    	**type**\:  str
                                    
                                    	**refers to**\:  :py:class:`ext_community_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet>`
                                    
                                    	**config**\: False
                                    
                                    .. attribute:: match_set_options
                                    
                                    	Optional parameter that governs the behaviour of the match operation
                                    	**type**\:   :py:class:`MatchSetOptionsTypeEnum <ydk.models.ydktest.openconfig_policy_types.MatchSetOptionsTypeEnum>`
                                    
                                    	**config**\: False
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.ext_community_set = None
                                        self.match_set_options = None

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:state'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return False

                                    def _has_data(self):
                                        if self.ext_community_set is not None:
                                            return True

                                        if self.match_set_options is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet.State']['meta_info']

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-bgp-policy:match-ext-community-set'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.config is not None and self.config._has_data():
                                        return True

                                    if self.state is not None and self.state._has_data():
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchExtCommunitySet']['meta_info']


                            class MatchAsPathSet(object):
                                """
                                Match a referenced as\-path set according to the logic
                                defined in the match\-set\-options leaf
                                
                                .. attribute:: config
                                
                                	Configuration data for match conditions on AS path set
                                	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet.Config>`
                                
                                .. attribute:: state
                                
                                	Operational state data for match conditions on AS path set
                                	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet.State>`
                                
                                	**config**\: False
                                
                                

                                """

                                _prefix = 'oc-bgp-pol'
                                _revision = '2016-06-21'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet.Config()
                                    self.config.parent = self
                                    self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet.State()
                                    self.state.parent = self


                                class Config(object):
                                    """
                                    Configuration data for match conditions on AS path set
                                    
                                    .. attribute:: as_path_set
                                    
                                    	References a defined AS path set
                                    	**type**\:  str
                                    
                                    	**refers to**\:  :py:class:`as_path_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet>`
                                    
                                    .. attribute:: match_set_options
                                    
                                    	Optional parameter that governs the behaviour of the match operation
                                    	**type**\:   :py:class:`MatchSetOptionsTypeEnum <ydk.models.ydktest.openconfig_policy_types.MatchSetOptionsTypeEnum>`
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.as_path_set = None
                                        self.match_set_options = None

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:config'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return True

                                    def _has_data(self):
                                        if self.as_path_set is not None:
                                            return True

                                        if self.match_set_options is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet.Config']['meta_info']


                                class State(object):
                                    """
                                    Operational state data for match conditions on AS
                                    path set
                                    
                                    .. attribute:: as_path_set
                                    
                                    	References a defined AS path set
                                    	**type**\:  str
                                    
                                    	**refers to**\:  :py:class:`as_path_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.AsPathSets.AsPathSet>`
                                    
                                    	**config**\: False
                                    
                                    .. attribute:: match_set_options
                                    
                                    	Optional parameter that governs the behaviour of the match operation
                                    	**type**\:   :py:class:`MatchSetOptionsTypeEnum <ydk.models.ydktest.openconfig_policy_types.MatchSetOptionsTypeEnum>`
                                    
                                    	**config**\: False
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.as_path_set = None
                                        self.match_set_options = None

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:state'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return False

                                    def _has_data(self):
                                        if self.as_path_set is not None:
                                            return True

                                        if self.match_set_options is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet.State']['meta_info']

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-bgp-policy:match-as-path-set'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.config is not None and self.config._has_data():
                                        return True

                                    if self.state is not None and self.state._has_data():
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions.MatchAsPathSet']['meta_info']

                            @property
                            def _common_path(self):
                                if self.parent is None:
                                    raise YPYModelError('parent is not set . Cannot derive path.')

                                return self.parent._common_path +'/openconfig-bgp-policy:bgp-conditions'

                            def is_config(self):
                                ''' Returns True if this instance represents config data else returns False '''
                                return True

                            def _has_data(self):
                                if self.as_path_length is not None and self.as_path_length._has_data():
                                    return True

                                if self.community_count is not None and self.community_count._has_data():
                                    return True

                                if self.config is not None and self.config._has_data():
                                    return True

                                if self.match_as_path_set is not None and self.match_as_path_set._has_data():
                                    return True

                                if self.match_community_set is not None and self.match_community_set._has_data():
                                    return True

                                if self.match_ext_community_set is not None and self.match_ext_community_set._has_data():
                                    return True

                                if self.state is not None and self.state._has_data():
                                    return True

                                return False

                            @staticmethod
                            def _meta_info():
                                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions.BgpConditions']['meta_info']

                        @property
                        def _common_path(self):
                            if self.parent is None:
                                raise YPYModelError('parent is not set . Cannot derive path.')

                            return self.parent._common_path +'/openconfig-routing-policy:conditions'

                        def is_config(self):
                            ''' Returns True if this instance represents config data else returns False '''
                            return True

                        def _has_data(self):
                            if self.bgp_conditions is not None and self.bgp_conditions._has_data():
                                return True

                            if self.config is not None and self.config._has_data():
                                return True

                            if self.igp_conditions is not None and self.igp_conditions._has_data():
                                return True

                            if self.match_interface is not None and self.match_interface._has_data():
                                return True

                            if self.match_neighbor_set is not None and self.match_neighbor_set._has_data():
                                return True

                            if self.match_prefix_set is not None and self.match_prefix_set._has_data():
                                return True

                            if self.match_tag_set is not None and self.match_tag_set._has_data():
                                return True

                            if self.state is not None and self.state._has_data():
                                return True

                            return False

                        @staticmethod
                        def _meta_info():
                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Conditions']['meta_info']


                    class Actions(object):
                        """
                        Top\-level container for policy action statements
                        
                        .. attribute:: bgp_actions
                        
                        	Top\-level container for BGP\-specific actions
                        	**type**\:   :py:class:`BgpActions <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions>`
                        
                        .. attribute:: config
                        
                        	Configuration data for policy actions
                        	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.Config>`
                        
                        .. attribute:: igp_actions
                        
                        	Actions to set IGP route attributes; these actions apply to multiple IGPs
                        	**type**\:   :py:class:`IgpActions <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions>`
                        
                        .. attribute:: state
                        
                        	Operational state data for policy actions
                        	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.State>`
                        
                        	**config**\: False
                        
                        

                        """

                        _prefix = 'oc-rpol'
                        _revision = '2016-05-12'

                        def __init__(self):
                            self.parent = None
                            self.ylist_key_names = []

                            self.bgp_actions = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions()
                            self.bgp_actions.parent = self
                            self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.Config()
                            self.config.parent = self
                            self.igp_actions = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions()
                            self.igp_actions.parent = self
                            self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.State()
                            self.state.parent = self


                        class Config(object):
                            """
                            Configuration data for policy actions
                            
                            .. attribute:: accept_route
                            
                            	accepts the route into the routing table
                            	**type**\:  :py:class:`Empty<ydk.types.Empty>`
                            
                            .. attribute:: reject_route
                            
                            	rejects the route
                            	**type**\:  :py:class:`Empty<ydk.types.Empty>`
                            
                            

                            """

                            _prefix = 'oc-rpol'
                            _revision = '2016-05-12'

                            def __init__(self):
                                self.parent = None
                                self.ylist_key_names = []

                                self.accept_route = None
                                self.reject_route = None

                            @property
                            def _common_path(self):
                                if self.parent is None:
                                    raise YPYModelError('parent is not set . Cannot derive path.')

                                return self.parent._common_path +'/openconfig-routing-policy:config'

                            def is_config(self):
                                ''' Returns True if this instance represents config data else returns False '''
                                return True

                            def _has_data(self):
                                if self.accept_route is not None:
                                    return True

                                if self.reject_route is not None:
                                    return True

                                return False

                            @staticmethod
                            def _meta_info():
                                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.Config']['meta_info']


                        class State(object):
                            """
                            Operational state data for policy actions
                            
                            .. attribute:: accept_route
                            
                            	accepts the route into the routing table
                            	**type**\:  :py:class:`Empty<ydk.types.Empty>`
                            
                            	**config**\: False
                            
                            .. attribute:: reject_route
                            
                            	rejects the route
                            	**type**\:  :py:class:`Empty<ydk.types.Empty>`
                            
                            	**config**\: False
                            
                            

                            """

                            _prefix = 'oc-rpol'
                            _revision = '2016-05-12'

                            def __init__(self):
                                self.parent = None
                                self.ylist_key_names = []

                                self.accept_route = None
                                self.reject_route = None

                            @property
                            def _common_path(self):
                                if self.parent is None:
                                    raise YPYModelError('parent is not set . Cannot derive path.')

                                return self.parent._common_path +'/openconfig-routing-policy:state'

                            def is_config(self):
                                ''' Returns True if this instance represents config data else returns False '''
                                return False

                            def _has_data(self):
                                if self.accept_route is not None:
                                    return True

                                if self.reject_route is not None:
                                    return True

                                return False

                            @staticmethod
                            def _meta_info():
                                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.State']['meta_info']


                        class IgpActions(object):
                            """
                            Actions to set IGP route attributes; these actions
                            apply to multiple IGPs
                            
                            .. attribute:: config
                            
                            	Configuration data 
                            	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions.Config>`
                            
                            .. attribute:: state
                            
                            	Operational state data 
                            	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions.State>`
                            
                            	**config**\: False
                            
                            

                            """

                            _prefix = 'oc-rpol'
                            _revision = '2016-05-12'

                            def __init__(self):
                                self.parent = None
                                self.ylist_key_names = []

                                self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions.Config()
                                self.config.parent = self
                                self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions.State()
                                self.state.parent = self


                            class Config(object):
                                """
                                Configuration data 
                                
                                .. attribute:: set_tag
                                
                                	Set the tag value for OSPF or IS\-IS routes
                                	**type**\: one of the below types:
                                
                                	**type**\:  int
                                
                                	**range:** 0..4294967295
                                
                                
                                ----
                                	**type**\:  str
                                
                                	**pattern:** ([0\-9a\-fA\-F]{2}(\:[0\-9a\-fA\-F]{2})\*)?
                                
                                
                                ----
                                

                                """

                                _prefix = 'oc-rpol'
                                _revision = '2016-05-12'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.set_tag = None

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-routing-policy:config'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.set_tag is not None:
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions.Config']['meta_info']


                            class State(object):
                                """
                                Operational state data 
                                
                                .. attribute:: set_tag
                                
                                	Set the tag value for OSPF or IS\-IS routes
                                	**type**\: one of the below types:
                                
                                	**type**\:  int
                                
                                	**range:** 0..4294967295
                                
                                	**config**\: False
                                
                                
                                ----
                                	**type**\:  str
                                
                                	**pattern:** ([0\-9a\-fA\-F]{2}(\:[0\-9a\-fA\-F]{2})\*)?
                                
                                	**config**\: False
                                
                                
                                ----
                                

                                """

                                _prefix = 'oc-rpol'
                                _revision = '2016-05-12'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.set_tag = None

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-routing-policy:state'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return False

                                def _has_data(self):
                                    if self.set_tag is not None:
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions.State']['meta_info']

                            @property
                            def _common_path(self):
                                if self.parent is None:
                                    raise YPYModelError('parent is not set . Cannot derive path.')

                                return self.parent._common_path +'/openconfig-routing-policy:igp-actions'

                            def is_config(self):
                                ''' Returns True if this instance represents config data else returns False '''
                                return True

                            def _has_data(self):
                                if self.config is not None and self.config._has_data():
                                    return True

                                if self.state is not None and self.state._has_data():
                                    return True

                                return False

                            @staticmethod
                            def _meta_info():
                                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.IgpActions']['meta_info']


                        class BgpActions(object):
                            """
                            Top\-level container for BGP\-specific actions
                            
                            .. attribute:: config
                            
                            	Configuration data for BGP\-specific actions
                            	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.Config>`
                            
                            .. attribute:: set_as_path_prepend
                            
                            	action to prepend local AS number to the AS\-path a specified number of times
                            	**type**\:   :py:class:`SetAsPathPrepend <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend>`
                            
                            .. attribute:: set_community
                            
                            	Action to set the community attributes of the route, along with options to modify how the community is modified. Communities may be set using an inline list OR reference to an existing defined set (not both)
                            	**type**\:   :py:class:`SetCommunity <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity>`
                            
                            .. attribute:: set_ext_community
                            
                            	Action to set the extended community attributes of the route, along with options to modify how the community is modified. Extended communities may be set using an inline list OR a reference to an existing defined set (but not both)
                            	**type**\:   :py:class:`SetExtCommunity <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity>`
                            
                            .. attribute:: state
                            
                            	Operational state data for BGP\-specific actions
                            	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.State>`
                            
                            	**config**\: False
                            
                            

                            """

                            _prefix = 'oc-bgp-pol'
                            _revision = '2016-06-21'

                            def __init__(self):
                                self.parent = None
                                self.ylist_key_names = []

                                self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.Config()
                                self.config.parent = self
                                self.set_as_path_prepend = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend()
                                self.set_as_path_prepend.parent = self
                                self.set_community = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity()
                                self.set_community.parent = self
                                self.set_ext_community = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity()
                                self.set_ext_community.parent = self
                                self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.State()
                                self.state.parent = self


                            class Config(object):
                                """
                                Configuration data for BGP\-specific actions
                                
                                .. attribute:: set_local_pref
                                
                                	set the local pref attribute on the route update
                                	**type**\:  int
                                
                                	**range:** 0..4294967295
                                
                                .. attribute:: set_med
                                
                                	set the med metric attribute in the route update
                                	**type**\: one of the below types:
                                
                                	**type**\:  int
                                
                                	**range:** 0..4294967295
                                
                                
                                ----
                                	**type**\:  str
                                
                                	**pattern:** ^[+\-][0\-9]+
                                
                                
                                ----
                                	**type**\:   :py:class:`BgpSetMedTypeEnum <ydk.models.ydktest.openconfig_bgp_policy.BgpSetMedTypeEnum>`
                                
                                
                                ----
                                .. attribute:: set_next_hop
                                
                                	set the next\-hop attribute in the route update
                                	**type**\: one of the below types:
                                
                                	**type**\:  str
                                
                                	**pattern:** (([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])(%[\\p{N}\\p{L}]+)?
                                
                                
                                ----
                                	**type**\:  str
                                
                                	**pattern:** ((\:\|[0\-9a\-fA\-F]{0,4})\:)([0\-9a\-fA\-F]{0,4}\:){0,5}((([0\-9a\-fA\-F]{0,4}\:)?(\:\|[0\-9a\-fA\-F]{0,4}))\|(((25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])\\.){3}(25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])))(%[\\p{N}\\p{L}]+)?
                                
                                
                                ----
                                
                                ----
                                	**type**\:   :py:class:`BgpNextHopTypeEnum <ydk.models.ydktest.openconfig_bgp_policy.BgpNextHopTypeEnum>`
                                
                                
                                ----
                                .. attribute:: set_route_origin
                                
                                	set the origin attribute to the specified value
                                	**type**\:   :py:class:`BgpOriginAttrTypeEnum <ydk.models.ydktest.openconfig_bgp_types.BgpOriginAttrTypeEnum>`
                                
                                

                                """

                                _prefix = 'oc-bgp-pol'
                                _revision = '2016-06-21'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.set_local_pref = None
                                    self.set_med = None
                                    self.set_next_hop = None
                                    self.set_route_origin = None

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-bgp-policy:config'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.set_local_pref is not None:
                                        return True

                                    if self.set_med is not None:
                                        return True

                                    if self.set_next_hop is not None:
                                        return True

                                    if self.set_route_origin is not None:
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.Config']['meta_info']


                            class State(object):
                                """
                                Operational state data for BGP\-specific actions
                                
                                .. attribute:: set_local_pref
                                
                                	set the local pref attribute on the route update
                                	**type**\:  int
                                
                                	**range:** 0..4294967295
                                
                                	**config**\: False
                                
                                .. attribute:: set_med
                                
                                	set the med metric attribute in the route update
                                	**type**\: one of the below types:
                                
                                	**type**\:  int
                                
                                	**range:** 0..4294967295
                                
                                	**config**\: False
                                
                                
                                ----
                                	**type**\:  str
                                
                                	**pattern:** ^[+\-][0\-9]+
                                
                                	**config**\: False
                                
                                
                                ----
                                	**type**\:   :py:class:`BgpSetMedTypeEnum <ydk.models.ydktest.openconfig_bgp_policy.BgpSetMedTypeEnum>`
                                
                                	**config**\: False
                                
                                
                                ----
                                .. attribute:: set_next_hop
                                
                                	set the next\-hop attribute in the route update
                                	**type**\: one of the below types:
                                
                                	**type**\:  str
                                
                                	**pattern:** (([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])(%[\\p{N}\\p{L}]+)?
                                
                                	**config**\: False
                                
                                
                                ----
                                	**type**\:  str
                                
                                	**pattern:** ((\:\|[0\-9a\-fA\-F]{0,4})\:)([0\-9a\-fA\-F]{0,4}\:){0,5}((([0\-9a\-fA\-F]{0,4}\:)?(\:\|[0\-9a\-fA\-F]{0,4}))\|(((25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])\\.){3}(25[0\-5]\|2[0\-4][0\-9]\|[01]?[0\-9]?[0\-9])))(%[\\p{N}\\p{L}]+)?
                                
                                	**config**\: False
                                
                                
                                ----
                                
                                ----
                                	**type**\:   :py:class:`BgpNextHopTypeEnum <ydk.models.ydktest.openconfig_bgp_policy.BgpNextHopTypeEnum>`
                                
                                	**config**\: False
                                
                                
                                ----
                                .. attribute:: set_route_origin
                                
                                	set the origin attribute to the specified value
                                	**type**\:   :py:class:`BgpOriginAttrTypeEnum <ydk.models.ydktest.openconfig_bgp_types.BgpOriginAttrTypeEnum>`
                                
                                	**config**\: False
                                
                                

                                """

                                _prefix = 'oc-bgp-pol'
                                _revision = '2016-06-21'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.set_local_pref = None
                                    self.set_med = None
                                    self.set_next_hop = None
                                    self.set_route_origin = None

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-bgp-policy:state'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return False

                                def _has_data(self):
                                    if self.set_local_pref is not None:
                                        return True

                                    if self.set_med is not None:
                                        return True

                                    if self.set_next_hop is not None:
                                        return True

                                    if self.set_route_origin is not None:
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.State']['meta_info']


                            class SetAsPathPrepend(object):
                                """
                                action to prepend local AS number to the AS\-path a
                                specified number of times
                                
                                .. attribute:: config
                                
                                	Configuration data for the AS path prepend action
                                	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend.Config>`
                                
                                .. attribute:: state
                                
                                	Operational state data for the AS path prepend action
                                	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend.State>`
                                
                                	**config**\: False
                                
                                

                                """

                                _prefix = 'oc-bgp-pol'
                                _revision = '2016-06-21'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend.Config()
                                    self.config.parent = self
                                    self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend.State()
                                    self.state.parent = self


                                class Config(object):
                                    """
                                    Configuration data for the AS path prepend action
                                    
                                    .. attribute:: repeat_n
                                    
                                    	Number of times to prepend the local AS number to the AS path.  The value should be between 1 and the maximum supported by the implementation
                                    	**type**\:  int
                                    
                                    	**range:** 1..255
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.repeat_n = None

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:config'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return True

                                    def _has_data(self):
                                        if self.repeat_n is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend.Config']['meta_info']


                                class State(object):
                                    """
                                    Operational state data for the AS path prepend action
                                    
                                    .. attribute:: repeat_n
                                    
                                    	Number of times to prepend the local AS number to the AS path.  The value should be between 1 and the maximum supported by the implementation
                                    	**type**\:  int
                                    
                                    	**range:** 1..255
                                    
                                    	**config**\: False
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.repeat_n = None

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:state'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return False

                                    def _has_data(self):
                                        if self.repeat_n is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend.State']['meta_info']

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-bgp-policy:set-as-path-prepend'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.config is not None and self.config._has_data():
                                        return True

                                    if self.state is not None and self.state._has_data():
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetAsPathPrepend']['meta_info']


                            class SetCommunity(object):
                                """
                                Action to set the community attributes of the route, along
                                with options to modify how the community is modified.
                                Communities may be set using an inline list OR
                                reference to an existing defined set (not both).
                                
                                .. attribute:: config
                                
                                	Configuration data for the set\-community action
                                	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Config>`
                                
                                .. attribute:: inline
                                
                                	Set the community values for the action inline with a list
                                	**type**\:   :py:class:`Inline <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline>`
                                
                                .. attribute:: reference
                                
                                	Provide a reference to a defined community set for the set\-community action
                                	**type**\:   :py:class:`Reference <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference>`
                                
                                .. attribute:: state
                                
                                	Operational state data for the set\-community action
                                	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.State>`
                                
                                	**config**\: False
                                
                                

                                """

                                _prefix = 'oc-bgp-pol'
                                _revision = '2016-06-21'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Config()
                                    self.config.parent = self
                                    self.inline = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline()
                                    self.inline.parent = self
                                    self.reference = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference()
                                    self.reference.parent = self
                                    self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.State()
                                    self.state.parent = self


                                class Config(object):
                                    """
                                    Configuration data for the set\-community action
                                    
                                    .. attribute:: method
                                    
                                    	Indicates the method used to specify the extended communities for the set\-ext\-community action
                                    	**type**\:   :py:class:`MethodEnum <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Config.MethodEnum>`
                                    
                                    .. attribute:: options
                                    
                                    	Options for modifying the community attribute with the specified values.  These options apply to both methods of setting the community attribute
                                    	**type**\:   :py:class:`BgpSetCommunityOptionTypeEnum <ydk.models.ydktest.openconfig_bgp_policy.BgpSetCommunityOptionTypeEnum>`
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.method = None
                                        self.options = None

                                    class MethodEnum(Enum):
                                        """
                                        MethodEnum

                                        Indicates the method used to specify the extended

                                        communities for the set\-ext\-community action

                                        .. data:: INLINE = 0

                                        	The extended communities are specified inline as a

                                        	list

                                        .. data:: REFERENCE = 1

                                        	The extended communities are specified by referencing a

                                        	defined ext-community set

                                        """

                                        INLINE = 0

                                        REFERENCE = 1


                                        @staticmethod
                                        def _meta_info():
                                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Config.MethodEnum']


                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:config'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return True

                                    def _has_data(self):
                                        if self.method is not None:
                                            return True

                                        if self.options is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Config']['meta_info']


                                class State(object):
                                    """
                                    Operational state data for the set\-community action
                                    
                                    .. attribute:: method
                                    
                                    	Indicates the method used to specify the extended communities for the set\-ext\-community action
                                    	**type**\:   :py:class:`MethodEnum <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.State.MethodEnum>`
                                    
                                    	**config**\: False
                                    
                                    .. attribute:: options
                                    
                                    	Options for modifying the community attribute with the specified values.  These options apply to both methods of setting the community attribute
                                    	**type**\:   :py:class:`BgpSetCommunityOptionTypeEnum <ydk.models.ydktest.openconfig_bgp_policy.BgpSetCommunityOptionTypeEnum>`
                                    
                                    	**config**\: False
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.method = None
                                        self.options = None

                                    class MethodEnum(Enum):
                                        """
                                        MethodEnum

                                        Indicates the method used to specify the extended

                                        communities for the set\-ext\-community action

                                        .. data:: INLINE = 0

                                        	The extended communities are specified inline as a

                                        	list

                                        .. data:: REFERENCE = 1

                                        	The extended communities are specified by referencing a

                                        	defined ext-community set

                                        """

                                        INLINE = 0

                                        REFERENCE = 1


                                        @staticmethod
                                        def _meta_info():
                                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.State.MethodEnum']


                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:state'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return False

                                    def _has_data(self):
                                        if self.method is not None:
                                            return True

                                        if self.options is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.State']['meta_info']


                                class Inline(object):
                                    """
                                    Set the community values for the action inline with
                                    a list.
                                    
                                    .. attribute:: config
                                    
                                    	Configuration data or inline specification of set\-community action
                                    	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline.Config>`
                                    
                                    .. attribute:: state
                                    
                                    	Operational state data or inline specification of set\-community action
                                    	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline.State>`
                                    
                                    	**config**\: False
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline.Config()
                                        self.config.parent = self
                                        self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline.State()
                                        self.state.parent = self


                                    class Config(object):
                                        """
                                        Configuration data or inline specification of set\-community
                                        action
                                        
                                        .. attribute:: communities
                                        
                                        	Set the community values for the update inline with a list
                                        	**type**\: one of the below types:
                                        
                                        	**type**\:  list of int
                                        
                                        	**range:** 65536..4294901759
                                        
                                        
                                        ----
                                        	**type**\:  list of str
                                        
                                        	**pattern:** ([0\-9]+\:[0\-9]+)
                                        
                                        
                                        ----
                                        
                                        ----
                                        	**type**\:  
                                        		list of   :py:class:`Bgp_Well_Known_Std_CommunityIdentity <ydk.models.ydktest.openconfig_bgp_types.Bgp_Well_Known_Std_CommunityIdentity>`
                                        
                                        
                                        ----
                                        

                                        """

                                        _prefix = 'oc-bgp-pol'
                                        _revision = '2016-06-21'

                                        def __init__(self):
                                            self.parent = None
                                            self.ylist_key_names = []

                                            self.communities = YLeafList()
                                            self.communities.parent = self
                                            self.communities.name = 'communities'

                                        @property
                                        def _common_path(self):
                                            if self.parent is None:
                                                raise YPYModelError('parent is not set . Cannot derive path.')

                                            return self.parent._common_path +'/openconfig-bgp-policy:config'

                                        def is_config(self):
                                            ''' Returns True if this instance represents config data else returns False '''
                                            return True

                                        def _has_data(self):
                                            if self.communities is not None:
                                                for child in self.communities:
                                                    if child is not None:
                                                        return True

                                            return False

                                        @staticmethod
                                        def _meta_info():
                                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline.Config']['meta_info']


                                    class State(object):
                                        """
                                        Operational state data or inline specification of
                                        set\-community action
                                        
                                        .. attribute:: communities
                                        
                                        	Set the community values for the update inline with a list
                                        	**type**\: one of the below types:
                                        
                                        	**type**\:  list of int
                                        
                                        	**range:** 65536..4294901759
                                        
                                        	**config**\: False
                                        
                                        
                                        ----
                                        	**type**\:  list of str
                                        
                                        	**pattern:** ([0\-9]+\:[0\-9]+)
                                        
                                        	**config**\: False
                                        
                                        
                                        ----
                                        
                                        ----
                                        	**type**\:  
                                        		list of   :py:class:`Bgp_Well_Known_Std_CommunityIdentity <ydk.models.ydktest.openconfig_bgp_types.Bgp_Well_Known_Std_CommunityIdentity>`
                                        
                                        	**config**\: False
                                        
                                        
                                        ----
                                        

                                        """

                                        _prefix = 'oc-bgp-pol'
                                        _revision = '2016-06-21'

                                        def __init__(self):
                                            self.parent = None
                                            self.ylist_key_names = []

                                            self.communities = YLeafList()
                                            self.communities.parent = self
                                            self.communities.name = 'communities'

                                        @property
                                        def _common_path(self):
                                            if self.parent is None:
                                                raise YPYModelError('parent is not set . Cannot derive path.')

                                            return self.parent._common_path +'/openconfig-bgp-policy:state'

                                        def is_config(self):
                                            ''' Returns True if this instance represents config data else returns False '''
                                            return False

                                        def _has_data(self):
                                            if self.communities is not None:
                                                for child in self.communities:
                                                    if child is not None:
                                                        return True

                                            return False

                                        @staticmethod
                                        def _meta_info():
                                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline.State']['meta_info']

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:inline'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return True

                                    def _has_data(self):
                                        if self.config is not None and self.config._has_data():
                                            return True

                                        if self.state is not None and self.state._has_data():
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Inline']['meta_info']


                                class Reference(object):
                                    """
                                    Provide a reference to a defined community set for the
                                    set\-community action
                                    
                                    .. attribute:: config
                                    
                                    	Configuration data for referening a community\-set in the set\-community action
                                    	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference.Config>`
                                    
                                    .. attribute:: state
                                    
                                    	Operational state data for referening a community\-set in the set\-community action
                                    	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference.State>`
                                    
                                    	**config**\: False
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference.Config()
                                        self.config.parent = self
                                        self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference.State()
                                        self.state.parent = self


                                    class Config(object):
                                        """
                                        Configuration data for referening a community\-set in the
                                        set\-community action
                                        
                                        .. attribute:: community_set_ref
                                        
                                        	References a defined community set by name
                                        	**type**\:  str
                                        
                                        	**refers to**\:  :py:class:`community_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet>`
                                        
                                        

                                        """

                                        _prefix = 'oc-bgp-pol'
                                        _revision = '2016-06-21'

                                        def __init__(self):
                                            self.parent = None
                                            self.ylist_key_names = []

                                            self.community_set_ref = None

                                        @property
                                        def _common_path(self):
                                            if self.parent is None:
                                                raise YPYModelError('parent is not set . Cannot derive path.')

                                            return self.parent._common_path +'/openconfig-bgp-policy:config'

                                        def is_config(self):
                                            ''' Returns True if this instance represents config data else returns False '''
                                            return True

                                        def _has_data(self):
                                            if self.community_set_ref is not None:
                                                return True

                                            return False

                                        @staticmethod
                                        def _meta_info():
                                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference.Config']['meta_info']


                                    class State(object):
                                        """
                                        Operational state data for referening a community\-set
                                        in the set\-community action
                                        
                                        .. attribute:: community_set_ref
                                        
                                        	References a defined community set by name
                                        	**type**\:  str
                                        
                                        	**refers to**\:  :py:class:`community_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.CommunitySets.CommunitySet>`
                                        
                                        	**config**\: False
                                        
                                        

                                        """

                                        _prefix = 'oc-bgp-pol'
                                        _revision = '2016-06-21'

                                        def __init__(self):
                                            self.parent = None
                                            self.ylist_key_names = []

                                            self.community_set_ref = None

                                        @property
                                        def _common_path(self):
                                            if self.parent is None:
                                                raise YPYModelError('parent is not set . Cannot derive path.')

                                            return self.parent._common_path +'/openconfig-bgp-policy:state'

                                        def is_config(self):
                                            ''' Returns True if this instance represents config data else returns False '''
                                            return False

                                        def _has_data(self):
                                            if self.community_set_ref is not None:
                                                return True

                                            return False

                                        @staticmethod
                                        def _meta_info():
                                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference.State']['meta_info']

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:reference'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return True

                                    def _has_data(self):
                                        if self.config is not None and self.config._has_data():
                                            return True

                                        if self.state is not None and self.state._has_data():
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity.Reference']['meta_info']

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-bgp-policy:set-community'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.config is not None and self.config._has_data():
                                        return True

                                    if self.inline is not None and self.inline._has_data():
                                        return True

                                    if self.reference is not None and self.reference._has_data():
                                        return True

                                    if self.state is not None and self.state._has_data():
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetCommunity']['meta_info']


                            class SetExtCommunity(object):
                                """
                                Action to set the extended community attributes of the
                                route, along with options to modify how the community is
                                modified. Extended communities may be set using an inline
                                list OR a reference to an existing defined set (but not
                                both).
                                
                                .. attribute:: config
                                
                                	Configuration data for the set\-ext\-community action
                                	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Config>`
                                
                                .. attribute:: inline
                                
                                	Set the extended community values for the action inline with a list
                                	**type**\:   :py:class:`Inline <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline>`
                                
                                .. attribute:: reference
                                
                                	Provide a reference to an extended community set for the set\-ext\-community action
                                	**type**\:   :py:class:`Reference <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference>`
                                
                                .. attribute:: state
                                
                                	Operational state data for the set\-ext\-community action
                                	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.State>`
                                
                                	**config**\: False
                                
                                

                                """

                                _prefix = 'oc-bgp-pol'
                                _revision = '2016-06-21'

                                def __init__(self):
                                    self.parent = None
                                    self.ylist_key_names = []

                                    self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Config()
                                    self.config.parent = self
                                    self.inline = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline()
                                    self.inline.parent = self
                                    self.reference = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference()
                                    self.reference.parent = self
                                    self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.State()
                                    self.state.parent = self


                                class Config(object):
                                    """
                                    Configuration data for the set\-ext\-community action
                                    
                                    .. attribute:: method
                                    
                                    	Indicates the method used to specify the extended communities for the set\-ext\-community action
                                    	**type**\:   :py:class:`MethodEnum <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Config.MethodEnum>`
                                    
                                    .. attribute:: options
                                    
                                    	Options for modifying the community attribute with the specified values.  These options apply to both methods of setting the community attribute
                                    	**type**\:   :py:class:`BgpSetCommunityOptionTypeEnum <ydk.models.ydktest.openconfig_bgp_policy.BgpSetCommunityOptionTypeEnum>`
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.method = None
                                        self.options = None

                                    class MethodEnum(Enum):
                                        """
                                        MethodEnum

                                        Indicates the method used to specify the extended

                                        communities for the set\-ext\-community action

                                        .. data:: INLINE = 0

                                        	The extended communities are specified inline as a

                                        	list

                                        .. data:: REFERENCE = 1

                                        	The extended communities are specified by referencing a

                                        	defined ext-community set

                                        """

                                        INLINE = 0

                                        REFERENCE = 1


                                        @staticmethod
                                        def _meta_info():
                                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Config.MethodEnum']


                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:config'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return True

                                    def _has_data(self):
                                        if self.method is not None:
                                            return True

                                        if self.options is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Config']['meta_info']


                                class State(object):
                                    """
                                    Operational state data for the set\-ext\-community action
                                    
                                    .. attribute:: method
                                    
                                    	Indicates the method used to specify the extended communities for the set\-ext\-community action
                                    	**type**\:   :py:class:`MethodEnum <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.State.MethodEnum>`
                                    
                                    	**config**\: False
                                    
                                    .. attribute:: options
                                    
                                    	Options for modifying the community attribute with the specified values.  These options apply to both methods of setting the community attribute
                                    	**type**\:   :py:class:`BgpSetCommunityOptionTypeEnum <ydk.models.ydktest.openconfig_bgp_policy.BgpSetCommunityOptionTypeEnum>`
                                    
                                    	**config**\: False
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.method = None
                                        self.options = None

                                    class MethodEnum(Enum):
                                        """
                                        MethodEnum

                                        Indicates the method used to specify the extended

                                        communities for the set\-ext\-community action

                                        .. data:: INLINE = 0

                                        	The extended communities are specified inline as a

                                        	list

                                        .. data:: REFERENCE = 1

                                        	The extended communities are specified by referencing a

                                        	defined ext-community set

                                        """

                                        INLINE = 0

                                        REFERENCE = 1


                                        @staticmethod
                                        def _meta_info():
                                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.State.MethodEnum']


                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:state'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return False

                                    def _has_data(self):
                                        if self.method is not None:
                                            return True

                                        if self.options is not None:
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.State']['meta_info']


                                class Inline(object):
                                    """
                                    Set the extended community values for the action inline with
                                    a list.
                                    
                                    .. attribute:: config
                                    
                                    	Configuration data or inline specification of set\-ext\-community action
                                    	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline.Config>`
                                    
                                    .. attribute:: state
                                    
                                    	Operational state data or inline specification of set\-ext\-community action
                                    	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline.State>`
                                    
                                    	**config**\: False
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline.Config()
                                        self.config.parent = self
                                        self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline.State()
                                        self.state.parent = self


                                    class Config(object):
                                        """
                                        Configuration data or inline specification of
                                        set\-ext\-community action
                                        
                                        .. attribute:: communities
                                        
                                        	Set the extended community values for the update inline with a list
                                        	**type**\: one of the below types:
                                        
                                        	**type**\:  list of str
                                        
                                        	**pattern:** (6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])\:(4[0\-2][0\-9][0\-4][0\-9][0\-6][0\-7][0\-2][0\-9][0\-6]\|[1\-3][0\-9]{9}\|[1\-9]([0\-9]{1,7})?[0\-9]\|[1\-9])
                                        
                                        
                                        ----
                                        	**type**\:  list of str
                                        
                                        	**pattern:** (([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])
                                        
                                        
                                        ----
                                        	**type**\:  list of str
                                        
                                        	**pattern:** route\\\-target\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])\:(4[0\-2][0\-9][0\-4][0\-9][0\-6][0\-7][0\-2][0\-9][0\-6]\|[1\-3][0\-9]{9}\|[1\-9]([0\-9]{1,7})?[0\-9]\|[1\-9])
                                        
                                        
                                        ----
                                        	**type**\:  list of str
                                        
                                        	**pattern:** route\\\-target\:(([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])
                                        
                                        
                                        ----
                                        	**type**\:  list of str
                                        
                                        	**pattern:** route\\\-origin\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])\:(4[0\-2][0\-9][0\-4][0\-9][0\-6][0\-7][0\-2][0\-9][0\-6]\|[1\-3][0\-9]{9}\|[1\-9]([0\-9]{1,7})?[0\-9]\|[1\-9])
                                        
                                        
                                        ----
                                        	**type**\:  list of str
                                        
                                        	**pattern:** route\\\-origin\:(([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])
                                        
                                        
                                        ----
                                        
                                        ----
                                        	**type**\:  
                                        		list of   :py:class:`Bgp_Well_Known_Std_CommunityIdentity <ydk.models.ydktest.openconfig_bgp_types.Bgp_Well_Known_Std_CommunityIdentity>`
                                        
                                        
                                        ----
                                        

                                        """

                                        _prefix = 'oc-bgp-pol'
                                        _revision = '2016-06-21'

                                        def __init__(self):
                                            self.parent = None
                                            self.ylist_key_names = []

                                            self.communities = YLeafList()
                                            self.communities.parent = self
                                            self.communities.name = 'communities'

                                        @property
                                        def _common_path(self):
                                            if self.parent is None:
                                                raise YPYModelError('parent is not set . Cannot derive path.')

                                            return self.parent._common_path +'/openconfig-bgp-policy:config'

                                        def is_config(self):
                                            ''' Returns True if this instance represents config data else returns False '''
                                            return True

                                        def _has_data(self):
                                            if self.communities is not None:
                                                for child in self.communities:
                                                    if child is not None:
                                                        return True

                                            return False

                                        @staticmethod
                                        def _meta_info():
                                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline.Config']['meta_info']


                                    class State(object):
                                        """
                                        Operational state data or inline specification of
                                        set\-ext\-community action
                                        
                                        .. attribute:: communities
                                        
                                        	Set the extended community values for the update inline with a list
                                        	**type**\: one of the below types:
                                        
                                        	**type**\:  list of str
                                        
                                        	**pattern:** (6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])\:(4[0\-2][0\-9][0\-4][0\-9][0\-6][0\-7][0\-2][0\-9][0\-6]\|[1\-3][0\-9]{9}\|[1\-9]([0\-9]{1,7})?[0\-9]\|[1\-9])
                                        
                                        	**config**\: False
                                        
                                        
                                        ----
                                        	**type**\:  list of str
                                        
                                        	**pattern:** (([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])
                                        
                                        	**config**\: False
                                        
                                        
                                        ----
                                        	**type**\:  list of str
                                        
                                        	**pattern:** route\\\-target\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])\:(4[0\-2][0\-9][0\-4][0\-9][0\-6][0\-7][0\-2][0\-9][0\-6]\|[1\-3][0\-9]{9}\|[1\-9]([0\-9]{1,7})?[0\-9]\|[1\-9])
                                        
                                        	**config**\: False
                                        
                                        
                                        ----
                                        	**type**\:  list of str
                                        
                                        	**pattern:** route\\\-target\:(([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])
                                        
                                        	**config**\: False
                                        
                                        
                                        ----
                                        	**type**\:  list of str
                                        
                                        	**pattern:** route\\\-origin\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])\:(4[0\-2][0\-9][0\-4][0\-9][0\-6][0\-7][0\-2][0\-9][0\-6]\|[1\-3][0\-9]{9}\|[1\-9]([0\-9]{1,7})?[0\-9]\|[1\-9])
                                        
                                        	**config**\: False
                                        
                                        
                                        ----
                                        	**type**\:  list of str
                                        
                                        	**pattern:** route\\\-origin\:(([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\\.){3}([0\-9]\|[1\-9][0\-9]\|1[0\-9][0\-9]\|2[0\-4][0\-9]\|25[0\-5])\:(6[0\-5][0\-5][0\-3][0\-5]\|[1\-5][0\-9]{4}\|[1\-9][0\-9]{1,4}\|[0\-9])
                                        
                                        	**config**\: False
                                        
                                        
                                        ----
                                        
                                        ----
                                        	**type**\:  
                                        		list of   :py:class:`Bgp_Well_Known_Std_CommunityIdentity <ydk.models.ydktest.openconfig_bgp_types.Bgp_Well_Known_Std_CommunityIdentity>`
                                        
                                        	**config**\: False
                                        
                                        
                                        ----
                                        

                                        """

                                        _prefix = 'oc-bgp-pol'
                                        _revision = '2016-06-21'

                                        def __init__(self):
                                            self.parent = None
                                            self.ylist_key_names = []

                                            self.communities = YLeafList()
                                            self.communities.parent = self
                                            self.communities.name = 'communities'

                                        @property
                                        def _common_path(self):
                                            if self.parent is None:
                                                raise YPYModelError('parent is not set . Cannot derive path.')

                                            return self.parent._common_path +'/openconfig-bgp-policy:state'

                                        def is_config(self):
                                            ''' Returns True if this instance represents config data else returns False '''
                                            return False

                                        def _has_data(self):
                                            if self.communities is not None:
                                                for child in self.communities:
                                                    if child is not None:
                                                        return True

                                            return False

                                        @staticmethod
                                        def _meta_info():
                                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline.State']['meta_info']

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:inline'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return True

                                    def _has_data(self):
                                        if self.config is not None and self.config._has_data():
                                            return True

                                        if self.state is not None and self.state._has_data():
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Inline']['meta_info']


                                class Reference(object):
                                    """
                                    Provide a reference to an extended community set for the
                                    set\-ext\-community action
                                    
                                    .. attribute:: config
                                    
                                    	Configuration data for referening an extended community\-set in the set\-ext\-community action
                                    	**type**\:   :py:class:`Config <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference.Config>`
                                    
                                    .. attribute:: state
                                    
                                    	Operational state data for referening an extended community\-set in the set\-ext\-community action
                                    	**type**\:   :py:class:`State <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference.State>`
                                    
                                    	**config**\: False
                                    
                                    

                                    """

                                    _prefix = 'oc-bgp-pol'
                                    _revision = '2016-06-21'

                                    def __init__(self):
                                        self.parent = None
                                        self.ylist_key_names = []

                                        self.config = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference.Config()
                                        self.config.parent = self
                                        self.state = RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference.State()
                                        self.state.parent = self


                                    class Config(object):
                                        """
                                        Configuration data for referening an extended
                                        community\-set in the set\-ext\-community action
                                        
                                        .. attribute:: ext_community_set_ref
                                        
                                        	References a defined extended community set by name
                                        	**type**\:  str
                                        
                                        	**refers to**\:  :py:class:`ext_community_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet>`
                                        
                                        

                                        """

                                        _prefix = 'oc-bgp-pol'
                                        _revision = '2016-06-21'

                                        def __init__(self):
                                            self.parent = None
                                            self.ylist_key_names = []

                                            self.ext_community_set_ref = None

                                        @property
                                        def _common_path(self):
                                            if self.parent is None:
                                                raise YPYModelError('parent is not set . Cannot derive path.')

                                            return self.parent._common_path +'/openconfig-bgp-policy:config'

                                        def is_config(self):
                                            ''' Returns True if this instance represents config data else returns False '''
                                            return True

                                        def _has_data(self):
                                            if self.ext_community_set_ref is not None:
                                                return True

                                            return False

                                        @staticmethod
                                        def _meta_info():
                                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference.Config']['meta_info']


                                    class State(object):
                                        """
                                        Operational state data for referening an extended
                                        community\-set in the set\-ext\-community action
                                        
                                        .. attribute:: ext_community_set_ref
                                        
                                        	References a defined extended community set by name
                                        	**type**\:  str
                                        
                                        	**refers to**\:  :py:class:`ext_community_set_name <ydk.models.ydktest.openconfig_routing_policy.RoutingPolicy.DefinedSets.BgpDefinedSets.ExtCommunitySets.ExtCommunitySet>`
                                        
                                        	**config**\: False
                                        
                                        

                                        """

                                        _prefix = 'oc-bgp-pol'
                                        _revision = '2016-06-21'

                                        def __init__(self):
                                            self.parent = None
                                            self.ylist_key_names = []

                                            self.ext_community_set_ref = None

                                        @property
                                        def _common_path(self):
                                            if self.parent is None:
                                                raise YPYModelError('parent is not set . Cannot derive path.')

                                            return self.parent._common_path +'/openconfig-bgp-policy:state'

                                        def is_config(self):
                                            ''' Returns True if this instance represents config data else returns False '''
                                            return False

                                        def _has_data(self):
                                            if self.ext_community_set_ref is not None:
                                                return True

                                            return False

                                        @staticmethod
                                        def _meta_info():
                                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference.State']['meta_info']

                                    @property
                                    def _common_path(self):
                                        if self.parent is None:
                                            raise YPYModelError('parent is not set . Cannot derive path.')

                                        return self.parent._common_path +'/openconfig-bgp-policy:reference'

                                    def is_config(self):
                                        ''' Returns True if this instance represents config data else returns False '''
                                        return True

                                    def _has_data(self):
                                        if self.config is not None and self.config._has_data():
                                            return True

                                        if self.state is not None and self.state._has_data():
                                            return True

                                        return False

                                    @staticmethod
                                    def _meta_info():
                                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity.Reference']['meta_info']

                                @property
                                def _common_path(self):
                                    if self.parent is None:
                                        raise YPYModelError('parent is not set . Cannot derive path.')

                                    return self.parent._common_path +'/openconfig-bgp-policy:set-ext-community'

                                def is_config(self):
                                    ''' Returns True if this instance represents config data else returns False '''
                                    return True

                                def _has_data(self):
                                    if self.config is not None and self.config._has_data():
                                        return True

                                    if self.inline is not None and self.inline._has_data():
                                        return True

                                    if self.reference is not None and self.reference._has_data():
                                        return True

                                    if self.state is not None and self.state._has_data():
                                        return True

                                    return False

                                @staticmethod
                                def _meta_info():
                                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions.SetExtCommunity']['meta_info']

                            @property
                            def _common_path(self):
                                if self.parent is None:
                                    raise YPYModelError('parent is not set . Cannot derive path.')

                                return self.parent._common_path +'/openconfig-bgp-policy:bgp-actions'

                            def is_config(self):
                                ''' Returns True if this instance represents config data else returns False '''
                                return True

                            def _has_data(self):
                                if self.config is not None and self.config._has_data():
                                    return True

                                if self.set_as_path_prepend is not None and self.set_as_path_prepend._has_data():
                                    return True

                                if self.set_community is not None and self.set_community._has_data():
                                    return True

                                if self.set_ext_community is not None and self.set_ext_community._has_data():
                                    return True

                                if self.state is not None and self.state._has_data():
                                    return True

                                return False

                            @staticmethod
                            def _meta_info():
                                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                                return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions.BgpActions']['meta_info']

                        @property
                        def _common_path(self):
                            if self.parent is None:
                                raise YPYModelError('parent is not set . Cannot derive path.')

                            return self.parent._common_path +'/openconfig-routing-policy:actions'

                        def is_config(self):
                            ''' Returns True if this instance represents config data else returns False '''
                            return True

                        def _has_data(self):
                            if self.bgp_actions is not None and self.bgp_actions._has_data():
                                return True

                            if self.config is not None and self.config._has_data():
                                return True

                            if self.igp_actions is not None and self.igp_actions._has_data():
                                return True

                            if self.state is not None and self.state._has_data():
                                return True

                            return False

                        @staticmethod
                        def _meta_info():
                            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                            return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement.Actions']['meta_info']

                    @property
                    def _common_path(self):
                        if self.parent is None:
                            raise YPYModelError('parent is not set . Cannot derive path.')
                        if self.name is None:
                            raise YPYModelError('Key property name is None')

                        return self.parent._common_path +'/openconfig-routing-policy:statement[openconfig-routing-policy:name = ' + str(self.name) + ']'

                    def is_config(self):
                        ''' Returns True if this instance represents config data else returns False '''
                        return True

                    def _has_data(self):
                        if self.name is not None:
                            return True

                        if self.actions is not None and self.actions._has_data():
                            return True

                        if self.conditions is not None and self.conditions._has_data():
                            return True

                        if self.config is not None and self.config._has_data():
                            return True

                        if self.state is not None and self.state._has_data():
                            return True

                        return False

                    @staticmethod
                    def _meta_info():
                        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                        return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements.Statement']['meta_info']

                @property
                def _common_path(self):
                    if self.parent is None:
                        raise YPYModelError('parent is not set . Cannot derive path.')

                    return self.parent._common_path +'/openconfig-routing-policy:statements'

                def is_config(self):
                    ''' Returns True if this instance represents config data else returns False '''
                    return True

                def _has_data(self):
                    if self.statement is not None:
                        for child_ref in self.statement:
                            if child_ref._has_data():
                                return True

                    return False

                @staticmethod
                def _meta_info():
                    from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                    return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition.Statements']['meta_info']

            @property
            def _common_path(self):
                if self.name is None:
                    raise YPYModelError('Key property name is None')

                return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:policy-definitions/openconfig-routing-policy:policy-definition[openconfig-routing-policy:name = ' + str(self.name) + ']'

            def is_config(self):
                ''' Returns True if this instance represents config data else returns False '''
                return True

            def _has_data(self):
                if self.name is not None:
                    return True

                if self.config is not None and self.config._has_data():
                    return True

                if self.state is not None and self.state._has_data():
                    return True

                if self.statements is not None and self.statements._has_data():
                    return True

                return False

            @staticmethod
            def _meta_info():
                from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
                return meta._meta_table['RoutingPolicy.PolicyDefinitions.PolicyDefinition']['meta_info']

        @property
        def _common_path(self):

            return '/openconfig-routing-policy:routing-policy/openconfig-routing-policy:policy-definitions'

        def is_config(self):
            ''' Returns True if this instance represents config data else returns False '''
            return True

        def _has_data(self):
            if self.policy_definition is not None:
                for child_ref in self.policy_definition:
                    if child_ref._has_data():
                        return True

            return False

        @staticmethod
        def _meta_info():
            from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
            return meta._meta_table['RoutingPolicy.PolicyDefinitions']['meta_info']

    @property
    def _common_path(self):

        return '/openconfig-routing-policy:routing-policy'

    def is_config(self):
        ''' Returns True if this instance represents config data else returns False '''
        return True

    def _has_data(self):
        if self.defined_sets is not None and self.defined_sets._has_data():
            return True

        if self.policy_definitions is not None and self.policy_definitions._has_data():
            return True

        return False

    @staticmethod
    def _meta_info():
        from ydk.models.ydktest._meta import _openconfig_routing_policy as meta
        return meta._meta_table['RoutingPolicy']['meta_info']


