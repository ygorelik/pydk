
import re
import collections

from enum import Enum

from ydk._core._dm_meta_info import _MetaInfoClassMember, _MetaInfoClass, _MetaInfoEnum
from ydk._core._dm_meta_info import ATTRIBUTE, REFERENCE_CLASS, REFERENCE_LIST, REFERENCE_LEAFLIST, ANYXML_CLASS
from ydk._core._dm_meta_info import REFERENCE_IDENTITY_CLASS, REFERENCE_ENUM_CLASS, REFERENCE_BITS, REFERENCE_UNION

from ydk.types import Empty, YList, YLeafList, DELETE, Decimal64, FixedBitsDict
from ydk.errors import YPYError, YPYModelError
from ydk.providers._importer import _yang_ns

_meta_table = {
    'BgpSessionDirectionEnum' : _MetaInfoEnum('BgpSessionDirectionEnum',
        'ydk.models.ydktest.openconfig_bgp_types', 'BgpSessionDirectionEnum',
        '''Type to describe the direction of NLRI transmission''',
        {
            'INBOUND':'INBOUND',
            'OUTBOUND':'OUTBOUND',
        }, 'openconfig-bgp-types', _yang_ns._namespaces['openconfig-bgp-types']),
    'BgpOriginAttrTypeEnum' : _MetaInfoEnum('BgpOriginAttrTypeEnum',
        'ydk.models.ydktest.openconfig_bgp_types', 'BgpOriginAttrTypeEnum',
        '''Type definition for standard BGP origin attribute''',
        {
            'IGP':'IGP',
            'EGP':'EGP',
            'INCOMPLETE':'INCOMPLETE',
        }, 'openconfig-bgp-types', _yang_ns._namespaces['openconfig-bgp-types']),
    'PeerTypeEnum' : _MetaInfoEnum('PeerTypeEnum',
        'ydk.models.ydktest.openconfig_bgp_types', 'PeerTypeEnum',
        '''labels a peer or peer group as explicitly internal or
external''',
        {
            'INTERNAL':'INTERNAL',
            'EXTERNAL':'EXTERNAL',
        }, 'openconfig-bgp-types', _yang_ns._namespaces['openconfig-bgp-types']),
    'CommunityTypeEnum' : _MetaInfoEnum('CommunityTypeEnum',
        'ydk.models.ydktest.openconfig_bgp_types', 'CommunityTypeEnum',
        '''type describing variations of community attributes:
STANDARD: standard BGP community [rfc1997]
EXTENDED: extended BGP community [rfc4360]
BOTH: both standard and extended community''',
        {
            'STANDARD':'STANDARD',
            'EXTENDED':'EXTENDED',
            'BOTH':'BOTH',
            'NONE':'NONE',
        }, 'openconfig-bgp-types', _yang_ns._namespaces['openconfig-bgp-types']),
    'Bgp_CapabilityIdentity' : {
        'meta_info' : _MetaInfoClass('Bgp_CapabilityIdentity', REFERENCE_IDENTITY_CLASS,
            '''Base identity for a BGP capability''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'BGP_CAPABILITY',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'Afi_Safi_TypeIdentity' : {
        'meta_info' : _MetaInfoClass('Afi_Safi_TypeIdentity', REFERENCE_IDENTITY_CLASS,
            '''Base identity type for AFI,SAFI tuples for BGP-4''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'AFI_SAFI_TYPE',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'Bgp_Well_Known_Std_CommunityIdentity' : {
        'meta_info' : _MetaInfoClass('Bgp_Well_Known_Std_CommunityIdentity', REFERENCE_IDENTITY_CLASS,
            '''Reserved communities within the standard community space
defined by RFC1997. These communities must fall within the
range 0x00000000 to 0xFFFFFFFF''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'BGP_WELL_KNOWN_STD_COMMUNITY',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'Remove_Private_As_OptionIdentity' : {
        'meta_info' : _MetaInfoClass('Remove_Private_As_OptionIdentity', REFERENCE_IDENTITY_CLASS,
            '''Base identity for options for removing private autonomous
system numbers from the AS_PATH attribute''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'REMOVE_PRIVATE_AS_OPTION',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'MpbgpIdentity' : {
        'meta_info' : _MetaInfoClass('MpbgpIdentity', REFERENCE_IDENTITY_CLASS,
            '''Multi-protocol extensions to BGP''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'MPBGP',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'Route_RefreshIdentity' : {
        'meta_info' : _MetaInfoClass('Route_RefreshIdentity', REFERENCE_IDENTITY_CLASS,
            '''The BGP route-refresh functionality''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'ROUTE_REFRESH',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'Asn32Identity' : {
        'meta_info' : _MetaInfoClass('Asn32Identity', REFERENCE_IDENTITY_CLASS,
            '''4-byte (32-bit) AS number functionality''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'ASN32',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'Graceful_RestartIdentity' : {
        'meta_info' : _MetaInfoClass('Graceful_RestartIdentity', REFERENCE_IDENTITY_CLASS,
            '''Graceful restart functionality''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'GRACEFUL_RESTART',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'Add_PathsIdentity' : {
        'meta_info' : _MetaInfoClass('Add_PathsIdentity', REFERENCE_IDENTITY_CLASS,
            '''BGP add-paths''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'ADD_PATHS',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'Ipv4_UnicastIdentity' : {
        'meta_info' : _MetaInfoClass('Ipv4_UnicastIdentity', REFERENCE_IDENTITY_CLASS,
            '''IPv4 unicast (AFI,SAFI = 1,1)''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'IPV4_UNICAST',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'Ipv6_UnicastIdentity' : {
        'meta_info' : _MetaInfoClass('Ipv6_UnicastIdentity', REFERENCE_IDENTITY_CLASS,
            '''IPv6 unicast (AFI,SAFI = 2,1)''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'IPV6_UNICAST',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'Ipv4_Labeled_UnicastIdentity' : {
        'meta_info' : _MetaInfoClass('Ipv4_Labeled_UnicastIdentity', REFERENCE_IDENTITY_CLASS,
            '''Labeled IPv4 unicast (AFI,SAFI = 1,4)''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'IPV4_LABELED_UNICAST',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'Ipv6_Labeled_UnicastIdentity' : {
        'meta_info' : _MetaInfoClass('Ipv6_Labeled_UnicastIdentity', REFERENCE_IDENTITY_CLASS,
            '''Labeled IPv6 unicast (AFI,SAFI = 2,4)''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'IPV6_LABELED_UNICAST',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'L3Vpn_Ipv4_UnicastIdentity' : {
        'meta_info' : _MetaInfoClass('L3Vpn_Ipv4_UnicastIdentity', REFERENCE_IDENTITY_CLASS,
            '''Unicast IPv4 MPLS L3VPN (AFI,SAFI = 1,128)''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'L3VPN_IPV4_UNICAST',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'L3Vpn_Ipv6_UnicastIdentity' : {
        'meta_info' : _MetaInfoClass('L3Vpn_Ipv6_UnicastIdentity', REFERENCE_IDENTITY_CLASS,
            '''Unicast IPv6 MPLS L3VPN (AFI,SAFI = 2,128)''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'L3VPN_IPV6_UNICAST',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'L3Vpn_Ipv4_MulticastIdentity' : {
        'meta_info' : _MetaInfoClass('L3Vpn_Ipv4_MulticastIdentity', REFERENCE_IDENTITY_CLASS,
            '''Multicast IPv4 MPLS L3VPN (AFI,SAFI = 1,129)''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'L3VPN_IPV4_MULTICAST',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'L3Vpn_Ipv6_MulticastIdentity' : {
        'meta_info' : _MetaInfoClass('L3Vpn_Ipv6_MulticastIdentity', REFERENCE_IDENTITY_CLASS,
            '''Multicast IPv6 MPLS L3VPN (AFI,SAFI = 2,129)''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'L3VPN_IPV6_MULTICAST',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'L2Vpn_VplsIdentity' : {
        'meta_info' : _MetaInfoClass('L2Vpn_VplsIdentity', REFERENCE_IDENTITY_CLASS,
            '''BGP-signalled VPLS (AFI,SAFI = 25,65)''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'L2VPN_VPLS',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'L2Vpn_EvpnIdentity' : {
        'meta_info' : _MetaInfoClass('L2Vpn_EvpnIdentity', REFERENCE_IDENTITY_CLASS,
            '''BGP MPLS Based Ethernet VPN (AFI,SAFI = 25,70)''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'L2VPN_EVPN',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'No_ExportIdentity' : {
        'meta_info' : _MetaInfoClass('No_ExportIdentity', REFERENCE_IDENTITY_CLASS,
            '''Do not export NLRI received carrying this community outside
the bounds of this autonomous system, or this confederation if
the local autonomous system is a confederation member AS. This
community has a value of 0xFFFFFF01.''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'NO_EXPORT',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'No_AdvertiseIdentity' : {
        'meta_info' : _MetaInfoClass('No_AdvertiseIdentity', REFERENCE_IDENTITY_CLASS,
            '''All NLRI received carrying this community must not be
advertised to other BGP peers. This community has a value of
0xFFFFFF02.''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'NO_ADVERTISE',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'No_Export_SubconfedIdentity' : {
        'meta_info' : _MetaInfoClass('No_Export_SubconfedIdentity', REFERENCE_IDENTITY_CLASS,
            '''All NLRI received carrying this community must not be
advertised to external BGP peers - including over confederation
sub-AS boundaries. This community has a value of 0xFFFFFF03.''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'NO_EXPORT_SUBCONFED',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'NopeerIdentity' : {
        'meta_info' : _MetaInfoClass('NopeerIdentity', REFERENCE_IDENTITY_CLASS,
            '''An autonomous system receiving NLRI tagged with this community
is advised not to readvertise the NLRI to external bi-lateral
peer autonomous systems. An AS may also filter received NLRI
from bilateral peer sessions when they are tagged with this
community value''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'NOPEER',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'Private_As_Remove_AllIdentity' : {
        'meta_info' : _MetaInfoClass('Private_As_Remove_AllIdentity', REFERENCE_IDENTITY_CLASS,
            '''Strip all private autonmous system numbers from the AS_PATH.
This action is performed regardless of the other content of the
AS_PATH attribute, and for all instances of private AS numbers
within that attribute.''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'PRIVATE_AS_REMOVE_ALL',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
    'Private_As_Replace_AllIdentity' : {
        'meta_info' : _MetaInfoClass('Private_As_Replace_AllIdentity', REFERENCE_IDENTITY_CLASS,
            '''Replace all instances of private autonomous system numbers in
the AS_PATH with the local BGP speaker's autonomous system
number. This action is performed regardless of the other
content of the AS_PATH attribute, and for all instances of
private AS number within that attribute.''',
            False, 
            [
            ],
            'openconfig-bgp-types',
            'PRIVATE_AS_REPLACE_ALL',
            _yang_ns._namespaces['openconfig-bgp-types'],
            'ydk.models.ydktest.openconfig_bgp_types'
        ),
    },
}
