
import re
import collections

from enum import Enum

from ydk._core._dm_meta_info import _MetaInfoClassMember, _MetaInfoClass, _MetaInfoEnum
from ydk._core._dm_meta_info import ATTRIBUTE, REFERENCE_CLASS, REFERENCE_LIST, REFERENCE_LEAFLIST, ANYXML_CLASS
from ydk._core._dm_meta_info import REFERENCE_IDENTITY_CLASS, REFERENCE_ENUM_CLASS, REFERENCE_BITS, REFERENCE_UNION

from ydk.types import Empty, YList, YLeafList, DELETE, Decimal64, FixedBitsDict
from ydk.errors import YPYError, YPYModelError
from ydk.providers._importer import _yang_ns

_meta_table = {
    'MainA.MainAug3_C' : {
        'meta_info' : _MetaInfoClass('MainA.MainAug3_C', REFERENCE_CLASS,
            ''' ''',
            False, 
            [
            _MetaInfoClassMember('meh', ATTRIBUTE, 'int', 'int8',
                None, None,
                [('-128', '127')], [],
                '''                blah
                ''',
                'meh',
                'main-aug3', False),
            ],
            'main-aug3',
            'C',
            _yang_ns._namespaces['main-aug3'],
            'ydk.models.ydktest.main',
        ),
    },
    'MainA.MainAug3_D' : {
        'meta_info' : _MetaInfoClass('MainA.MainAug3_D', REFERENCE_CLASS,
            ''' ''',
            False, 
            [
            _MetaInfoClassMember('buh', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                blah
                ''',
                'buh',
                'main-aug3', False),
            ],
            'main-aug3',
            'D',
            _yang_ns._namespaces['main-aug3'],
            'ydk.models.ydktest.main',
        ),
    },
    'MainA.MainAug1_C' : {
        'meta_info' : _MetaInfoClass('MainA.MainAug1_C', REFERENCE_CLASS,
            ''' ''',
            False, 
            [
            _MetaInfoClassMember('two', ATTRIBUTE, 'str', 'string',
                None, None,
                [], [],
                '''                blah
                ''',
                'two',
                'main-aug1', False),
            ],
            'main-aug1',
            'C',
            _yang_ns._namespaces['main-aug1'],
            'ydk.models.ydktest.main',
        ),
    },
    'MainA.MainAug2_C' : {
        'meta_info' : _MetaInfoClass('MainA.MainAug2_C', REFERENCE_CLASS,
            ''' ''',
            False, 
            [
            _MetaInfoClassMember('three', ATTRIBUTE, 'int', 'int16',
                None, None,
                [('-32768', '32767')], [],
                '''                blah
                ''',
                'three',
                'main-aug2', False),
            ],
            'main-aug2',
            'C',
            _yang_ns._namespaces['main-aug2'],
            'ydk.models.ydktest.main',
        ),
    },
    'MainA.MainAug2_D' : {
        'meta_info' : _MetaInfoClass('MainA.MainAug2_D', REFERENCE_CLASS,
            ''' ''',
            False, 
            [
            _MetaInfoClassMember('poo', ATTRIBUTE, 'int', 'int32',
                None, None,
                [('-2147483648', '2147483647')], [],
                '''                blah
                ''',
                'poo',
                'main-aug2', False),
            ],
            'main-aug2',
            'D',
            _yang_ns._namespaces['main-aug2'],
            'ydk.models.ydktest.main',
        ),
    },
    'MainA' : {
        'meta_info' : _MetaInfoClass('MainA', REFERENCE_CLASS,
            ''' ''',
            False, 
            [
            _MetaInfoClassMember('C', REFERENCE_CLASS, 'MainAug1_C', '',
                'ydk.models.ydktest.main', 'MainA.MainAug1_C',
                [], [],
                '''                ''',
                'main_aug1_c',
                'main-aug1', False),
            _MetaInfoClassMember('C', REFERENCE_CLASS, 'MainAug2_C', '',
                'ydk.models.ydktest.main', 'MainA.MainAug2_C',
                [], [],
                '''                ''',
                'main_aug2_c',
                'main-aug2', False),
            _MetaInfoClassMember('D', REFERENCE_CLASS, 'MainAug2_D', '',
                'ydk.models.ydktest.main', 'MainA.MainAug2_D',
                [], [],
                '''                ''',
                'main_aug2_d',
                'main-aug2', False),
            _MetaInfoClassMember('C', REFERENCE_CLASS, 'MainAug3_C', '',
                'ydk.models.ydktest.main', 'MainA.MainAug3_C',
                [], [],
                '''                ''',
                'main_aug3_c',
                'main-aug3', False),
            _MetaInfoClassMember('D', REFERENCE_CLASS, 'MainAug3_D', '',
                'ydk.models.ydktest.main', 'MainA.MainAug3_D',
                [], [],
                '''                ''',
                'main_aug3_d',
                'main-aug3', False),
            _MetaInfoClassMember('one', ATTRIBUTE, 'int', 'int32',
                None, None,
                [('-2147483648', '2147483647')], [],
                '''                blah
                ''',
                'one',
                'main', False),
            ],
            'main',
            'main-A',
            _yang_ns._namespaces['main'],
            'ydk.models.ydktest.main',
        ),
    },
}
_meta_table['MainA.MainAug3_C']['meta_info'].parent =_meta_table['MainA']['meta_info']
_meta_table['MainA.MainAug3_D']['meta_info'].parent =_meta_table['MainA']['meta_info']
_meta_table['MainA.MainAug1_C']['meta_info'].parent =_meta_table['MainA']['meta_info']
_meta_table['MainA.MainAug2_C']['meta_info'].parent =_meta_table['MainA']['meta_info']
_meta_table['MainA.MainAug2_D']['meta_info'].parent =_meta_table['MainA']['meta_info']
